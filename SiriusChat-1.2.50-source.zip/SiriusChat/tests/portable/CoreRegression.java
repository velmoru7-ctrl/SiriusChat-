import com.sirius.chat.core.util.Graphemes;
import com.sirius.chat.core.util.MessageSelection;
import com.sirius.chat.core.util.SafeProjectPaths;
import com.sirius.chat.core.util.VerifiedStreams;
import com.sirius.chat.ai.pricing.CostMath;
import java.io.*;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.CancellationException;

/** Exercises the actual production Java helpers, not a rewritten Python model. */
public final class CoreRegression {
    private static int checks;
    @FunctionalInterface interface Checked { void run() throws Exception; }
    private static void check(boolean ok, String message) {
        checks++;
        if (!ok) throw new AssertionError(message);
    }
    private static void rejects(Class<? extends Throwable> type, Checked work) throws Exception {
        checks++;
        try { work.run(); }
        catch (Throwable error) { if (type.isInstance(error)) return; throw new AssertionError("Wrong exception", error); }
        throw new AssertionError("Expected " + type.getSimpleName());
    }

    public static void main(String[] args) throws Exception {
        paths(); graphemes(); transfers(); costs(); selections();
        System.out.println("PASS: " + checks + " production-core assertions (paths, Unicode, binary I/O, cost admission, message identity).");
    }

    private static void selections() {
        List<String> owned = new ArrayList<>(List.of("a", "b", "c"));
        check(MessageSelection.ownedSelection(owned, List.of("foreign")).isEmpty(), "foreign-only selection is empty, never a fallback");
        check(MessageSelection.ownedSelection(owned, List.of("foreign", "b")).equals(List.of("b")), "mixed selection stays in chat");
        check(MessageSelection.ownedSelection(owned, List.of("c", "a")).equals(List.of("a", "c")), "selection follows display order");
        check(MessageSelection.ownedSelection(owned, List.of("a", "a")).equals(List.of("a")), "no duplicate deletes");
        check(MessageSelection.ownedSelection(owned, List.of()).isEmpty(), "empty selection");
        check(MessageSelection.ownedSelection(List.of(), List.of("a")).isEmpty(), "no stale selection fallback");
        check(MessageSelection.fromAnchor(owned, "b").equals(List.of("b", "c")), "rewind by identity, not timestamp");
        check(MessageSelection.fromAnchor(owned, "a").equals(owned), "first anchor");
        check(MessageSelection.fromAnchor(owned, "c").equals(List.of("c")), "last anchor");
        check(MessageSelection.fromAnchor(owned, "missing").isEmpty(), "missing anchor cannot remove history");
        List<String> selected = MessageSelection.ownedSelection(owned, owned);
        selected.clear();
        check(owned.equals(List.of("a", "b", "c")), "selection result is detached");
        List<String> suffix = MessageSelection.fromAnchor(owned, "b"); suffix.clear();
        check(owned.equals(List.of("a", "b", "c")), "rewind result is detached");
    }

    private static void paths() throws Exception {
        for (String bad : new String[]{"../secret", "a/../../b", "/absolute", "\\absolute", "C:/boot", "C:\nboot", "a\\b", "a\0b", "", ".", "./"}) {
            rejects(IllegalArgumentException.class, () -> SafeProjectPaths.relative(bad, false));
        }
        check(SafeProjectPaths.relative("./src//main.kt", false).equals("src/main.kt"), "normalized path");
        check(SafeProjectPaths.relative(".", true).isEmpty(), "root allowed explicitly");
        check(SafeProjectPaths.relative("файл с пробелами.kt", false).equals("файл с пробелами.kt"), "Unicode path");
        Path root = Files.createTempDirectory("sirius-paths-");
        Path other = Files.createTempDirectory("sirius-outside-");
        try {
            check(SafeProjectPaths.file(root.toFile(), "src/a.kt").toPath().startsWith(root), "contained path");
            Files.createSymbolicLink(root.resolve("linked"), other);
            rejects(IllegalArgumentException.class, () -> SafeProjectPaths.file(root.toFile(), "linked/secret.txt"));
            Path link = root.resolve("root-link");
            Files.createSymbolicLink(link, other);
            rejects(IllegalArgumentException.class, () -> SafeProjectPaths.file(link.toFile(), "secret.txt"));
            check(!Files.exists(other.resolve("secret.txt")), "outside remains untouched");
        } finally {
            try (var walk = Files.walk(root)) { for (Path p : walk.sorted(Comparator.reverseOrder()).toList()) Files.deleteIfExists(p); }
            Files.deleteIfExists(other);
        }
    }

    private static void graphemes() throws Exception {
        for (String cluster : new String[]{"A", "й", "e\u0301", "👨‍👩‍👧‍👦", "👍🏽", "🇰🇿", "1️⃣", "🏳️‍🌈", "\r\n"}) {
            check(Arrays.equals(Graphemes.boundaries(cluster), new int[]{0, cluster.length()}), "single cluster " + cluster);
            Graphemes.Edit added = Graphemes.diff("ab", "a" + cluster + "b");
            check(added.oldStart == 1 && added.oldEnd == 1 && added.newStart == 1 && added.newEnd == 1 + cluster.length(), "insertion range " + cluster);
            Graphemes.Edit deleted = Graphemes.diff("a" + cluster + "b", "ab");
            check(deleted.oldStart == 1 && deleted.oldEnd == 1 + cluster.length() && deleted.newStart == deleted.newEnd, "delete range " + cluster);
        }
        check(Graphemes.boundaries("🇰🇿🇫🇷").length == 3, "separate flag pairs");
        check(Graphemes.boundaries("").length == 1, "empty boundaries");
        Graphemes.Edit combining = Graphemes.diff("e", "e\u0301");
        check(combining.oldStart == 0 && combining.newStart == 0, "do not split combining update");
        Graphemes.Edit same = Graphemes.diff("привет", "привет");
        check(same.oldStart == same.oldEnd && same.newStart == same.newEnd, "no-op text edit");
    }

    private static void transfers() throws Exception {
        byte[] bytes = new byte[3 * 1024 * 1024 + 113];
        new Random(44).nextBytes(bytes);
        ByteArrayOutputStream target = new ByteArrayOutputStream();
        long count = VerifiedStreams.copy(() -> new ByteArrayInputStream(bytes), () -> target,
            () -> new ByteArrayInputStream(target.toByteArray()), () -> {});
        check(count == bytes.length, "large binary length");
        check(Arrays.equals(bytes, target.toByteArray()), "large binary checksum");
        rejects(IOException.class, () -> VerifiedStreams.copy(() -> null, () -> new ByteArrayOutputStream(), () -> null, () -> {}));
        rejects(IOException.class, () -> VerifiedStreams.copy(() -> new ByteArrayInputStream(bytes), () -> null, () -> null, () -> {}));
        rejects(IOException.class, () -> VerifiedStreams.copy(() -> new ByteArrayInputStream(bytes), () -> new ByteArrayOutputStream(), () -> null, () -> {}));
        rejects(IOException.class, () -> VerifiedStreams.copy(() -> new ByteArrayInputStream(bytes), () -> new ByteArrayOutputStream(),
            () -> new ByteArrayInputStream(new byte[]{1}), () -> {}));
        rejects(IOException.class, () -> VerifiedStreams.copy(() -> new ByteArrayInputStream(bytes), () -> new OutputStream() {
            int remaining = 31;
            public void write(int value) throws IOException { if (--remaining <= 0) throw new IOException("Injected write failure"); }
        }, () -> new ByteArrayInputStream(bytes), () -> {}));
        boolean[] closed = {false};
        rejects(IOException.class, () -> VerifiedStreams.copy(() -> new ByteArrayInputStream(bytes) {
            public void close() { closed[0] = true; }
        }, () -> new OutputStream() { public void write(int b) throws IOException { throw new IOException("fail"); } },
            () -> new ByteArrayInputStream(bytes), () -> {}));
        check(closed[0], "source closed on failure");
        rejects(CancellationException.class, () -> VerifiedStreams.copy(() -> new ByteArrayInputStream(bytes), () -> new ByteArrayOutputStream(),
            () -> new ByteArrayInputStream(bytes), () -> { throw new CancellationException("stop"); }));
        check(VerifiedStreams.copy(() -> new ByteArrayInputStream(new byte[0]), () -> new ByteArrayOutputStream(),
            () -> new ByteArrayInputStream(new byte[0]), () -> {}) == 0, "intentional empty file");
        rejects(IOException.class, () -> VerifiedStreams.copy(() -> new ByteArrayInputStream(new byte[]{1}), () -> new ByteArrayOutputStream() {
            public void close() throws IOException { throw new IOException("close failure"); }
        }, () -> new ByteArrayInputStream(new byte[]{1}), () -> {}));
    }

    private static void costs() throws Exception {
        check(Math.abs(CostMath.tokenCost(1_000_000, 2_000_000, 3, 15) - 33) < 1e-10, "input + output rates");
        check(CostMath.tokenCost(100, 200, 0, 0) == 0, "explicitly free model");
        check(CostMath.admits(1, .2, .3, .5), "exact budget edge");
        check(!CostMath.admits(1, .2, .3, .5001), "reserved concurrent calls included");
        check(!CostMath.admits(.01, .01, 0, .0001), "stop before next request");
        check(!CostMath.admits(1, Double.NaN, 0, 0), "NaN rejected");
        check(!CostMath.admits(1, 0, 0, Double.POSITIVE_INFINITY), "infinite price rejected");
        rejects(IllegalArgumentException.class, () -> CostMath.tokenCost(-1, 1, 1, 1));
        rejects(IllegalArgumentException.class, () -> CostMath.tokenCost(1, 1, -1, 1));
        rejects(IllegalArgumentException.class, () -> CostMath.tokenCost(1, 1, Double.NaN, 1));
        check(CostMath.tokenCost(1, 0, 0.1, 1) > 0, "small charge is not zero");
    }
}
