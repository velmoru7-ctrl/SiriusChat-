import com.sirius.chat.core.util.*;
import com.sirius.chat.ai.streaming.SseDecoder;
import com.sirius.chat.ai.streaming.SseLines;
import com.sirius.chat.ai.streaming.StreamBudget;
import java.io.*;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.util.*;
import java.util.concurrent.CancellationException;
import java.util.zip.*;

/** Actual production Java code. No network, Android, or real APK is required or claimed. */
public final class ReliabilityRegression {
    private static int checks;
    @FunctionalInterface interface Checked { void run() throws Exception; }
    private static void check(boolean ok, String message) {
        checks++;
        if (!ok) throw new AssertionError(message);
    }
    private static void rejects(Class<? extends Throwable> type, Checked action) throws Exception {
        checks++;
        try { action.run(); }
        catch (Throwable e) {
            if (type.isInstance(e)) return;
            throw new AssertionError("Expected " + type.getSimpleName() + ", got " + e, e);
        }
        throw new AssertionError("Expected " + type.getSimpleName());
    }
    private static byte[] bytes(String s) { return s.getBytes(StandardCharsets.UTF_8); }
    public static void main(String[] args) throws Exception {
        bounded(); media(); origins(); sseLines(); sse(); streamBudget(); drafts(); paths(); contrast(); archives();
        System.out.println("PASS: " + checks + " additional production-Java assertions (bounded I/O, formats, origin, SSE, stream limits, drafts, paths, contrast, ZIP faults).");
    }
    private static void bounded() throws Exception {
        check(BoundedIo.readBytes(new ByteArrayInputStream(new byte[0]),0).length==0,"empty at zero cap");
        check(Arrays.equals(BoundedIo.readBytes(new ByteArrayInputStream(bytes("abc")),3),bytes("abc")),"exact byte cap");
        rejects(BoundedIo.LimitExceededException.class,()->BoundedIo.readBytes(new ByteArrayInputStream(bytes("abcd")),3));
        rejects(BoundedIo.LimitExceededException.class,()->BoundedIo.readBytes(new ByteArrayInputStream(bytes("a")),0));
        rejects(IllegalArgumentException.class,()->BoundedIo.readBytes(new ByteArrayInputStream(new byte[0]),-1));
        long[] consumed={0};
        InputStream endless=new InputStream(){
            public int read(){consumed[0]++;return 7;}
            public int read(byte[] b,int off,int n){Arrays.fill(b,off,off+n,(byte)7);consumed[0]+=n;return n;}
        };
        rejects(BoundedIo.LimitExceededException.class,()->BoundedIo.readBytes(endless,17));
        check(consumed[0]==18,"unknown-length input stops after cap plus one byte");
        byte[] large=new byte[30_000];new Random(7).nextBytes(large);
        ByteArrayOutputStream target=new ByteArrayOutputStream();
        check(BoundedIo.copy(new ByteArrayInputStream(large),target,Long.MAX_VALUE,()->{})==large.length,"long cap cannot overflow");
        check(Arrays.equals(target.toByteArray(),large),"exact streamed binary content");
        InputStream zeroOnce=new ByteArrayInputStream(bytes("abc")){
            boolean first=true;
            public synchronized int read(byte[] b,int o,int n){if(first){first=false;return 0;}return super.read(b,o,n);}
        };
        check(Arrays.equals(BoundedIo.readBytes(zeroOnce,3),bytes("abc")),"zero bulk read cannot spin forever");
        rejects(CancellationException.class,()->BoundedIo.readBytes(new ByteArrayInputStream(large),large.length,()->{throw new CancellationException();}));
        rejects(IOException.class,()->BoundedIo.copy(new ByteArrayInputStream(large),new OutputStream(){public void write(int b)throws IOException{throw new IOException("injected write failure");}},large.length,()->{}));
        rejects(IOException.class,()->BoundedIo.readBytes(new InputStream(){public int read()throws IOException{throw new IOException("injected read failure");}},32));
        check(BoundedIo.utf8(bytes("Привет 🚀")).equals("Привет 🚀"),"strict UTF-8 preserves valid data");
        rejects(CharacterCodingException.class,()->BoundedIo.utf8(new byte[]{(byte)0xc3,0x28}));
        rejects(CharacterCodingException.class,()->BoundedIo.utf8(new byte[]{(byte)0xed,(byte)0xa0,(byte)0x80}));
        check(BoundedIo.prefix("a🚀b",2).equals("a"),"no half surrogate pair");
        check(BoundedIo.prefix("a🚀b",3).equals("a🚀"),"full surrogate pair fits");
        check(BoundedIo.prefix("abc",-1).isEmpty(),"negative text budget is empty");
        check(BoundedIo.prefix("abc",100).equals("abc"),"large text budget");
    }
    private static void media() throws Exception {
        for(String s:new String[]{null,""," ","application/octet-stream","text/plain","image/svg+xml"})
            check(!MediaTypes.isSupportedImage(s),"unknown/non-image MIME must not become PNG");
        for(String s:new String[]{"image/png","IMAGE/PNG; charset=UTF-8","image/jpeg","image/jpg","image/webp","image/gif"})
            check(MediaTypes.isSupportedImage(s),"supported normalized MIME "+s);
        check(MediaTypes.normalize(" IMAGE/JPG ; ignored=yes ").equals("image/jpeg"),"JPEG alias and MIME parameters");
        check(MediaTypes.imageExtension("image/jpeg").equals(".jpg"),"JPEG filename must not lie about PNG");
        check(MediaTypes.imageExtension("image/webp").equals(".webp"),"WebP suffix");
        check(MediaTypes.imageExtension("image/gif").equals(".gif"),"GIF suffix");
        check(MediaTypes.imageExtension("image/png").equals(".png"),"PNG suffix");
        rejects(IllegalArgumentException.class,()->MediaTypes.imageExtension("text/plain"));
        check(MediaTypes.detectImageType(new byte[]{(byte)137,80,78,71,13,10,26,10}).equals("image/png"),"PNG signature");
        check(MediaTypes.detectImageType(new byte[]{(byte)255,(byte)216,(byte)255}).equals("image/jpeg"),"JPEG signature despite wrong name or MIME");
        check(MediaTypes.detectImageType(bytes("GIF89a")).equals("image/gif"),"GIF89");
        check(MediaTypes.detectImageType(bytes("GIF87a")).equals("image/gif"),"GIF87");
        check(MediaTypes.detectImageType(bytes("RIFF0000WEBP")).equals("image/webp"),"WebP signature");
        for(byte[] b:new byte[][]{new byte[0],bytes("PNG"),bytes("GIF88a"),bytes("RIFF0000WAVE"),bytes("text")})
            check(MediaTypes.detectImageType(b).isEmpty(),"no fabricated media type from arbitrary bytes");
    }
    private static void origins() {
        check(RequestOrigin.same("https","API.EXAMPLE",443,"HTTPS","api.example",443),"same normalized origin");
        check(RequestOrigin.same("http","localhost",11434,"http","localhost",11434),"same opted-in local origin");
        check(!RequestOrigin.same("https","api.example",443,"https","other.example",443),"cross-host refusal");
        check(!RequestOrigin.same("https","api.example",443,"http","api.example",80),"scheme downgrade refusal");
        check(!RequestOrigin.same("http","localhost",11434,"http","localhost",11435),"cross-port refusal");
        check(!RequestOrigin.same("https","api.example",443,"https","api.example.evil",443),"suffix is not same host");
        check(!RequestOrigin.same("https","",443,"https","",443),"empty host is invalid");
        check(!RequestOrigin.same(null,"host",443,"https","host",443),"null origin is invalid");
        check(!RequestOrigin.same("https","host",0,"https","host",0),"invalid effective port");
    }
    private static void sseLines() throws Exception {
        SseLines lines = new SseLines(new ByteArrayInputStream(bytes("a\nb\r\nc\rd")), 8);
        check(lines.next().equals("a"), "LF delimiter");
        check(lines.next().equals("b"), "CRLF delimiter");
        check(lines.next().equals("c"), "CR-only delimiter");
        check(lines.next().equals("d"), "EOF tail delimiter");
        check(lines.next()==null, "EOF remains EOF");
        SseLines empty = new SseLines(new ByteArrayInputStream(bytes("\r\r\n\n")), 0);
        check(empty.next().isEmpty() && empty.next().isEmpty() && empty.next().isEmpty() && empty.next()==null, "empty lines and CRLF folding");
        SseLines exact = new SseLines(new ByteArrayInputStream(bytes("abc\r\n")), 3);
        check(exact.next().equals("abc"), "exact byte limit before CRLF");
        rejects(BoundedIo.LimitExceededException.class, () -> new SseLines(new ByteArrayInputStream(bytes("abcd")),3).next());
        rejects(BoundedIo.LimitExceededException.class, () -> new SseLines(new ByteArrayInputStream(bytes("я")),1).next());
        rejects(CharacterCodingException.class, () -> new SseLines(new ByteArrayInputStream(new byte[]{(byte)255,10}),3).next());
        rejects(IllegalArgumentException.class, () -> new SseLines(new ByteArrayInputStream(new byte[0]),-1));
        // A CR line is available immediately; no extra read is needed to discover a possible LF.
        InputStream pausesAfterCr = new InputStream() {
            byte[] value=bytes("data: x\r"); int pos;
            public int read() throws IOException { if(pos==value.length)throw new IOException("Would wait for more network data");return value[pos++]; }
            public int read(byte[] b,int off,int len)throws IOException{
                if(pos==value.length)throw new IOException("Would wait for more network data");
                int n=Math.min(len,value.length-pos);System.arraycopy(value,pos,b,off,n);pos+=n;return n;
            }
        };
        check(new SseLines(pausesAfterCr,32).next().equals("data: x"), "CR flush does not await another byte");
    }
    private static void sse() throws Exception {
        SseDecoder d=new SseDecoder();
        check(d.accept("\uFEFFdata: hello ")==null,"BOM line waits for boundary");
        SseDecoder.Frame f=d.accept("");
        check(f.data.equals("hello ")&&f.event==null&&!f.keepAlive,"payload trailing space preserved");
        d.accept("event: stale");check(d.accept("")==null,"event-only block has no message");
        d.accept("data: next");check(d.finish().event==null,"event-only block does not leak event name");
        d.accept("event: delta");d.accept("data:  a\t ");d.accept("data:");
        f=d.finish();check(f.data.equals(" a\t \n")&&f.event.equals("delta"),"one optional space only, including empty fields");
        d.accept("data");check(d.finish().data.isEmpty(),"colonless empty data field still dispatches");
        d.accept("data:");d.accept("data: x");d.accept("data:");check(d.finish().data.equals("\nx\n"),"empty first and last data lines");
        d.accept("data: before");check(d.accept(": ping").keepAlive,"comment heartbeat");
        check(d.finish().data.equals("before"),"heartbeat does not discard data");
        d.accept("event: one");d.accept("event: two");d.accept("data: a:b:c");f=d.finish();
        check(f.event.equals("two")&&f.data.equals("a:b:c"),"last event name and later colons");
        d.accept("event:");d.accept("data: x");check(d.finish().event==null,"empty event name defaults");
        d.accept("id: 1");d.accept("retry: 10");d.accept("unknown: x");check(d.finish()==null,"irrelevant fields are not payloads");
        d.accept("data: eof");check(d.finish().data.equals("eof"),"EOF compatibility flush");
        check(d.finish()==null,"no duplicate EOF event");
        SseDecoder tiny=new SseDecoder(3);tiny.accept("data: abc");check(tiny.finish().data.equals("abc"),"exact event size limit");
        rejects(IllegalArgumentException.class,()->tiny.accept("data: abcd"));
        SseDecoder small=new SseDecoder(3);small.accept("data: ab");rejects(IllegalArgumentException.class,()->small.accept("data: c"));
        rejects(IllegalArgumentException.class,()->new SseDecoder(2).accept("event: tool"));
        rejects(IllegalArgumentException.class,()->new SseDecoder(-1));
    }
    private static void streamBudget() throws Exception {
        StreamBudget b=new StreamBudget(4);b.add(1);b.add(3);check(b.used()==4,"cumulative budget exact edge");
        rejects(IllegalArgumentException.class,()->b.add(1));check(b.used()==4,"rejection cannot mutate budget");
        rejects(IllegalArgumentException.class,()->new StreamBudget(3).add(-1));
        rejects(IllegalArgumentException.class,()->new StreamBudget(-1));
        b.checkSlots(128,true);check(true,"existing tool fragments remain allowed at count cap");
        rejects(IllegalArgumentException.class,()->b.checkSlots(128,false));
        b.checkSlots(127,false);check(true,"last permitted tool slot");
    }
    private static void drafts() {
        DraftLifecycle d=new DraftLifecycle();
        check(!d.isLoaded()&&!d.mayPersist(),"unloaded empty composer is not a real empty draft");
        check(!d.hasEdits(),"caret/focus does not imply editing");
        d.markLoaded();check(d.isLoaded()&&d.mayPersist(),"loaded empty draft can legitimately be saved");
        DraftLifecycle typed=new DraftLifecycle();typed.markEdited();
        check(typed.hasEdits()&&typed.mayPersist()&&!typed.isLoaded(),"intentional new input can persist before slow load");
        typed.markLoaded();check(typed.hasEdits()&&typed.mayPersist(),"loading does not clear edit history");
    }
    private static void paths() throws Exception {
        check(GitHubPaths.contents("owner/repo","a#b?.kt","").equals("/repos/owner/repo/contents/a%23b%3F.kt"),"query and fragment are encoded filenames");
        check(GitHubPaths.contents("owner/repo","dir/a b+c%25.kt","feature/a b").equals("/repos/owner/repo/contents/dir/a%20b%2Bc%2525.kt?ref=feature%2Fa%20b"),"spaces, literal percent, plus and branch encoding");
        check(GitHubPaths.contents("owner/repo","файл.kt","").contains("%D1%84%D0%B0%D0%B9%D0%BB.kt"),"UTF-8 file path");
        check(GitHubPaths.contents("owner/repo","","").equals("/repos/owner/repo/contents/"),"root listing");
        check(GitHubPaths.repository("/owner/repo/").equals("owner/repo"),"existing slash tolerance");
        for(String bad:new String[]{"../x","a/../../x","a\\b","a\u0000b"})
            rejects(IllegalArgumentException.class,()->GitHubPaths.contents("owner/repo",bad,""));
        for(String bad:new String[]{"owner","owner/repo/other","../repo","owner/..","owner/repo?x","https://evil/repo"})
            rejects(IllegalArgumentException.class,()->GitHubPaths.repository(bad));
    }
    private static void contrast() {
        check(Math.abs(ContrastColors.contrast(0xff000000,0xffffffff)-21)<1e-9,"black/white contrast 21:1");
        check(ContrastColors.ink(0xff000000)==0xffffffff,"white on black");
        check(ContrastColors.ink(0xffffffff)==0xff000000,"black on white");
        check(ContrastColors.contrast(0xff19b8a6,0xffffffff)<4.5,"old green/white failure reproduced quantitatively");
        check(ContrastColors.contrast(0xff19b8a6,ContrastColors.ink(0xff19b8a6))>=4.5,"green contrast corrected");
        for(int r=0;r<256;r+=17)for(int g=0;g<256;g+=17)for(int b=0;b<256;b+=17){
            int color=0xff000000|(r<<16)|(g<<8)|b;
            check(ContrastColors.contrast(color,ContrastColors.ink(color))>=4.5,"opaque accent grid contrast");
        }
    }
    private static Path zip(Path root,String name,LinkedHashMap<String,byte[]> entries,boolean stored)throws Exception{
        Path out=root.resolve(name);
        try(ZipOutputStream z=new ZipOutputStream(Files.newOutputStream(out))){
            for(var item:entries.entrySet()){
                ZipEntry e=new ZipEntry(item.getKey());
                if(stored){CRC32 crc=new CRC32();crc.update(item.getValue());e.setMethod(ZipEntry.STORED);e.setSize(item.getValue().length);e.setCrc(crc.getValue());}
                z.putNextEntry(e);z.write(item.getValue());z.closeEntry();
            }
        }
        return out;
    }
    private static LinkedHashMap<String,byte[]> entries(Object... args){
        var map=new LinkedHashMap<String,byte[]>();for(int i=0;i<args.length;i+=2)map.put((String)args[i],(byte[])args[i+1]);return map;
    }
    private static long files(Path directory)throws IOException{try(var s=Files.list(directory)){return s.count();}}
    private static void archives() throws Exception {
        Path root=Files.createTempDirectory("sirius-zip-test-");Path out=Files.createDirectory(root.resolve("out"));
        try{
            byte[] payload=bytes("APK-BINARY-CONTENT-NOT-A-REAL-APK");
            Path valid=zip(root,"valid.zip",entries("notes.txt",bytes("readme"),"nested/../../escape.APK",payload),false);
            File apk=SafeApkExtractor.extract(valid.toFile(),out.toFile(),128,256,10,()->{});
            check(apk!=null&&apk.toPath().getParent().equals(out),"ZIP paths never escape destination");
            check(Arrays.equals(Files.readAllBytes(apk.toPath()),payload),"extracted bytes unchanged");
            check(!Files.exists(root.resolve("escape.APK")),"no remote filename writes outside root");
            File second=SafeApkExtractor.extract(valid.toFile(),out.toFile(),128,256,10,()->{});
            check(!second.equals(apk)&&Arrays.equals(Files.readAllBytes(apk.toPath()),payload),"repeated artifact cannot overwrite earlier APK");
            long count=files(out);
            Path big=zip(root,"big.zip",entries("app.apk",new byte[200]),false);
            rejects(BoundedIo.LimitExceededException.class,()->SafeApkExtractor.extract(big.toFile(),out.toFile(),16,256,10,()->{}));
            check(files(out)==count,"oversized APK leaves no partial file");
            Path bomb=zip(root,"ignored-bomb.zip",entries("ignored.txt",new byte[200],"app.apk",payload),false);
            rejects(BoundedIo.LimitExceededException.class,()->SafeApkExtractor.extract(bomb.toFile(),out.toFile(),128,32,10,()->{}));
            check(files(out)==count,"ignored entry cannot bypass expanded-size cap");
            Path aggregate=zip(root,"aggregate.zip",entries("a.txt",new byte[20],"b.txt",new byte[20],"app.apk",payload),false);
            rejects(BoundedIo.LimitExceededException.class,()->SafeApkExtractor.extract(aggregate.toFile(),out.toFile(),128,30,10,()->{}));
            Path many=zip(root,"many.zip",entries("a",new byte[0],"b",new byte[0],"app.apk",payload),false);
            rejects(IOException.class,()->SafeApkExtractor.extract(many.toFile(),out.toFile(),128,256,2,()->{}));
            Path empty=zip(root,"empty-apk.zip",entries("app.apk",new byte[0]),false);
            rejects(IOException.class,()->SafeApkExtractor.extract(empty.toFile(),out.toFile(),128,256,10,()->{}));
            check(files(out)==count,"empty APK leaves no output");
            Path noApk=zip(root,"no-apk.zip",entries("readme.md",bytes("hi")),false);
            check(SafeApkExtractor.extract(noApk.toFile(),out.toFile(),128,256,10,()->{})==null,"non-APK artifact remains non-installable");
            int[] ticks={0};
            rejects(CancellationException.class,()->SafeApkExtractor.extract(big.toFile(),out.toFile(),1024,2048,10,()->{if(++ticks[0]>=3)throw new CancellationException();}));
            check(files(out)==count,"cancellation removes unpublished output");
            Path crc=zip(root,"crc.zip",entries("app.apk",payload),true);
            byte[] raw=Files.readAllBytes(crc);int at=-1;
            outer:for(int i=0;i<=raw.length-payload.length;i++){for(int j=0;j<payload.length;j++)if(raw[i+j]!=payload[j])continue outer;at=i;break;}
            if(at<0)throw new AssertionError("fixture payload missing");raw[at]^=1;Files.write(crc,raw);
            rejects(ZipException.class,()->SafeApkExtractor.extract(crc.toFile(),out.toFile(),128,256,10,()->{}));
            check(files(out)==count,"bad CRC cannot publish a corrupt APK");
            Path truncated=zip(root,"truncated.zip",entries("app.apk",payload),true);
            byte[] raw2=Files.readAllBytes(truncated);Files.write(truncated,Arrays.copyOf(raw2,35));
            rejects(IOException.class,()->SafeApkExtractor.extract(truncated.toFile(),out.toFile(),128,256,10,()->{}));
            check(files(out)==count,"truncated entry cannot leave an installable-looking partial");
            rejects(IllegalArgumentException.class,()->SafeApkExtractor.extract(valid.toFile(),out.toFile(),1,1,0,()->{}));
            Path blocked=root.resolve("not-a-dir");Files.write(blocked,bytes("keep"));
            rejects(IOException.class,()->SafeApkExtractor.extract(valid.toFile(),blocked.toFile(),()->{}));
            check(Files.readString(blocked).equals("keep"),"non-directory output remains untouched");
        }finally{try(var walk=Files.walk(root)){for(Path p:walk.sorted(Comparator.reverseOrder()).toList())Files.deleteIfExists(p);}}
    }
}
