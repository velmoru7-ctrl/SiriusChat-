import com.sirius.chat.core.util.DictationText;
import com.sirius.chat.core.util.VoiceSession;

public final class VoiceInputRegression {
    private static int assertions;
    private static void check(boolean value, String label) {
        assertions++;
        if (!value) throw new AssertionError(label);
    }
    private static void rejects(Runnable action, String label) {
        boolean rejected=false;
        try { action.run(); } catch (IllegalArgumentException expected) { rejected=true; }
        check(rejected,label);
    }
    public static void main(String[] args) {
        VoiceSession a=new VoiceSession();
        check(!a.isActive() && !a.isClosed(), "idle without recording");
        check(!a.isCurrent(0), "zero never valid");
        long first=a.begin();
        check(first!=0 && a.isCurrent(first), "explicit request reserves one ticket");
        check(a.begin()==0, "duplicate click rejected");
        check(!a.finish(first+1) && a.isActive(), "foreign result does not consume active request");
        check(a.finish(first), "one result commits");
        check(!a.finish(first), "duplicate result cannot insert twice");
        check(!a.isCurrent(first), "interim after final ignored");
        long second=a.begin();
        check(second!=first && a.isCurrent(second), "second recording uses new ticket");
        a.cancel();
        check(!a.isActive() && !a.isCurrent(second), "cancel invalidates pending permission and speech");
        check(!a.finish(second), "late result after cancel ignored");
        long third=a.begin();
        check(third!=0 && third!=second, "restart after error or cancel");
        VoiceSession b=new VoiceSession(); long other=b.begin();
        check(other!=third, "different chat owner has different ticket");
        check(!a.isCurrent(other) && !b.isCurrent(third), "cross-chat ticket rejected both ways");
        a.close();
        check(a.isClosed() && !a.isActive(), "dispose closes owner");
        check(a.begin()==0 && !a.finish(third), "late grant after navigation cannot reopen microphone");
        a.close();a.cancel();
        check(a.isClosed() && a.begin()==0, "cleanup idempotent and does not reopen owner");
        check(b.finish(other), "closing old owner does not cancel current owner");
        for(int i=0;i<12;i++) {
            long ticket=b.begin();check(ticket!=0,"new explicit session "+i);
            b.cancel();check(!b.finish(ticket),"late callback after background "+i);
        }
        check(DictationText.append("", "Привет").equals("Привет"), "empty draft");
        check(DictationText.append("Hello", "world").equals("Hello world"), "separator inserted");
        check(DictationText.append("typed while listening", "new phrase").equals("typed while listening new phrase"), "latest typing preserved");
        check(DictationText.append("  keep prefix\n", "next").equals("  keep prefix\nnext"), "existing whitespace preserved");
        check(DictationText.append("Hello ", "world").equals("Hello world"), "no double separator");
        check(DictationText.append("Hello", "!").equals("Hello!"), "punctuation joins previous word");
        check(DictationText.append("\ud83d\udc68\u200d\ud83d\udc69\u200d\ud83d\udc67", "family").endsWith(" family"), "emoji draft preserved");
        check(DictationText.append("Cafe\u0301", "text").equals("Cafe\u0301 text"), "combining sequence preserved");
        check(DictationText.append("نص", "جديد").equals("نص جديد"), "RTL text kept logical");
        check(DictationText.append("draft", "\u00a0 \n").equals("draft"), "empty speech is a no-op");
        check(DictationText.append("draft", "\u2003hello\u00a0").equals("draft hello"), "Unicode speech-edge spaces");
        check(DictationText.append("", "x".repeat(8000)).length()==8000, "utterance exact bound");
        rejects(()->DictationText.append("", "x".repeat(8001)), "oversized utterance rejected");
        check(DictationText.append("x".repeat(199998), "y").length()==200000, "draft exact bound including separator");
        rejects(()->DictationText.append("x".repeat(199999), "y"), "draft overflow rejected, not truncated");
        check(DictationText.append("x".repeat(200001), "").length()==200001, "existing long draft never shortened by empty result");
        rejects(()->DictationText.append(null,"hello"), "null draft rejected");
        rejects(()->DictationText.append("hello",null), "null speech rejected");
        check(DictationText.preview(null).isEmpty(), "missing interim safe");
        check(DictationText.preview("x".repeat(2000)).length()==512, "preview bounded");
        String cut=DictationText.preview("x".repeat(511)+"\ud83d\ude00");
        check(cut.length()==511, "preview never exposes half emoji");
        check(DictationText.level(Float.NaN)==0, "NaN RMS ignored");
        check(DictationText.level(Float.POSITIVE_INFINITY)==0, "infinite RMS ignored");
        check(DictationText.level(Float.NEGATIVE_INFINITY)==0, "negative infinite RMS ignored");
        check(DictationText.level(-100)==0, "low RMS clamped");
        check(DictationText.level(100)==1, "high RMS clamped");
        check(Math.abs(DictationText.level(4)-0.5f)<0.0001f, "RMS uses real callback value");
        System.out.println("PASS: "+assertions+" voice-input production-Java assertions (owner tickets, cancel/replay, draft merge, Unicode, limits, RMS).");
    }
}
