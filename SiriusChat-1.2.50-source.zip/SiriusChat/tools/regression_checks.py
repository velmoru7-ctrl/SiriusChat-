#!/usr/bin/env python3
"""Source-contract and real SQLite/XML checks; NOT an Android runtime test."""
from pathlib import Path
import json
import re
import sqlite3
import xml.etree.ElementTree as ET

root = Path(__file__).resolve().parents[1]
kotlin = root / 'app/src/main/java/com/sirius/chat'
checks = []
def check(name, condition):
    if not condition:
        raise AssertionError(name)
    checks.append(name)
def read(name): return (kotlin / name).read_text()

# Every XML file must parse, and each locale must have unique string identifiers.
for path in (root/'app/src/main/res').rglob('*.xml'):
    ET.parse(path)
check('Resource XML parses', True)
locale_strings = {}
nontranslatable = set()
for locale in ('values', 'values-ru'):
    entries = {}
    for path in (root/'app/src/main/res'/locale).glob('*.xml'):
        for element in ET.parse(path).getroot():
            if element.tag != 'string': continue
            name = element.attrib['name']
            if locale == 'values' and element.attrib.get('translatable') == 'false': nontranslatable.add(name)
            check(f'{locale}: no duplicate {name}', name not in entries)
            entries[name] = ''.join(element.itertext())
    locale_strings[locale] = entries
check('EN/RU translatable string IDs match', locale_strings['values'].keys() - nontranslatable == locale_strings['values-ru'].keys() - nontranslatable)
fmt = re.compile(r'%(?:\d+\$)?[dsf]')
for name, value in locale_strings['values'].items():
    check(f'Format arguments: {name}', sorted(fmt.findall(value)) == sorted(fmt.findall(locale_strings['values-ru'].get(name, value))))

for locale, entries in locale_strings.items():
    check('No corrupted localization text: '+locale, all('\ufffd' not in value for value in entries.values()))

# Execute the actual DAO update statement against SQLite, rather than a hand-rewritten query.
dao = read('data/local/db/dao/Daos.kt')
query = re.search(r'UPDATE chat_sessions\s+SET title = :title,[\s\S]*?WHERE id = :id', dao).group()
columns = list(dict.fromkeys(re.findall(r'\b(\w+)\s*=\s*:\w+', query)))
con = sqlite3.connect(':memory:')
con.execute('CREATE TABLE chat_sessions (' + ', '.join('"'+c+'" '+('INTEGER' if c in ('memory','titleAuto','contextMeter','updatedAt','pinned','agentMode') else 'TEXT') for c in columns) + ')')
con.execute('INSERT INTO chat_sessions(id,memory,titleAuto) VALUES(?,?,?)', ('chat', 1, 0))
params = {name: '' for name in re.findall(r':(\w+)', query)}
params.update(id='chat', memory=0, titleAuto=1, contextMeter=-1, updatedAt=42, pinned=0, agentMode=1)
con.execute(query, params)
check('Actual DAO SQL persists memory off and automatic title', con.execute('SELECT memory,titleAuto FROM chat_sessions WHERE id=?', ('chat',)).fetchone() == (0,1))
check('Repository forwards memory to DAO', 'memory = encodeMeter(session.memory)' in read('data/repository/ChatRepositoryImpl.kt'))

# Contracts guarding the original reported bugs.
engine = read('ai/agent/AgentEngine.kt')
check('External actions have an approval gate', 'tool.requiresApproval && !requestToolApproval' in engine)
check('GitHub visibility has no public=true default', "'public' must explicitly be true or false" in read('ai/agent/tools/GitHubTools.kt'))
check('Missing content is rejected', 'else -> throw IllegalArgumentException("Missing or invalid' in read('ai/agent/AgentTool.kt'))
apply = read('domain/usecase/ApplyChangesUseCase.kt')
check('Proposals are bound to original tree', 'change.treeUri == treeUri' in apply)
check('Optimistic conflict check uses full original', 'workspace.readTextExact(tree, node.documentId) == original' in apply)
check('Moves use native binary-safe path', 'return workspace.move(' in apply)
repo = read('data/repository/WorkspaceRepositoryImpl.kt')
check('Copy failure returns before deleting source', 'val copied = copy(treeUri, documentId, targetParentId) ?: return@withContext null' in repo)
check('Production repository uses tested verified transfer', 'com.sirius.chat.core.util.VerifiedStreams.copy(' in repo)
commit = read('data/preview/SandboxCommitter.kt')
write = commit.split('private fun applyWrite',1)[1].split('private fun applyCreate',1)[0]
check('Undo for failing file is registered before write', write.index('journal += Undo.Restore') < write.index('writeBytes(target, bytes)'))
check('Rollback runs despite cancellation', 'withContext(NonCancellable + Dispatchers.IO) { rollback(done) }' in commit)
check('Editor saves submitted snapshot', 'it.copy(savedContent = submitted)' in read('feature/editor/EditorViewModel.kt'))
check('Dirty tabs require explicit discard', 'if (tab.dirty && !discardUnsaved) return' in read('data/repository/EditorSessionStore.kt'))
check('Preview uses scoped sandbox', 'previewController.sandboxFor(session.id, project?.treeUri)' in read('ai/agent/GenerationManager.kt'))
check('No hardcoded /data dependency in self-test', not re.search(r'^[^#\n]*[\"\']/data/', (root/'tools/kselftest.py').read_text(), re.M))
for source in ('ai/provider/HttpClientProvider.kt','data/image/ImageGenerationService.kt','data/web/WebSearchService.kt','data/github/GitHubService.kt'):
    check('HTTP policy covers '+source, 'addInterceptor(com.sirius.chat.ai.provider.LanHttpPolicy.interceptor)' in read(source) and 'addNetworkInterceptor(com.sirius.chat.ai.provider.LanHttpPolicy.interceptor)' in read(source))
check('LAN opt-in defaults off', 'val allowLanHttp: Boolean = false' in read('domain/model/AppSettings.kt'))
check('No transparent unmetered provider retries', '.retryOnConnectionFailure(false)' in read('ai/provider/HttpClientProvider.kt'))
check('Each retry is metered internally', 'RetryingProvider(com.sirius.chat.ai.pricing.MeteredProvider(provider, usageLedger))' in read('ai/provider/ProviderFactory.kt'))
for source, purpose in [('ai/context/ContextCompactor.kt','compaction'),('ai/context/SessionTitler.kt','title'),('ai/memory/MemoryExtractor.kt','memory')]:
    check(purpose+' accounted separately', 'request.copy(purpose = "'+purpose+'")' in read(source))
check('Images are metered at native and fallback routes', read('data/image/ImageGenerationService.kt').count('ledger.imageCall(') == 5)
check('Ledger persists atomically', 'file.finishWrite(stream)' in read('ai/pricing/UsageLedger.kt'))
check('Unknown charges stop budgeted tasks', 'if (task.budgetUsd > 0.0)' in read('ai/pricing/UsageLedger.kt') and 'unknown ->' in read('ai/pricing/UsageLedger.kt'))
check('All five particle styles exist', all(f'{index} ->' in read('core/designsystem/effects/TextReveal.kt') for index in (1,2,3,4)))
check('Animation never rewrites IME offsets', 'OffsetMapping.Identity' in read('core/designsystem/effects/TextReveal.kt'))
check('Composer has one explicit scroll', '.verticalScroll(inputScroll)' in read('feature/chat/components/ChatInputBar.kt'))
check('No opaque DEX loader in animation', 'InMemoryDexClassLoader' not in read('core/designsystem/effects/TextReveal.kt'))
check('Complete animation settings are persisted', 'TextAnimationSettings.serializer(), updated.textAnimation.coerced()' in read('data/local/preferences/SettingsDataStore.kt'))
for source_file in kotlin.rglob('*.kt'):
    check('No simple interface code: '+source_file.name, not re.search(r'simpleMode|simple_mode|SimpleHomeScreen', source_file.read_text()))
check('No simple interface screen remains', not (kotlin/'feature/home/SimpleHomeScreen.kt').exists())
check('Full navigation is unconditional', 'val destinations = TopLevelDestination.entries' in read('core/navigation/SiriusBottomBar.kt'))
chat_screen = read('feature/chat/ChatScreen.kt')
chat_vm = read('feature/chat/ChatViewModel.kt')
menu = read('core/designsystem/components/MorphMenu.kt')
bubble = read('feature/chat/components/MessageBubble.kt')
check('No permanent task-cost strip', 'TaskCostCard(' not in chat_screen)
check('Cost details are on demand', 'if (showUsage)' in chat_screen and 'TaskUsageSheet(' in chat_screen)
check('Native anchored menu replaces custom popup', 'DropdownMenu(' in menu and 'MutableTransitionState' not in menu)
check('A menu can only dispatch once per opening', 'expanded && item.enabled && !consumed' in menu)
check('Message content has no entry opacity gate', 'alpha = entry' not in bubble and 'var arrived' not in bubble)
message_actions = bubble.split('private fun MessageActionsButton(', 1)[1].split('/** Compact transcript', 1)[0]
check('Open and closed message-menu icons retain surface ink', 'tint = tint,' in message_actions)
check('Open icon never switches to the bubble fill', 'tint = if (open) colors.primary else tint' not in message_actions)
check('Message action target remains 48dp', '.size(48.dp)' in message_actions)
check('User metadata row has an extra spacing token', 'Modifier.align(Alignment.End).padding(top = SiriusSpacing.xs)' in bubble)

check('No immediate last-message delete path', 'if (following == 0)' not in chat_screen)
check('Delete dialog has a real cancel button', 'TextButton(onClick = { pendingDelete = null })' in chat_screen)
check('History-changing menus are disabled while busy', 'historyActionsEnabled = historyActionsEnabled' in chat_screen)
check('Mutation admission precedes asynchronous writes', '_historyBusy.compareAndSet(false, true)' in chat_vm)
check('Cancelling editing restores the previous draft', 'draftBeforeEdit = ComposerSnapshot' in chat_vm and 'restoreDraftAfterEdit()' in chat_vm)
check('Initial draft load cannot overwrite new typing', 'inputRevision == revisionBeforeLoad' in chat_vm)
check('No unscoped memory task in chat screen model', 'memoryExtractor.learn' not in chat_vm)
check('Bulk deletion never falls back to arbitrary IDs', 'if (ordered.isEmpty()) messageIds.toList()' not in chat_vm)
check('Single deletion also uses scoped repository writes', 'container.chatRepository.deleteMessage(' not in chat_vm)
check('Settings Back closes the panel', 'BackHandler(enabled = visible, onBack = onDismiss)' in read('feature/chat/components/ChatSettingsPanel.kt'))
usage_screen = read('feature/settings/UsageSettingsScreen.kt')
check('Late saved prices refresh untouched fields', 'LaunchedEffect(providerId, model, savedRule)' in usage_screen and 'if (!priceDirty)' in usage_screen)
check('Budget save is awaited before success', 'container.settingsRepository.update { it.copy(taskBudgetUsd = value) }' in usage_screen)
for transaction_name in ('truncateInSession','replaceFromInSession','deleteSelectionInSession'):
    check('Room transaction: '+transaction_name, bool(re.search(r'@Transaction\s+suspend fun '+transaction_name+r'\(', dao)))

# Execute the actual scoped DELETE SQL with collection bindings expanded like Room.
scoped_sql = re.search(r'@Query\("(DELETE FROM chat_messages WHERE sessionId = :sessionId AND id IN \(:ids\))"\)', dao).group(1)
history_db = sqlite3.connect(':memory:')
history_db.execute('CREATE TABLE chat_messages(id TEXT PRIMARY KEY, sessionId TEXT, content TEXT NOT NULL, createdAt INTEGER)')
history_db.executemany('INSERT INTO chat_messages VALUES(?,?,?,?)', [('a','chat-a','Question',42),('b','chat-a','Answer',42),('x','chat-b','Other chat',42)])
history_db.commit()
def scoped_delete(session, ids):
    if not ids: return
    sql = scoped_sql.replace(':sessionId','?').replace(':ids',','.join('?' for _ in ids))
    history_db.execute(sql, (session,*ids))
scoped_delete('chat-a',['x','b'])
check('Actual scoped SQL keeps foreign messages', history_db.execute('SELECT id FROM chat_messages ORDER BY id').fetchall()==[('a',),('x',)])
history_db.rollback()
check('Transaction rollback restores removed messages', history_db.execute('SELECT id FROM chat_messages ORDER BY id').fetchall()==[('a',),('b',),('x',)])
try:
    with history_db:
        scoped_delete('chat-a',['a','b'])
        history_db.execute('INSERT INTO chat_messages VALUES(?,?,?,?)',('replacement','chat-a',None,43))
except sqlite3.IntegrityError:
    pass
check('Failed replacement does not leave empty history in transaction', history_db.execute('SELECT id FROM chat_messages ORDER BY id').fetchall()==[('a',),('b',),('x',)])

signing_build = (root/'app/build.gradle.kts').read_text()
check('Release falls back to a signed local test APK', 'signingConfigs.getByName("debug")' in signing_build)
check('Local signing is disclosed as test-only', 'Sirius LOCAL TEST SIGNING:' in signing_build and 'Not for publication.' in signing_build)
check('Configured release key is preferred', 'signingConfigs.getByName("release")' in signing_build)
check('Incomplete credentials never silently fall back', 'Incomplete keystore.properties:' in signing_build and 'missing.isNotEmpty()' in signing_build)
check('Signing file must exist', 'keystoreProperties.getProperty("storeFile")).isFile' in signing_build)
check('Strict signing can refuse the test key', '!hasReleaseKeystore && !allowLocalTestSigning' in signing_build)
check('Release never selects a null signing config', 'else {\n                null\n            }' not in signing_build)
check('CI verifies signatures before uploading APKs', 'python3 tools/verify_apk.py app/build/outputs/apk' in (root/'.github/workflows/sirius-apk.yml').read_text())

# Regression for the actual Kotlin compiler error reported on the device.
transform = read('core/designsystem/effects/TextReveal.kt')
check('Letter particle transform explicitly supplies both scale axes',
      'scale(scaleX = factor, scaleY = factor, pivot = pos)' in transform)
check('Broken one-axis DrawTransform call is absent',
      'scale((config.particleSize / 50f)' not in transform)

# Catch syntactically malformed imports, which the lightweight checker does not parse.
import_pattern = re.compile(r'^import (?:[\w`]+\.)*(?:[\w`]+|\*)(?: as [\w`]+)?$')
for path in kotlin.rglob('*.kt'):
    for line in path.read_text().splitlines():
        if line.startswith('import '):
            check('Valid import '+str(path.relative_to(kotlin)), bool(import_pattern.fullmatch(line.strip())))


# 1.2.49 source integration contracts. These do not claim native layout/network execution.
user_part = bubble.split('if (message.isFromUser) {',1)[1].split('        } else {',1)[0]
check('Short user bubble has a compact trailing footer', 'Modifier.align(Alignment.End)' in user_part)
check('Footer no longer has expanding spacer', 'Spacer(Modifier.weight(1f))' not in user_part)
check('Natural user bubbles retain width cap', '.widthIn(max = 320.dp)' in user_part)
check('No intrinsic measurement of popup content', 'IntrinsicSize' not in user_part)
check('Long model names cannot push menu away', 'modifier = Modifier.weight(1f),\n                        maxLines = 1' in bubble)
attachment = read('data/attachment/AttachmentReader.kt')
check('Attachment reads enforce limits before allocating all input', 'BoundedIo.readBytes(stream' in attachment and 'stream.readBytes()' not in attachment)
check('MIME classification no longer defaults to PNG', 'MediaTypes.isSupportedImage(type)' in attachment and 'normalizeImageType(type) in' not in attachment)
check('Image payload encoding follows bytes, not untrusted MIME', 'MediaTypes.detectImageType(bytes)' in attachment)
check('Text attachments do not silently replace invalid UTF-8', 'BoundedIo.utf8(bytes)' in attachment)
check('Attachment truncation cannot split surrogate pairs', 'BoundedIo.prefix(full, maxTextChars)' in attachment)
check('Attachment cancellation propagates', 'catch (cancel: CancellationException)' in attachment)
check('Unloaded draft placeholder cannot erase saved text', 'if (!draftLifecycle.mayPersist()) return@withLock' in chat_vm)
check('History edit waits for draft load', 'if (!draftLifecycle.isLoaded())' in chat_vm)
check('Message upsert preserves rowid', '@Upsert\n    suspend fun upsertMessage' in dao)
check('Both session previews use display-order tie breaker', dao.count('ORDER BY m2.createdAt DESC, m2.rowid DESC LIMIT 1') == 2)
relay = read('core/network/CancellableCalls.kt')
check('Cancellation relay is a child job', 'Job(parent).also' in relay and 'if (cause != null) this.cancel()' in relay)
check('HTTP response closure completes relay', 'finally {\n        relay.complete()' in relay)
for provider in ['ai/provider/OpenAiCompatibleProvider.kt','ai/provider/AnthropicProvider.kt']:
    source=read(provider)
    check('Socket cancellation before blocked parent completion: '+provider, 'call.cancellationRelay(' in source and 'cancellation.complete()' in source)
    check('Non-streaming response is bounded: '+provider, 'val text = source.readUtf8()' not in source and 'readLimitedText()' in source)
    check('Accumulated response has a budget: '+provider, 'val streamBudget = StreamBudget()' in source and 'streamBudget.add(' in source)
check('Anthropic terminal error cannot emit success next', 'if (terminalError) return@use' in read('ai/provider/AnthropicProvider.kt'))
for client in ['ai/provider/HttpClientProvider.kt','data/image/ImageGenerationService.kt']:
    check('Cross-origin request guard: '+client, 'addNetworkInterceptor(' in read(client) and 'CredentialRedirectGuard.interceptor' in read(client))
redirect = read('ai/provider/CredentialRedirectGuard.kt')
check('Guard protects prompt bodies even without a key', 'initial.body != null' in redirect)
check('Guard compares original URL against every redirect', 'chain.call().request()' in redirect and 'RequestOrigin.same(' in redirect)
check('Credential refusal is not retried as network outage', 'is CredentialRedirectException' in read('ai/provider/ProviderErrors.kt'))
image = read('data/image/ImageGenerationService.kt')
store = read('data/image/GeneratedImageStore.kt')
check('Images use cancellable request lifetime', 'useCancellableResponse' in image and '.execute().use' not in image)
check('Images avoid nested blocking coroutine', 'runBlocking' not in image)
check('Image downloads are bounded', 'readImageBody(response.body)' in image and '.body?.bytes()' not in image)
check('Base64 size is checked before decoding', image.index('val encodedLimit') < image.index('val bytes = Base64.decode(payload'))
check('Image storage failure does not buy a fallback image', 'if (error is ImageStorageException) throw error' in image)
check('Images have unique names and atomic writes', 'UUID.randomUUID()' in store and 'AtomicFile(file)' in store and 'atomic.finishWrite(stream)' in store)
check('Image suffix describes actual encoding', 'MediaTypes.imageExtension(bounds.outMimeType)' in store)
check('Fresh image is never pruned', 'if (file == keep) continue' in store)
check('Failed deletion does not count as freed storage', 'if (file.delete()) total -= length' in store)
check('Legacy edit input MIME is detected', 'imageMime(source)' in image and '"source" + MediaTypes.imageExtension(mime)' in image)
github = read('data/github/GitHubService.kt'); gitvm=read('feature/github/GitHubViewModel.kt')
check('GitHub text and revision come from same response', 'GitHubFileVersion(text, sha)' in github)
check('GitHub editor saves expected original SHA', 'expectedSha = open.sha' in gitvm)
check('GitHub save preserves newer typing', 'latest.copy(original = open.content, sha = receipt.blobSha)' in gitvm and 'openFile = open.copy(original = open.content)' not in gitvm)
check('GitHub update cannot reopen old file', 'latest != null && latest.repo == repo' in gitvm and 'latest.sha == open.sha' in gitvm)
check('GitHub mutations have synchronous admission', gitvm.index('if (_state.value.busy.isNotBlank()) return', gitvm.index('private fun operation(')) < gitvm.index('operationJob = viewModelScope.launch'))
check('Cancelled operation cannot clear new operation state', 'if (serial == operationSerial)' in gitvm)
check('GitHub archives unpack off main dispatcher', 'withContext(container.dispatchers.io)' in gitvm and 'SafeApkExtractor.extract' in gitvm)
check('Remote artifact names are not paths', '${artifact.name}.zip' not in gitvm and 'artifact-${artifact.id}.zip' in gitvm)
check('GitHub downloads are bounded and staged', 'BoundedIo.copy(input, output, limit)' in github and 'pending.renameTo(destination)' in github)
check('GitHub failures do not masquerade as file absence', 'if (error.status == 404)' in github and 'runCatching { get(contentsUrl' not in github)
check('File creation is race-safe create-only', 'expectedSha = ""' in gitvm and 'expectedSha = ""' in github)
check('GitHub writes and deletes encode the path', 'put(contentsUrl(fullName, clean, ""), payload)' in github and 'delete(contentsUrl(fullName, clean, ""), payload)' in github)
check('Shared contents URL uses tested encoder', 'GitHubPaths.contents(fullName, path, ref)' in github)
check('Custom existing workflow is not overwritten', 'it was not overwritten.' in github)
check('GitHub unsaved edits require confirmation', 'pendingDiscard' in read('feature/github/GitHubScreen.kt') and 'github_discard_local_body' in read('feature/github/GitHubScreen.kt'))
check('Accent ink uses actual contrast ratios', 'ContrastColors.ink(tint.toArgb())' in read('core/designsystem/SiriusPalette.kt'))
check('Tiny context no longer reports zero', 'clamped > 0f && clamped < 0.01f' in read('feature/chat/components/ContextMeter.kt'))
check('Invalid context values cannot reach layout fraction', 'val known = fill.isFinite()' in read('feature/chat/components/ContextMeter.kt'))
check('Sequential version increment', 'versionCode = 59' in signing_build and 'versionName = "1.2.50"' in signing_build)

check('SSE line reader uses the executed bounded production class', 'SseLines(source.inputStream()' in read('ai/streaming/SseParser.kt'))
check('GitHub side effects have no transparent replay', '.retryOnConnectionFailure(false)' in github)

# Real SQLite demonstration: updating a row must preserve equal-timestamp display order.
order_db=sqlite3.connect(':memory:')
order_db.executescript('CREATE TABLE chat_messages(id TEXT PRIMARY KEY, sessionId TEXT, content TEXT, createdAt INTEGER);')
order_db.executemany('INSERT INTO chat_messages VALUES(?,?,?,?)',[('u','s','user',42),('a','s','assistant',42)])
ordered_sql=re.search(r'@Query\("(SELECT \* FROM chat_messages WHERE sessionId = :sessionId ORDER BY createdAt ASC, rowid ASC)"\)',dao).group(1)
order=lambda:[r[0] for r in order_db.execute(ordered_sql,{'sessionId':'s'})]
check('Actual message-order SQL starts in insertion order',order()==['u','a'])
order_db.execute('UPDATE chat_messages SET content=? WHERE id=?',('edited','u'))
check('In-place update preserves equal-timestamp order',order()==['u','a'])
preview_sql=re.search(r'SELECT m2.content FROM chat_messages m2 WHERE m2.sessionId = s.id\s+ORDER BY m2.createdAt DESC, m2.rowid DESC LIMIT 1',dao).group(0).replace('s.id',':sessionId')
check('Actual preview SQL agrees with last displayed message',order_db.execute(preview_sql,{'sessionId':'s'}).fetchone()[0]=='assistant')
order_db.execute('INSERT OR REPLACE INTO chat_messages VALUES(?,?,?,?)',('u','s','replaced',42))
check('Old REPLACE ordering defect is actually reproducible',order()==['a','u'])


# The recent-file key is (documentId, projectId), not documentId alone.
position_sql=re.search(r'@Query\("(UPDATE recent_files SET caretOffset = :caret, scrollLine = :line WHERE documentId = :documentId AND projectId = :projectId)"\)',dao).group(1)
position_db=sqlite3.connect(':memory:')
position_db.executescript('CREATE TABLE recent_files(documentId TEXT, projectId TEXT, caretOffset INTEGER, scrollLine INTEGER, PRIMARY KEY(documentId,projectId)); INSERT INTO recent_files VALUES("same","one",1,2),("same","two",3,4);')
position_db.execute(position_sql,dict(documentId='same',projectId='one',caret=10,line=20))
check('Actual file-position SQL only touches selected project',position_db.execute('SELECT projectId,caretOffset,scrollLine FROM recent_files ORDER BY projectId').fetchall()==[('one',10,20),('two',3,4)])
check('Repository forwards project and clamps negative positions','dao.updateFilePosition(documentId, projectId, caretOffset.coerceAtLeast(0), scrollLine.coerceAtLeast(0))' in read('data/repository/ProjectRepositoryImpl.kt'))


# Voice/composer integration: these are source contracts, not Android microphone tests.
voice=read('data/voice/SpeechInputController.kt')
voice_ui=read('feature/chat/components/ChatVoiceInput.kt')
input_ui=read('feature/chat/components/ChatInputBar.kt')
preview=read('feature/chat/components/PendingAttachmentPreview.kt')
settings=read('data/local/preferences/SettingsDataStore.kt')
manifest=ET.parse(root/'app/src/main/AndroidManifest.xml').getroot()
android='{http://schemas.android.com/apk/res/android}'
check('Microphone permission declared once',sum(e.get(android+'name')=='android.permission.RECORD_AUDIO' for e in manifest.findall('uses-permission'))==1)
check('Speech service is visible on Android 11+',any(e.get(android+'name')=='android.speech.RecognitionService' for e in manifest.findall('./queries/intent/action')))
check('Microphone hardware is optional',any(e.get(android+'name')=='android.hardware.microphone' and e.get(android+'required')=='false' for e in manifest.findall('uses-feature')))
check('No background microphone service added',all('microphone' not in e.get(android+'foregroundServiceType','') for e in manifest.findall('./application/service')))
check('Engine starts only after microphone permission check','ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO)' in voice and 'engine.startListening(intent)' in voice)
check('On-device engine uses API guard','Build.VERSION.SDK_INT >= Build.VERSION_CODES.S' in voice and 'createOnDeviceSpeechRecognizer' in voice)
check('No silent network mode switch','!request.onDevice && !request.systemApproved' in voice and 'if (request.onDevice' in voice)
check('No fake voice words or signal','simulateText' not in voice_ui+voice and 'demoTextInterval' not in voice_ui+voice and 'Math.random' not in voice_ui+voice)
check('Real RMS is bounded by tested helper','DictationText.level(rmsdB)' in voice)
check('Interim speech is preview only','override fun onPartialResults' in voice and 'DictationText.preview(firstResult(partialResults))' in voice)
check('Exactly one final result may insert','if (!gate.finish(request.ticket)) return' in voice and 'appendFinal(text)' in voice)
check('Recorder has startup/capture/result deadlines','START_TIMEOUT_MS = 10_000L' in voice and 'MAX_CAPTURE_MS = 60_000L' in voice and 'RESULT_TIMEOUT_MS = 8_000L' in voice)
check('Gate invalidated before engine cleanup',voice.index('gate.cancel() // invalidate') < voice.index('cleanup(cancel = true)',voice.index('fun cancel()')))
check('Native engine released','engine?.destroy()' in voice)
check('Background/dispose stop recording','Lifecycle.Event.ON_STOP' in voice_ui and 'Lifecycle.Event.ON_PAUSE' in voice_ui and 'controller.close()' in voice_ui)
check('Permission launch is isolated per owner','val permission = key(controller)' in voice_ui and 'pendingPermission by remember(controller)' in voice_ui)
check('Permission result waits for foreground','lifecycle.withResumed' in voice_ui and 'controller.current(request)' in voice_ui)
check('Voice result uses current rather than captured draft','DictationText.append(_input.value, text)' in chat_vm and 'expectedEpoch == _composerEpoch.value' in chat_vm)
check('Dictation cannot beat initial draft read','_draftReady.value && expectedEpoch' in chat_vm and '_draftReady.value = session != null' in chat_vm)
check('History operations invalidate dictated text scope','_composerEpoch.value++' in chat_vm[chat_vm.index('private fun launchHistoryAction'):])
check('Final speech does not auto-send','viewModel.send(' not in voice_ui and 'onSend(' not in voice_ui)
check('Style and consent round-trip by stable names','prefs[Keys.composerStyle] = updated.composerStyle.name' in settings and 'composerStyle = enumOrDefault' in settings and 'prefs[Keys.systemVoiceAllowed] = updated.systemVoiceAllowed' in settings)
check('Safe style and consent defaults','val composerStyle: ComposerStyle = ComposerStyle.Classic' in read('domain/model/AppSettings.kt') and 'val systemVoiceAllowed: Boolean = false' in read('domain/model/AppSettings.kt'))
check('New settings route is wired','composable(Routes.SETTINGS_INTERFACE)' in read('SiriusApp.kt') and 'onOpenInterface' in read('feature/settings/SettingsScreen.kt'))
check('Style writes report failure and prevent duplicate writes','_interfaceBusy.compareAndSet(false, true)' in read('feature/settings/SettingsViewModel.kt') and 'interface_save_failed' in read('feature/settings/SettingsViewModel.kt'))
check('Both styles share one native text editor',input_ui.count('BasicTextField(')==1 and 'composerStyle == ComposerStyle.Prompt' in input_ui)
check('Typing animation remains attached to native field','visualTransformation = revealTransformation' in input_ui and 'TextRevealOverlay(' in input_ui)
check('Voice collection stays out of transcript keystrokes','voice.controller.state.collectAsStateWithLifecycle()' in input_ui and 'input = viewModel.input' in read('feature/chat/ChatScreen.kt'))
check('Message send waits for dictation to finish','!voiceState.active && hasPayload' in input_ui)
check('Primary Prompt action uses contrasting ink','if (promptStyle && armed) colors.onPrimary' in input_ui)
check('Narrow/large-font layouts separate selectors','splitControls' in input_ui and 'fontScale > 1.3f' in input_ui)
check('Composer honours reduced-motion helpers','animateContentSize(animationSpec = siriusTween(' in input_ui)
check('Attachment preview does not fetch remote URLs','uri.scheme != "content"' in preview and 'http' not in preview.lower())
check('Preview bounds bytes and decoded pixels','BoundedIo.readBytes(it, PREVIEW_MAX_BYTES)' in preview and '64_000_000L' in preview and 'maxSide.coerceIn(64, 1536)' in preview)
check('Preview work is off main and bounded concurrently','withContext(Dispatchers.IO)' in preview and 'Semaphore(2)' in preview)
check('Attachment remove is not hover-only','IconButton(onClick = onRemove, modifier = Modifier.size(48.dp))' in preview)
check('Current UI settings contain only implemented choices','ComposerStyle.entries.forEach' in read('feature/settings/InterfaceSettingsScreen.kt'))

print(json.dumps({'passed': len(checks), 'kind': 'source contracts + real SQLite + XML; not Android runtime', 'summary': 'PASS'}, ensure_ascii=False, indent=2))
