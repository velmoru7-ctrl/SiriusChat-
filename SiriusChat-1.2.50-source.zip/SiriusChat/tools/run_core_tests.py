#!/usr/bin/env python3
"""Compile and run actual dependency-free production helpers with JDK 17+."""
from pathlib import Path
import shutil
import subprocess
import tempfile

root = Path(__file__).resolve().parents[1]
base = root / 'app/src/main/java/com/sirius/chat'
sources = sorted((base / 'core/util').glob('*.java'))
sources += sorted((base / 'ai').rglob('*.java'))
sources += sorted((root / 'tests/portable').glob('*.java'))
java = shutil.which('java')
if not java:
    raise SystemExit('JDK 17+ required: java was not found.')
compiler = [shutil.which('javac')] if shutil.which('javac') else [java, '-m', 'jdk.compiler/com.sun.tools.javac.Main']
with tempfile.TemporaryDirectory(prefix='sirius-core-tests-') as directory:
    subprocess.run(compiler + ['--release', '17', '-encoding', 'UTF-8', '-d', directory] + [str(p) for p in sources], check=True)
    for suite in ('CoreRegression', 'ReliabilityRegression', 'VoiceInputRegression'):
        subprocess.run([java, '-ea', '-cp', directory, suite], check=True)
