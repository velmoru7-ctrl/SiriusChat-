#!/usr/bin/env python3
"""Verify APKs cryptographically using Android SDK apksigner. Never sign or alter APKs."""
from pathlib import Path
import argparse
import os
import re
import shutil
import subprocess
import sys


def find_signer(explicit=None):
    if explicit:
        candidate = shutil.which(explicit)
        return Path(candidate) if candidate else None
    command = shutil.which('apksigner')
    if command:
        return Path(command)
    roots = [Path(value) for key in ('ANDROID_SDK_ROOT', 'ANDROID_HOME')
             if (value := os.environ.get(key))]
    properties = Path(__file__).resolve().parents[1] / 'local.properties'
    if properties.is_file():
        for line in properties.read_text(errors='replace').splitlines():
            if line.strip().startswith('sdk.dir='):
                value = line.strip().split('=', 1)[1].replace('\\:', ':').replace('\\ ', ' ').replace('\\\\', '\\')
                path = Path(value)
                roots.append(path if path.is_absolute() else properties.parent / path)
    roots.extend((Path.home() / 'Android/Sdk', Path.home() / 'Library/Android/sdk'))
    candidates = []
    for root in roots:
        for pattern in ('*/apksigner', '*/apksigner.bat'):
            candidates.extend(p for p in (root / 'build-tools').glob(pattern)
                              if p.is_file() and (os.name == 'nt' or os.access(p, os.X_OK)))
    return max(candidates, key=lambda p: tuple(map(int, re.findall(r'\d+', p.parent.name))), default=None)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('paths', nargs='+', help='APK files or build output directories')
    parser.add_argument('--apksigner', default=os.environ.get('APKSIGNER'), help='Path to Android SDK apksigner')
    args = parser.parse_args()
    apks = set()
    for name in args.paths:
        path = Path(name)
        if path.is_dir():
            apks.update(p.resolve() for p in path.rglob('*.apk') if p.is_file())
        elif path.is_file() and path.suffix.lower() == '.apk':
            apks.add(path.resolve())
        else:
            print(f'APK input not found: {path}', file=sys.stderr)
            return 2
    if not apks:
        print('No APK files found; signature verification did not run.', file=sys.stderr)
        return 2
    signer = find_signer(args.apksigner)
    if not signer:
        print('Android SDK apksigner not found. Install Build Tools or set --apksigner. Nothing was verified.', file=sys.stderr)
        return 2
    for apk in sorted(apks):
        print(f'\nVerifying {apk.name}', flush=True)
        try:
            result = subprocess.run([str(signer), 'verify', '--verbose', '--print-certs', str(apk)], timeout=120)
        except (OSError, subprocess.TimeoutExpired) as error:
            print(f'Signature verification could not complete: {error}', file=sys.stderr)
            return 2
        if result.returncode:
            print(f'FAILED: {apk.name}. Do not distribute/install this output. Clean old unsigned outputs and rebuild.', file=sys.stderr)
            return 1
    print(f'PASS: {len(apks)} APK signature(s) verified by apksigner.')
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
