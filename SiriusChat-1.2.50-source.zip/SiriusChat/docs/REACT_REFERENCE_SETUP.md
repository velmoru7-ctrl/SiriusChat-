# React-референс и отдельная web-сборка

## Почему TSX не вставлен в Android

Текущий Sirius — **Kotlin + Jetpack Compose**, Gradle, Android resources. React, shadcn/ui, Tailwind и TypeScript не являются его UI-движком. Положить .tsx в Android-папку не означает интегрировать компонент; Gradle его не отрисует. Перевод всего приложения или WebView-мост микрофона не были нужны для запроса, поэтому добавлен нативный вариант Prompt.

Присланный фрагмент `ai-chat-input.tsx` обрывается на `recognition.onerror` / `console.error("Speech recognition error", e)`. Не хватает конца обработчиков, основной return-JSX и закрытия forwardRef. Он не является законченным компилируемым компонентом. Буквально копировать эту обрезанную часть как рабочую .tsx было бы ошибкой. Завершённая React-копия в этом архиве **не заявляется**.

Нативные пути:

```text
app/src/main/java/com/sirius/chat/feature/chat/components/
    ChatInputBar.kt
    ChatVoiceInput.kt
    PendingAttachmentPreview.kt
app/src/main/java/com/sirius/chat/data/voice/SpeechInputController.kt
app/src/main/java/com/sirius/chat/feature/settings/InterfaceSettingsScreen.kt
app/src/main/java/com/sirius/chat/core/designsystem/   # палитра, типографика, движения
app/src/main/res/values*/strings.xml                 # локализация
```

## Если потребуется отдельный React/Next.js проект

Ниже **инструкции**, а не команды, выполненные над Android-проектом. Запускай в отдельной папке, с Node/npm и доступом к пакетам. Версии latest нужно проверить и зафиксировать lockfile перед реальным релизом.

```sh
npx create-next-app@latest sirius-composer-web --typescript --tailwind --eslint --app --no-src-dir --import-alias "@/*"
cd sirius-composer-web
npx shadcn@latest init
npx shadcn@latest add button dialog dropdown-menu
mkdir -p components/ui
```

Так TypeScript и Tailwind устанавливаются при создании Next.js, а shadcn задаёт дизайн-токены, утилиту cn и структуру компонентов. Выбор `--no-src-dir` нужен, чтобы путь был именно `<корень проекта>/components/ui`, а не `src/components/ui`.

Ожидаемые пути в **этом отдельном web-проекте**:

```text
components/ui/ai-chat-input.tsx
lib/utils.ts
app/globals.css
app/page.tsx
components.json
tsconfig.json
```

Проверь в `components.json`:

```json
{
  "aliases": {
    "components": "@/components",
    "ui": "@/components/ui",
    "utils": "@/lib/utils"
  },
  "tailwind": { "css": "app/globals.css" }
}
```

Это фрагмент конфигурации, не замена всех настроек CLI. Папка components/ui важна для согласованности alias, дальнейших shadcn add-команд и импорта `@/components/ui/ai-chat-input`; она не обладает специальным значением для Android. Если в существующем web-проекте используется `src/`, либо оставь `src/components/ui` с корректным alias, либо согласованно измени aliases и tsconfig — простого перемещения одного файла недостаточно.

После получения **полного** компонента файл располагается в components/ui/ai-chat-input.tsx, страница импортирует `PromptInput`. Подключи его onSubmit к реальному backend, а не к фиктивному ответу. Проверь:

- при отказе микрофона нет fakeText/simulateText;
- URL.createObjectURL освобождаются при удалении/размонтировании;
- SpeechRecognition/MediaStream/AudioContext останавливаются при закрытии и ошибках;
- промежуточные результаты не затирают свежий ручной ввод;
- кнопки удаления доступны с клавиатуры/тача и не вложены друг в друга;
- Dialog имеет имя, focus trap, Escape, возврат фокуса и reduced-motion путь закрытия;
- пустые models/efforts не дают undefined;
- обработан IME composition при отправке, не только Enter;
- перечень моделей — реальные данные приложения, не демонстрационные названия.

В web-проекте используй `npx tsc --noEmit` и `npm run build`. Эти web-команды здесь не запускались; отдельный web-проект не создавался. Рабочая целевая реализация этого релиза — Android/Compose.
