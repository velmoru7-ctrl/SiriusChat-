# Перенос Text Animation (fork) 9.2

Источник: предоставленный пользователем `text_animation_private_let.py`.

Авторы оригинала: @mihailkotovski и @mishabotov. Авторы форка: @private_let и @TextAnimation.

Python содержит Telegram-обёртку и сжатый DEX, а не независимый Compose-компонент. DEX был прочитан как данные: проверены формат и контрольные суммы, изучены имена методов и настройки. Он не исполнялся и не включён в приложение. Это самостоятельная нативная адаптация набора эффектов, не декомпилированная побайтовая копия.

SHA-256 исходного Python: `85ebae30e2cda62c4ee632876146dc77de2c4938ec0ce30de64a83c797391e77`.

## Сверка настроек

Все 29 предоставленных настроек представлены в модели и сохраняются в DataStore. Исходные значения сверены автоматически; исходный JSON — `references/text-animation-defaults.json`.

| Python | Kotlin | Исходное значение |
|---|---|---|
| `enabled` | `enabled` | `true` |
| `duration` | `durationMillis` | `300` |
| `blur_enabled` | `blurEnabled` | `true` |
| `blur_duration` | `blurDurationMillis` | `300` |
| `blur_radius` | `blurRadius` | `10` |
| `blur_text_delay` | `blurHoldPercent` | `20` |
| `slide_enabled` | `slideEnabled` | `true` |
| `slide_dist` | `slideDistanceDp` | `20` |
| `scale_enabled` | `scaleEnabled` | `false` |
| `scale_start` | `scaleStart` | `0.0` |
| `rotate_enabled` | `rotateEnabled` | `false` |
| `rotate_angle` | `rotateDegrees` | `-15` |
| `delete_anim_enabled` | `deleteAnimationEnabled` | `true` |
| `particle_style` | `particleStyle` | `0` |
| `particle_count` | `particleCount` | `5` |
| `particle_speed` | `particleSpeed` | `50` |
| `particle_spread` | `particleSpread` | `50` |
| `particle_size` | `particleSize` | `50` |
| `cursor_enabled` | `cursorEnabled` | `true` |
| `cursor_speed` | `cursorSpeed` | `25` |
| `cursor_width` | `cursorWidthDp` | `5` |
| `liquid_cursor_enabled` | `liquidCursorEnabled` | `false` |
| `liquid_scale_factor` | `liquidScaleFactor` | `15` |
| `selection_cursor_effect` | `selectionCursorEffect` | `0` |
| `selection_liquid_stretch` | `selectionLiquidStretch` | `60` |
| `selection_liquid_side` | `selectionLiquidSide` | `50` |
| `ignore_spaces` | `ignoreSpaces` | `true` |
| `animate_all_lines` | `animateAllLines` | `false` |
| `debug_mode` | `debugMode` | `false` |

## Отличия платформы

- Нативное Compose-поле сохраняет управление IME, текстом, выделением, буфером обмена и семантикой; декоративный слой не перехватывает ввод.
- Во время IME-композиции используется системный курсор. Это осознанное ограничение ради корректного ввода.
- Аппаратное размытие работает на Android 12+. На Android 8–11 действуют fade, сдвиг, масштаб, поворот, частицы и прочие эффекты без аппаратного blur.
- Движение, частицы и растяжение реализованы нативно; пиксельное совпадение с Telegram не заявляется.
- Большие вставки не анимируются посимвольно. Ограничены число GPU-слоёв и частиц.
- Работа со сложными графемами проверена отдельными JVM-тестами; настоящие IME и визуальный результат ещё нужно проверить на Android.
- Reduce Motion отключает декоративную анимацию. Парольные поля не используют overlay.
