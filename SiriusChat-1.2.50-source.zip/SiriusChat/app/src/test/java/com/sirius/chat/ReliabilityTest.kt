package com.sirius.chat

import com.sirius.chat.ai.agent.requiredContent
import com.sirius.chat.data.repository.ChangeStore
import com.sirius.chat.data.repository.EditorSessionStore
import com.sirius.chat.data.preview.SandboxOverlay
import com.sirius.chat.domain.model.*
import com.sirius.chat.domain.repository.WorkspaceRepository
import com.sirius.chat.domain.usecase.ApplyChangesUseCase
import kotlinx.coroutines.test.runTest
import kotlinx.serialization.json.*
import org.junit.Assert.*
import org.junit.Test
import java.lang.reflect.Proxy
import java.nio.file.Files

/** Android/Gradle unit suite. Run with :app:testDebugUnitTest (not executed in the offline sandbox). */
class ReliabilityTest {
    private fun change(id: String = "change", tree: String = "tree-a", session: String = "chat-a") = PendingChange(
        id, session, ChangeKind.Modify, "file.txt", "file.txt", "root", "old", "new", projectId = tree, treeUri = tree
    )

    @Test fun missingContentCannotEraseAFile() {
        assertThrows(IllegalArgumentException::class.java) { buildJsonObject {}.requiredContent() }
        assertThrows(IllegalArgumentException::class.java) { buildJsonObject { put("content", JsonNull) }.requiredContent() }
        assertThrows(IllegalArgumentException::class.java) { buildJsonObject { put("content", 3) }.requiredContent() }
        assertEquals("", buildJsonObject { put("content", "") }.requiredContent())
        assertEquals("a\nb", buildJsonObject { put("content", buildJsonArray { add("a"); add("b") }) }.requiredContent())
    }

    @Test fun proposalsArePartitionedByProjectAndChat() {
        val store = ChangeStore()
        store.submit(listOf(change("a"), change("b", "tree-b"), change("c", session = "chat-b")))
        assertEquals(3, store.changes.value.size)
        store.submit(listOf(change("new-a")))
        assertEquals(setOf("new-a", "b", "c"), store.changes.value.map { it.id }.toSet())
    }

    @Test fun applyingOldSnapshotCannotRemoveANewerProposal() {
        val store = ChangeStore()
        val original = change()
        store.submit(listOf(original))
        store.replaceContent(original.id, "newer")
        store.removeIfUnchanged(original)
        assertEquals("newer", store.byId(original.id)?.newContent)
    }

    @Test fun originMismatchStopsBeforeFileIO() = runTest {
        val fake = FakeWorkspace()
        val result = ApplyChangesUseCase(fake)("tree-b", listOf(change()))
        assertEquals(0, result.applied)
        assertEquals(0, fake.reads)
        assertEquals(0, fake.writes)
    }

    @Test fun staleOriginalCannotBeOverwritten() = runTest {
        val fake = FakeWorkspace().apply { text = "external edit" }
        val result = ApplyChangesUseCase(fake)("tree-a", listOf(change()))
        assertFalse(result.success)
        assertEquals("external edit", fake.text)
        assertEquals(0, fake.writes)
    }

    @Test fun writeFailureRestoresTheOriginal() = runTest {
        val fake = FakeWorkspace().apply { failFirstWrite = true }
        val result = ApplyChangesUseCase(fake)("tree-a", listOf(change()))
        assertFalse(result.success)
        assertEquals("old", fake.text)
        assertEquals(2, fake.writes)
    }

    @Test fun moveDoesNotReadOrRewriteText() = runTest {
        val fake = FakeWorkspace()
        val move = change().copy(kind = ChangeKind.Move, path = "dest/file.txt", parentDocumentId = "dest",
            sourceParentDocumentId = "root", sourcePath = "file.txt", oldContent = null, newContent = null)
        assertTrue(ApplyChangesUseCase(fake)("tree-a", listOf(move)).success)
        assertEquals(1, fake.moves)
        assertEquals(0, fake.reads)
        assertEquals(0, fake.writes)
    }

    @Test fun absentNewContentDoesNotBecomeAnEmptyFile() = runTest {
        val fake = FakeWorkspace()
        assertFalse(ApplyChangesUseCase(fake)("tree-a", listOf(change().copy(newContent = null))).success)
        assertEquals("old", fake.text)
        assertEquals(0, fake.writes)
    }

    @Test fun dirtyTabsNeedExplicitDiscard() {
        val store = EditorSessionStore()
        val node = FileNode("same-id", "a.kt", "a.kt", false)
        store.open(node, "one", treeUri = "tree-a")
        store.update(node.documentId) { it.copy(content = "unsaved") }
        store.close(node.documentId)
        assertEquals("unsaved", store.tab(node.documentId)?.content)
        store.close(node.documentId, discardUnsaved = true)
        assertNull(store.tab(node.documentId))
    }

    @Test fun projectSwitchParksUnsavedBuffers() {
        val store = EditorSessionStore()
        val node = FileNode("same-id", "a.kt", "a.kt", false)
        store.open(node, "a", treeUri = "tree-a")
        store.update(node.documentId) { it.copy(content = "dirty-a") }
        store.open(node, "b", treeUri = "tree-b")
        assertEquals("b", store.tab(node.documentId)?.content)
        store.switchTree("tree-a")
        assertEquals("dirty-a", store.tab(node.documentId)?.content)
        assertEquals("tree-a", store.tab(node.documentId)?.treeUri)
    }

    @Test fun saveSnapshotCannotMarkLaterTypingSaved() {
        val store = EditorSessionStore()
        val node = FileNode("id", "a.kt", "a.kt", false)
        store.open(node, "old", treeUri = "tree-a")
        store.update(node.documentId) { it.copy(content = "submitted") }
        val submitted = store.tab(node.documentId)!!.content
        store.update(node.documentId) { it.copy(content = "newer typing") }
        store.switchTree("tree-b")
        store.updateInTree("tree-a", node.documentId) { it.copy(savedContent = submitted) }
        store.switchTree("tree-a")
        assertTrue(store.tab(node.documentId)!!.dirty)
        assertEquals("submitted", store.tab(node.documentId)?.savedContent)
        assertEquals("newer typing", store.tab(node.documentId)?.content)
    }

    @Test fun overlayCannotEscapeAndKeepsTheFirstBaseVersion() {
        val root = Files.createTempDirectory("sirius-overlay-").toFile()
        try {
            val overlay = SandboxOverlay(root)
            assertThrows(IllegalArgumentException::class.java) { overlay.write("../escape", byteArrayOf(1), null) }
            overlay.write("a.txt", "first".toByteArray(), "original-hash")
            overlay.write("./a.txt", "next".toByteArray(), "later-hash")
            assertEquals("original-hash", overlay.baseHash("a.txt"))
            assertEquals("next", overlay.resolve("a.txt")?.readText())
            overlay.delete("a.txt", "changed")
            assertTrue(overlay.isDeleted("./a.txt"))
            assertNull(overlay.resolve("a.txt"))
        } finally { root.deleteRecursively() }
    }
}

private fun unsupportedWorkspace(): WorkspaceRepository = Proxy.newProxyInstance(
    WorkspaceRepository::class.java.classLoader, arrayOf(WorkspaceRepository::class.java)
) { _, method, _ -> error("Unexpected workspace operation: ${method.name}") } as WorkspaceRepository

private class FakeWorkspace : WorkspaceRepository by unsupportedWorkspace() {
    var text = "old"
    var reads = 0
    var writes = 0
    var moves = 0
    var failFirstWrite = false
    private val file = FileNode("file.txt", "file.txt", "file.txt", false)
    override suspend fun findByPath(treeUri: String, path: String): FileNode? = if (path == "file.txt") file else null
    override suspend fun exists(treeUri: String, path: String): Boolean = path == "file.txt"
    override suspend fun readTextExact(treeUri: String, documentId: String, maxBytes: Long): String { reads++; return text }
    override suspend fun writeText(treeUri: String, documentId: String, content: String): Boolean {
        writes++
        if (failFirstWrite && writes == 1) { text = "partial"; return false }
        text = content
        return true
    }
    override suspend fun move(treeUri: String, documentId: String, sourceParentId: String, targetParentId: String): FileNode {
        moves++
        return file.copy(path = "$targetParentId/file.txt")
    }
}
