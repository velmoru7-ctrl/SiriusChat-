package com.sirius.chat

import com.sirius.chat.ai.streaming.SseEvent
import com.sirius.chat.ai.streaming.SseParser
import com.sirius.chat.core.network.cancellationRelay
import com.sirius.chat.core.util.BoundedIo
import com.sirius.chat.data.attachment.AttachmentReader
import com.sirius.chat.domain.model.AttachmentKind
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.runBlocking
import okhttp3.OkHttpClient
import okhttp3.Request
import okio.Buffer
import org.junit.Assert.*
import org.junit.Test
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/** For Gradle/CI; no request is sent, and these tests do not validate native Compose UI. */
class NetworkReliabilityTest {
    @Test fun missingMimeKotlinFileIsText() = assertEquals(AttachmentKind.TextFile, AttachmentReader.classify("Main.kt", null))
    @Test fun missingMimeArchiveIsOpaque() = assertEquals(AttachmentKind.Opaque, AttachmentReader.classify("app.zip", null))
    @Test fun missingMimePdfIsDocument() = assertEquals(AttachmentKind.Document, AttachmentReader.classify("doc.pdf", null))
    @Test fun missingMimeDockerfileIsText() = assertEquals(AttachmentKind.TextFile, AttachmentReader.classify("Dockerfile", null))
    @Test fun imageMimeParametersAreNormalized() = assertEquals(AttachmentKind.Image, AttachmentReader.classify("photo", "IMAGE/JPG; charset=UTF-8"))

    private fun events(text: String): List<SseEvent> {
        val result = mutableListOf<SseEvent>()
        SseParser.read(Buffer().writeUtf8(text)) { result += it; true }
        return result
    }
    @Test fun eofWithoutFinalNewline() = assertEquals("tail ", events("data: tail ").single().data)
    @Test fun bomAndCrLf() = assertEquals("hello", events("\uFEFFdata: hello\r\n\r\n").single().data)
    @Test fun crOnlyFrames() = assertEquals("hello", events("data: hello\r\r").single().data)
    @Test fun emptyDataStillDispatches() = assertEquals("", events("data:\n\n").single().data)
    @Test fun eventOnlyBlockResetsName() = assertNull(events("event: old\n\ndata: x\n\n").single().event)
    @Test fun stopCallbackDoesNotReadNextEvent() {
        var count = 0
        SseParser.read(Buffer().writeUtf8("data: first\n\ndata: second\n\n")) { count++; false }
        assertEquals(1, count)
    }
    @Test(expected = BoundedIo.LimitExceededException::class)
    fun oversizedUnterminatedLineIsRejected() {
        SseParser.read(Buffer().writeUtf8("x".repeat(SseParser.MAX_LINE_BYTES.toInt() + 1))) { true }
    }
    @Test fun normalRelayCompletionDoesNotCancelCall() {
        val parent = Job()
        val call = OkHttpClient().newCall(Request.Builder().url("https://example.invalid/").build())
        call.cancellationRelay(parent).complete()
        assertFalse(call.isCanceled())
        parent.complete()
    }
    @Test fun alreadyCancelledParentCancelsCall() {
        val parent = Job(); parent.cancel()
        val call = OkHttpClient().newCall(Request.Builder().url("https://example.invalid/").build())
        call.cancellationRelay(parent)
        assertTrue(call.isCanceled())
    }
    @Test fun cancellationDoesNotWaitForBlockedParentCompletion() = runBlocking {
        val started = CountDownLatch(1)
        val release = CountDownLatch(1)
        val call = OkHttpClient().newCall(Request.Builder().url("https://example.invalid/").build())
        val blocked = launch(Dispatchers.IO) { started.countDown(); release.await(5, TimeUnit.SECONDS) }
        val completed = java.util.concurrent.atomic.AtomicBoolean(false)
        blocked.invokeOnCompletion { completed.set(true) }
        val relay = call.cancellationRelay(blocked)
        try {
            assertTrue(started.await(5, TimeUnit.SECONDS))
            blocked.cancel()
            assertTrue(call.isCanceled())
            assertFalse(completed.get())
        } finally {
            release.countDown(); relay.complete(); blocked.join()
        }
    }
}
