package com.sirius.chat

import com.sirius.chat.ai.pricing.UsageAttempt
import com.sirius.chat.feature.chat.components.summarizeUsage
import org.junit.Assert.*
import org.junit.Test

/** Pure summary calculations. These are not Android rendering tests. */
class UsagePresentationTest {
    private fun row(status: String, cost: Double? = null) = UsageAttempt(
        id = "attempt", taskId = "task", providerId = "provider", model = "model",
        purpose = "answer", createdAt = 0, status = status, costUsd = cost
    )

    @Test fun emptyIsNotFree() {
        val value = summarizeUsage(emptyList())
        assertTrue(value.empty)
        assertEquals(0, value.known)
    }

    @Test fun pendingIsNotUnknown() {
        val value = summarizeUsage(listOf(row("pending")))
        assertEquals(1, value.pending)
        assertEquals(0, value.unknown)
        assertEquals(0, value.known)
    }

    @Test fun zeroChargeIsKnown() {
        val value = summarizeUsage(listOf(row("complete", 0.0)))
        assertFalse(value.empty)
        assertEquals(1, value.known)
        assertEquals(0, value.unknown)
    }

    @Test fun uncertainChargeStaysUnknown() {
        val value = summarizeUsage(listOf(row("uncertain")))
        assertEquals(1, value.unknown)
        assertEquals(0, value.pending)
    }

    @Test fun completedWithoutPriceIsNotFree() {
        val value = summarizeUsage(listOf(row("complete")))
        assertEquals(1, value.unknown)
        assertEquals(0, value.known)
    }

    @Test fun totalsOnlyKnownCharges() {
        val value = summarizeUsage(listOf(row("complete", .2), row("complete", .3), row("uncertain")))
        assertEquals(.5, value.totalUsd, .00000001)
        assertEquals(2, value.known)
        assertEquals(1, value.unknown)
    }

    @Test fun mixedInFlightIsSeparateFromMissingPrice() {
        val value = summarizeUsage(listOf(row("pending"), row("uncertain"), row("complete", .01)))
        assertEquals(1, value.pending)
        assertEquals(1, value.unknown)
        assertEquals(1, value.known)
    }

    @Test fun smallChargeIsNotDiscarded() {
        val value = summarizeUsage(listOf(row("complete", .0000001)))
        assertTrue(value.totalUsd > 0)
        assertEquals(1, value.known)
    }
}
