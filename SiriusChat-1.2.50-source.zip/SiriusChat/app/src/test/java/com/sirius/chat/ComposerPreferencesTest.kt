package com.sirius.chat

import com.sirius.chat.core.util.DictationText
import com.sirius.chat.core.util.VoiceSession
import com.sirius.chat.domain.model.AppSettings
import com.sirius.chat.domain.model.ComposerStyle
import org.junit.Assert.*
import org.junit.Test

/** Included in Gradle/CI. Portable counterparts execute directly without Android SDK. */
class ComposerPreferencesTest {
    @Test fun upgradeKeepsClassic() { assertEquals(ComposerStyle.Classic, AppSettings().composerStyle) }
    @Test fun systemSpeechNeedsConsent() { assertFalse(AppSettings().systemVoiceAllowed) }
    @Test fun onlyOneAlternateStyle() { assertEquals(listOf(ComposerStyle.Classic, ComposerStyle.Prompt), ComposerStyle.entries.toList()) }
    @Test fun changingStylePreservesOtherSettings() {
        val original=AppSettings(activeModel="chosen",taskBudgetUsd=3.0,language=com.sirius.chat.domain.model.AppLanguage.Russian)
        val styled=original.copy(composerStyle=ComposerStyle.Prompt)
        assertEquals("chosen",styled.activeModel);assertEquals(3.0,styled.taskBudgetUsd,0.0);assertEquals(original.textAnimation,styled.textAnimation)
    }
    @Test fun consentDoesNotChangeStyle() {
        val settings=AppSettings(composerStyle=ComposerStyle.Prompt).copy(systemVoiceAllowed=true)
        assertEquals(ComposerStyle.Prompt,settings.composerStyle)
    }
    @Test fun consentCanBeRevoked() { assertFalse(AppSettings(systemVoiceAllowed=true).copy(systemVoiceAllowed=false).systemVoiceAllowed) }
    @Test fun cancelledSpeechCannotCommit() { val gate=VoiceSession();val ticket=gate.begin();gate.cancel();assertFalse(gate.finish(ticket)) }
    @Test fun doubleFinalCommitsOnce() { val gate=VoiceSession();val ticket=gate.begin();assertTrue(gate.finish(ticket));assertFalse(gate.finish(ticket)) }
    @Test fun manualInputIsPreserved() { assertEquals("latest text spoken",DictationText.append("latest text","spoken")) }
    @Test fun unicodeIsPreserved() { assertEquals("Привет 👋 мир",DictationText.append("Привет 👋","мир")) }
    @Test fun nonFiniteMeterIsZero() { assertEquals(0f,DictationText.level(Float.NaN),0f) }
    @Test fun ownerCannotBeReopened() { val gate=VoiceSession();gate.close();assertEquals(0L,gate.begin()) }
}
