package com.sirius.chat.ai.streaming;

/** A stream made of small legal frames must not build an unlimited answer in memory. */
public final class StreamBudget {
    public static final int MAX_CHARS = 1024 * 1024;
    public static final int MAX_TOOL_CALLS = 128;
    private final int limit;
    private long used;
    public StreamBudget() { this(MAX_CHARS); }
    public StreamBudget(int limit) {
        if (limit < 0) throw new IllegalArgumentException("Negative stream limit");
        this.limit = limit;
    }
    public void add(int chars) {
        if (chars < 0 || used + chars > limit)
            throw new IllegalArgumentException("The streamed answer exceeds the safe character limit.");
        used += chars;
    }
    public void checkSlots(int existingCount, boolean existingSlot) {
        if (!existingSlot && existingCount >= MAX_TOOL_CALLS)
            throw new IllegalArgumentException("The provider returned too many tool calls.");
    }
    public long used() { return used; }
}
