package com.sirius.chat.feature.chat.components

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.ai.pricing.ModelPricing
import com.sirius.chat.ai.pricing.UsageAttempt
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.SiriusBottomSheet
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.ui.LocalAppContainer

/** Distinguish a genuine zero charge from no data or an unfinished request. */
data class UsageCostSummary(
    val totalUsd: Double,
    val known: Int,
    val pending: Int,
    val unknown: Int,
    val empty: Boolean
)

fun summarizeUsage(rows: List<UsageAttempt>): UsageCostSummary = UsageCostSummary(
    totalUsd = rows.sumOf { it.costUsd ?: 0.0 },
    known = rows.count { it.costUsd != null },
    pending = rows.count { it.status == "pending" },
    unknown = rows.count { it.status != "pending" && it.costUsd == null },
    empty = rows.isEmpty()
)

@Composable
fun usageAmountLabel(summary: UsageCostSummary): String = when {
    summary.empty -> stringResource(R.string.usage_no_data)
    summary.known == 0 && summary.unknown > 0 -> stringResource(R.string.usage_unknown)
    summary.known == 0 && summary.pending > 0 -> stringResource(R.string.usage_calculating)
    else -> "≈ ${ModelPricing.format(summary.totalUsd)}" + if (summary.unknown > 0) " + ?" else ""
}

/** Opened on demand, never inserted above the composer or into the transcript. */
@Composable
fun TaskUsageSheet(sessionId: String, onOpenUsage: () -> Unit, onDismiss: () -> Unit) {
    val container = LocalAppContainer.current
    val ledger by container.usageLedger.state.collectAsStateWithLifecycle()
    val task = ledger.latest(sessionId)
    val rows = task?.let { ledger.forTask(it.id) }.orEmpty()
    val summary = summarizeUsage(rows)
    val colors = SiriusTheme.colors
    SiriusBottomSheet(
        title = stringResource(R.string.usage_task_details),
        subtitle = stringResource(R.string.usage_latest_in_chat),
        onDismiss = onDismiss
    ) {
        Column(
            Modifier.fillMaxWidth().background(colors.surfaceMuted, RoundedCornerShape(16.dp)).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text(stringResource(R.string.usage_accounted), style = MaterialTheme.typography.labelMedium,
                color = colors.textSecondary)
            Text(usageAmountLabel(summary), style = MaterialTheme.typography.headlineSmall, color = colors.textPrimary)
            if (summary.empty) {
                Text(stringResource(R.string.usage_empty), style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
            } else {
                if (summary.pending > 0) Text(stringResource(R.string.usage_pending, summary.pending),
                    style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                if (summary.unknown > 0) Text(stringResource(R.string.usage_unknown_count, summary.unknown),
                    style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
            }
            task?.let {
                Text(if (it.budgetUsd > 0.0) stringResource(R.string.usage_budget_amount, ModelPricing.format(it.budgetUsd))
                    else stringResource(R.string.usage_no_budget), style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                if (it.stoppedReason.isNotBlank()) Text(it.stoppedReason,
                    style = MaterialTheme.typography.bodySmall, color = colors.error)
            }
        }
        if (rows.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            CostBreakdown(rows)
            HorizontalDivider(Modifier.padding(vertical = 12.dp))
            Text(stringResource(R.string.usage_token_totals, rows.sumOf { it.inputTokens }.toString(), rows.sumOf { it.outputTokens }.toString()),
                style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
        }
        Spacer(Modifier.height(12.dp))
        Text(stringResource(R.string.usage_estimate_note), style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
        Spacer(Modifier.height(8.dp))
        SiriusGhostButton(text = stringResource(R.string.usage_open), onClick = {
            onDismiss()
            onOpenUsage()
        }, modifier = Modifier.fillMaxWidth())
    }
}

@Composable
fun CostBreakdown(rows: List<UsageAttempt>) {
    val colors = SiriusTheme.colors
    rows.groupBy { it.purpose }.forEach { (purpose, entries) ->
        val summary = summarizeUsage(entries)
        val label = stringResource(when (purpose) {
            "memory" -> R.string.usage_memory
            "title" -> R.string.usage_naming
            "compaction" -> R.string.usage_compaction
            "images" -> R.string.usage_images
            else -> R.string.usage_answer
        })
        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Column(Modifier.weight(1f)) {
                Text(label, style = MaterialTheme.typography.bodyMedium, color = colors.textPrimary)
                Text(stringResource(R.string.usage_operation_count, entries.size),
                    style = MaterialTheme.typography.labelSmall, color = colors.textSecondary)
            }
            Text(usageAmountLabel(summary), modifier = Modifier.weight(1f),
                style = MaterialTheme.typography.bodyMedium, color = colors.textSecondary,
                textAlign = androidx.compose.ui.text.style.TextAlign.End)
        }
    }
}
