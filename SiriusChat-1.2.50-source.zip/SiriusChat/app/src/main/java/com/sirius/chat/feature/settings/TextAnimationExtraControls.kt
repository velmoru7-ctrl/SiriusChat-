package com.sirius.chat.feature.settings

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.domain.model.TextAnimationSettings

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun TextAnimationExtraControls(settings: TextAnimationSettings, onChange: (TextAnimationSettings) -> Unit) {
    val enabled = settings.enabled && !SiriusTheme.reduceMotion
    GlassCard {
        Text(stringResource(R.string.anim_extra_title), style = MaterialTheme.typography.titleLarge)
        SettingToggle(Icons.Rounded.AutoAwesome, stringResource(R.string.anim_delete), stringResource(R.string.anim_delete_hint),
            settings.deleteAnimationEnabled, { onChange(settings.copy(deleteAnimationEnabled = it)) }, enabled = enabled)
        if (enabled && settings.deleteAnimationEnabled) {
            Text(stringResource(R.string.anim_style), style = MaterialTheme.typography.titleMedium)
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf(R.string.anim_dust, R.string.anim_sparks, R.string.anim_snow, R.string.anim_petals, R.string.anim_letters).forEachIndexed { index, name ->
                    FilterChip(selected = settings.particleStyle == index, onClick = { onChange(settings.copy(particleStyle = index)) },
                        label = { Text(stringResource(name)) }, modifier = Modifier.heightIn(min = 48.dp))
                }
            }
            AnimationDial(R.string.anim_count, settings.particleCount, 0..12) { onChange(settings.copy(particleCount = it)) }
            AnimationDial(R.string.anim_speed, settings.particleSpeed, 0..120) { onChange(settings.copy(particleSpeed = it)) }
            AnimationDial(R.string.anim_spread, settings.particleSpread, 0..120) { onChange(settings.copy(particleSpread = it)) }
            AnimationDial(R.string.anim_size, settings.particleSize, 10..120) { onChange(settings.copy(particleSize = it)) }
        }
        SettingToggle(Icons.Rounded.AutoAwesome, stringResource(R.string.anim_cursor), stringResource(R.string.anim_cursor_hint),
            settings.cursorEnabled, { onChange(settings.copy(cursorEnabled = it)) }, enabled = enabled)
        if (enabled && settings.cursorEnabled) {
            AnimationDial(R.string.anim_cursor_speed, settings.cursorSpeed, 1..60) { onChange(settings.copy(cursorSpeed = it)) }
            AnimationDial(R.string.anim_cursor_width, settings.cursorWidthDp, 1..12) { onChange(settings.copy(cursorWidthDp = it)) }
            SettingToggle(Icons.Rounded.AutoAwesome, stringResource(R.string.anim_liquid), stringResource(R.string.anim_liquid_hint),
                settings.liquidCursorEnabled, { onChange(settings.copy(liquidCursorEnabled = it)) })
            if (settings.liquidCursorEnabled) AnimationDial(R.string.anim_liquid_factor, settings.liquidScaleFactor, 0..40) {
                onChange(settings.copy(liquidScaleFactor = it))
            }
        }
        SettingToggle(Icons.Rounded.AutoAwesome, stringResource(R.string.anim_selection), stringResource(R.string.anim_selection_hint),
            settings.selectionCursorEffect == 1, { onChange(settings.copy(selectionCursorEffect = if (it) 1 else 0)) }, enabled = enabled)
        if (enabled && settings.selectionCursorEffect == 1) {
            AnimationDial(R.string.anim_selection_stretch, settings.selectionLiquidStretch, 0..200) { onChange(settings.copy(selectionLiquidStretch = it)) }
            AnimationDial(R.string.anim_selection_side, settings.selectionLiquidSide, 0..200) { onChange(settings.copy(selectionLiquidSide = it)) }
        }
        SettingToggle(Icons.Rounded.AutoAwesome, stringResource(R.string.anim_all_lines), stringResource(R.string.anim_all_lines_hint),
            settings.animateAllLines, { onChange(settings.copy(animateAllLines = it)) }, enabled = enabled)
        SettingToggle(Icons.Rounded.AutoAwesome, stringResource(R.string.anim_debug), stringResource(R.string.anim_debug_hint),
            settings.debugMode, { onChange(settings.copy(debugMode = it)) }, enabled = enabled)
        Text(stringResource(R.string.anim_attribution), style = MaterialTheme.typography.bodySmall, modifier = Modifier.padding(top = 8.dp))
    }
}

@Composable
private fun AnimationDial(label: Int, value: Int, range: IntRange, onChange: (Int) -> Unit) {
    SliderRow(stringResource(label), value.toFloat(), value.toString(), range.first.toFloat()..range.last.toFloat(),
        { onChange(it.toInt()) })
}
