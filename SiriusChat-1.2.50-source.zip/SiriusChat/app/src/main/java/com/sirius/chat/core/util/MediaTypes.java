package com.sirius.chat.core.util;

import java.util.Locale;

/** An absent MIME type is unknown, never evidence that bytes are a PNG. */
public final class MediaTypes {
    private MediaTypes() {}
    public static String normalize(String mime) {
        if (mime == null) return "";
        int separator = mime.indexOf(';');
        String type = (separator < 0 ? mime : mime.substring(0, separator))
            .trim().toLowerCase(Locale.ROOT);
        return type.equals("image/jpg") ? "image/jpeg" : type;
    }
    public static boolean isSupportedImage(String mime) {
        String type = normalize(mime);
        return type.equals("image/png") || type.equals("image/jpeg")
            || type.equals("image/gif") || type.equals("image/webp");
    }
    /** Detect the four accepted encodings; this is format detection, not full image validation. */
    public static String detectImageType(byte[] b) {
        if (b.length >= 8 && (b[0] & 255) == 137 && b[1] == 80 && b[2] == 78 && b[3] == 71
                && b[4] == 13 && b[5] == 10 && b[6] == 26 && b[7] == 10) return "image/png";
        if (b.length >= 3 && (b[0] & 255) == 255 && (b[1] & 255) == 216 && (b[2] & 255) == 255)
            return "image/jpeg";
        if (b.length >= 6 && b[0] == 'G' && b[1] == 'I' && b[2] == 'F' && b[3] == '8'
                && (b[4] == '7' || b[4] == '9') && b[5] == 'a') return "image/gif";
        if (b.length >= 12 && b[0] == 'R' && b[1] == 'I' && b[2] == 'F' && b[3] == 'F'
                && b[8] == 'W' && b[9] == 'E' && b[10] == 'B' && b[11] == 'P') return "image/webp";
        return "";
    }
    public static String imageExtension(String mime) {
        switch (normalize(mime)) {
            case "image/jpeg": return ".jpg";
            case "image/webp": return ".webp";
            case "image/gif": return ".gif";
            case "image/png": return ".png";
            default: throw new IllegalArgumentException("Unsupported encoded image type");
        }
    }
}
