package com.sirius.chat.data.preview

import java.io.File
import java.nio.file.Files
import com.sirius.chat.core.util.ProjectPaths
import java.security.MessageDigest
import java.util.concurrent.ConcurrentHashMap

/**
 * Writes the agent makes while a preview is running, kept off the real project.
 *
 * ### Why the agent does not write straight through
 * A repair loop writes deliberate rubbish on the way to a fix: generate, watch
 * it throw, patch, watch it throw differently, patch again. If those land in the
 * project then an interrupted run -- token budget spent, app killed, user hit
 * stop -- leaves the folder in whichever half-broken state the model happened to
 * be in. SAF makes that worse: there is no atomic rename across providers and no
 * cheap undo, so "put it back" is not a thing that can be offered afterwards.
 *
 * With an overlay, abandoning a run is free. It is also markedly faster, which
 * matters more than it sounds in a write-reload-screenshot loop: app-private
 * storage is a syscall, a SAF write is several binder round trips.
 *
 * ### Why deletions need a tombstone
 * Deleting a file in the overlay cannot delete it from the project, so the
 * lookup would fall through and find the original still sitting there -- the
 * agent would delete a file and the page would carry on serving it. A tombstone
 * makes the miss explicit.
 */
class SandboxOverlay(private val root: File) {

    private val tombstones = ConcurrentHashMap.newKeySet<String>()

    /**
     * Hash of the original at the moment this path was first written.
     *
     * Kept so the review at the end can tell "the agent changed this" from "the
     * user changed this in another editor while the loop was running". Without
     * it, committing the overlay would silently discard their edit.
     */
    private val baseHashes = ConcurrentHashMap<String, String>()

    val isEmpty: Boolean get() = tombstones.isEmpty() && touchedFiles().isEmpty()

    @Synchronized
    fun write(path: String, bytes: ByteArray, baseHash: String?) {
        val key = ProjectPaths.relative(path)
        val target = ProjectPaths.file(root, key)
        check(target.parentFile?.let { it.isDirectory || it.mkdirs() } == true) { "Cannot create overlay directory." }
        // Replace only after a complete write. A failed stage must keep its previous version.
        val temp = File.createTempFile(".stage-", ".tmp", target.parentFile)
        try {
            temp.outputStream().use { out -> out.write(bytes); out.fd.sync() }
            Files.move(temp.toPath(), target.toPath(), java.nio.file.StandardCopyOption.REPLACE_EXISTING,
                java.nio.file.StandardCopyOption.ATOMIC_MOVE)
        } finally { temp.delete() }
        tombstones.remove(key)
        baseHashes.putIfAbsent(key, baseHash ?: ABSENT)
    }

    @Synchronized
    fun delete(path: String, baseHash: String?) {
        val key = ProjectPaths.relative(path)
        val target = ProjectPaths.file(root, key)
        check(!target.exists() || target.delete()) { "Cannot remove overlay file." }
        tombstones += key
        baseHashes.putIfAbsent(key, baseHash ?: ABSENT)
    }

    @Synchronized
    fun resolve(path: String): File? {
        val key = ProjectPaths.relative(path)
        val file = ProjectPaths.file(root, key)
        return if (key in tombstones) null else file.takeIf { it.isFile }
    }

    fun isDeleted(path: String): Boolean = ProjectPaths.relative(path) in tombstones
    fun baseHash(path: String): String? = baseHashes[ProjectPaths.relative(path)]
    @Synchronized
    fun touchedPaths(): Set<String> = touchedFiles() + tombstones

    @Synchronized
    fun clear() {
        // Files.walk does not follow symlinks. Never recurse into a linked directory.
        if (root.exists()) Files.walk(root.toPath()).use { paths ->
            paths.sorted(java.util.Comparator.reverseOrder()).forEach { Files.deleteIfExists(it) }
        }
        check(root.isDirectory || root.mkdirs()) { "Cannot recreate overlay directory." }
        tombstones.clear()
        baseHashes.clear()
    }

    private fun touchedFiles(): Set<String> {
        if (!root.isDirectory) return emptySet()
        return root.walkTopDown().onEnter { !Files.isSymbolicLink(it.toPath()) }
            .filter { it.isFile && !Files.isSymbolicLink(it.toPath()) && !it.name.startsWith(".stage-") }
            .map { it.relativeTo(root).invariantSeparatorsPath }.toSet()
    }

    companion object {
        const val ABSENT = "<absent>"
        /** Content hash, used to detect an edit that arrived from outside the run. */
        fun hash(bytes: ByteArray): String {
            val digest = MessageDigest.getInstance("SHA-256").digest(bytes)
            val out = StringBuilder(digest.size * 2)
            for (byte in digest) {
                val value = byte.toInt() and 0xFF
                out.append(HEX[value ushr 4])
                out.append(HEX[value and 0x0F])
            }
            return out.toString()
        }

        private const val HEX = "0123456789abcdef"
    }
}
