package com.sirius.chat.feature.chat.components

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.key
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.LiveRegionMode
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.semantics.liveRegion
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.withResumed
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.data.voice.SpeechInputController
import com.sirius.chat.data.voice.SpeechInputState
import com.sirius.chat.data.voice.SpeechPhase
import com.sirius.chat.data.voice.SpeechProblem
import com.sirius.chat.data.voice.SpeechRequest
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch

class ChatVoiceInput(
    val controller: SpeechInputController,
    val onMicrophone: () -> Unit,
    val openPermissions: () -> Unit
)

/** Native permission/consent bridge. No recognizer is created before an explicit tap. */
@Composable
fun rememberChatVoiceInput(
    sessionId: String,
    composerEpoch: Long,
    enabled: Boolean,
    systemVoiceAllowed: Boolean,
    canStart: () -> Boolean,
    appendFinal: (String) -> Boolean,
    allowSystemVoice: suspend () -> Boolean
): ChatVoiceInput {
    val context = LocalContext.current
    val languageTag = LocalConfiguration.current.locales[0].toLanguageTag()
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    val scope = rememberCoroutineScope()
    val currentEnabled by rememberUpdatedState(enabled)
    val controller = remember(sessionId, composerEpoch, languageTag) {
        // Owner callbacks are captured per chat/epoch, not rebound to a different chat.
        SpeechInputController(context, { currentEnabled && canStart() }, appendFinal)
    }
    var pendingPermission by remember(controller) { mutableStateOf<SpeechRequest?>(null) }
    var pendingConsent by remember(controller) { mutableStateOf<SpeechRequest?>(null) }
    var savingConsent by remember(controller) { mutableStateOf(false) }

    fun resumeRequest(request: SpeechRequest) {
        scope.launch {
            // Permission results can arrive before the Activity has resumed.
            lifecycle.withResumed {
                if (controller.current(request)) controller.start(request)
            }
        }
    }
    val permission = key(controller) {
      rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val request = pendingPermission
        pendingPermission = null
        if (request != null && controller.current(request)) {
            if (granted) resumeRequest(request) else controller.fail(request, SpeechProblem.Permission)
        }
      }
    }
    fun requestPermission(request: SpeechRequest) {
        if (!controller.current(request)) return
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            resumeRequest(request)
        } else {
            pendingPermission = request
            try { permission.launch(Manifest.permission.RECORD_AUDIO) }
            catch (_: RuntimeException) { pendingPermission = null; controller.fail(request, SpeechProblem.Permission) }
        }
    }

    DisposableEffect(controller, lifecycle) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_STOP) {
                pendingPermission = null
                pendingConsent = null
                controller.cancel()
            } else if (event == Lifecycle.Event.ON_PAUSE && controller.state.value.phase != SpeechPhase.Permission) {
                // A permission dialog may pause the host before recording begins.
                // A real recording never continues behind another Activity.
                controller.cancel()
            }
        }
        lifecycle.addObserver(observer)
        onDispose {
            lifecycle.removeObserver(observer)
            controller.close()
        }
    }
    LaunchedEffect(controller, enabled) {
        if (!enabled) { pendingPermission = null; pendingConsent = null; controller.cancel() }
    }
    VoiceBackGuard(controller)

    pendingConsent?.let { request ->
        AlertDialog(
            onDismissRequest = { pendingConsent = null; controller.cancel() },
            title = { Text(stringResource(R.string.voice_system_title)) },
            text = { Text(stringResource(R.string.voice_system_notice)) },
            confirmButton = {
                TextButton(enabled = !savingConsent, onClick = {
                    if (!controller.current(request)) { pendingConsent = null; return@TextButton }
                    savingConsent = true
                    scope.launch {
                        try {
                            val saved = allowSystemVoice()
                            pendingConsent = null
                            if (controller.current(request)) {
                                if (saved) requestPermission(request.copy(systemApproved = true))
                                else controller.fail(request, SpeechProblem.ConsentSave)
                            }
                        } finally { savingConsent = false }
                    }
                }) { Text(stringResource(R.string.voice_system_accept)) }
            },
            dismissButton = {
                TextButton(onClick = { pendingConsent = null; controller.cancel() }) { Text(stringResource(R.string.action_cancel)) }
            }
        )
    }

    return ChatVoiceInput(
        controller = controller,
        onMicrophone = {
            when (controller.state.value.phase) {
                SpeechPhase.Listening -> controller.stop()
                SpeechPhase.Starting, SpeechPhase.Finishing, SpeechPhase.Permission -> {
                    pendingConsent = null; pendingPermission = null; controller.cancel()
                }
                SpeechPhase.Idle -> {
                    if (enabled && lifecycle.currentState.isAtLeast(Lifecycle.State.RESUMED)) {
                        val request = controller.reserve(languageTag, systemVoiceAllowed)
                        if (request != null) {
                            if (!request.onDevice && !request.systemApproved) pendingConsent = request
                            else requestPermission(request)
                        }
                    }
                }
            }
        },
        openPermissions = {
            controller.cancel()
            try {
                context.startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.fromParts("package", context.packageName, null)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            } catch (_: RuntimeException) { /* Existing permission message remains actionable by Settings app. */ }
        }
    )
}

/** RMS and partial text never subscribe the entire transcript to microphone updates. */
@Composable
private fun VoiceBackGuard(controller: SpeechInputController) {
    val activeFlow = remember(controller) { controller.state.map { it.active }.distinctUntilChanged() }
    val active by activeFlow.collectAsStateWithLifecycle(initialValue = false)
    BackHandler(enabled = active) { controller.cancel() }
}

@Composable
fun VoiceInputButton(voice: ChatVoiceInput, state: SpeechInputState, enabled: Boolean) {
    val colors = SiriusTheme.colors
    IconButton(onClick = voice.onMicrophone, enabled = enabled || state.active, modifier = Modifier.size(48.dp)) {
        Icon(
            imageVector = when (state.phase) {
                SpeechPhase.Listening -> Icons.Rounded.Stop
                SpeechPhase.Starting, SpeechPhase.Finishing, SpeechPhase.Permission -> Icons.Rounded.Close
                SpeechPhase.Idle -> Icons.Rounded.Mic
            },
            contentDescription = stringResource(when (state.phase) {
                SpeechPhase.Listening -> R.string.voice_finish
                SpeechPhase.Starting, SpeechPhase.Finishing, SpeechPhase.Permission -> R.string.voice_cancel
                SpeechPhase.Idle -> R.string.voice_start
            }),
            tint = if (state.active) colors.accent else if (enabled) colors.textSecondary else colors.textTertiary,
            modifier = Modifier.size(21.dp)
        )
    }
}

@Composable
fun VoiceInputPanel(voice: ChatVoiceInput, state: SpeechInputState) {
    if (!state.active && state.problem == null) return
    val colors = SiriusTheme.colors
    Column(Modifier.fillMaxWidth().padding(vertical = SiriusSpacing.xs)) {
        if (state.active) {
            Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
                VoiceLevel(state.level)
                Spacer(Modifier.width(SiriusSpacing.xs))
                Column(Modifier.weight(1f)) {
                    Text(
                        text = stringResource(when (state.phase) {
                            SpeechPhase.Permission -> R.string.voice_permission_pending
                            SpeechPhase.Starting -> R.string.voice_starting
                            SpeechPhase.Listening -> R.string.voice_listening
                            else -> R.string.voice_processing
                        }),
                        style = MaterialTheme.typography.labelLarge,
                        color = colors.textPrimary,
                        modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite }
                    )
                    Text(
                        stringResource(if (state.onDevice) R.string.voice_engine_device else R.string.voice_engine_system),
                        style = MaterialTheme.typography.labelSmall, color = colors.textSecondary
                    )
                }
                IconButton(onClick = { voice.controller.cancel() }, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Rounded.Close, stringResource(R.string.voice_cancel), tint = colors.textSecondary, modifier = Modifier.size(18.dp))
                }
            }
            if (state.partial.isNotBlank()) {
                Text(state.partial, style = MaterialTheme.typography.bodyMedium, color = colors.textSecondary,
                    maxLines = 3, overflow = TextOverflow.Ellipsis)
                Text(stringResource(R.string.voice_partial_hint), style = MaterialTheme.typography.labelSmall, color = colors.textTertiary)
            }
        }
        state.problem?.let { problem ->
            Text(stringResource(speechProblemResource(problem)), style = MaterialTheme.typography.bodySmall,
                color = colors.warning, modifier = Modifier.semantics { liveRegion = LiveRegionMode.Polite })
            Row(horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)) {
                if (problem == SpeechProblem.Permission) {
                    TextButton(onClick = voice.openPermissions) { Text(stringResource(R.string.voice_open_permissions)) }
                }
                TextButton(onClick = { voice.controller.dismissProblem() }) { Text(stringResource(R.string.action_close)) }
            }
        }
    }
}

@Composable
private fun VoiceLevel(level: Float) {
    val ink = SiriusTheme.colors.accent
    // All bars derive from the recognizer's aggregate RMS. No random or timer-driven signal.
    Canvas(Modifier.size(width = 32.dp, height = 28.dp).clearAndSetSemantics { }) {
        val profile = floatArrayOf(0.45f, 0.75f, 1f, 0.75f, 0.45f)
        val step = size.width / profile.size
        val width = step * 0.55f
        for (i in profile.indices) {
            val height = 4.dp.toPx() + (size.height - 4.dp.toPx()) * level.coerceIn(0f, 1f) * profile[i]
            drawRoundRect(ink, Offset(i * step, (size.height-height)/2), Size(width,height), CornerRadius(width/2,width/2))
        }
    }
}

private fun speechProblemResource(problem: SpeechProblem): Int = when (problem) {
    SpeechProblem.Unavailable -> R.string.voice_unavailable
    SpeechProblem.Permission -> R.string.voice_permission_denied
    SpeechProblem.Audio -> R.string.voice_audio_error
    SpeechProblem.Network -> R.string.voice_network_error
    SpeechProblem.Busy -> R.string.voice_busy
    SpeechProblem.NoMatch -> R.string.voice_no_match
    SpeechProblem.Timeout -> R.string.voice_timeout
    SpeechProblem.Language -> R.string.voice_language_error
    SpeechProblem.TooLong -> R.string.voice_too_long
    SpeechProblem.ChangedDraft -> R.string.voice_draft_changed
    SpeechProblem.ConsentSave -> R.string.voice_consent_save_failed
    SpeechProblem.Failed -> R.string.voice_failed
}
