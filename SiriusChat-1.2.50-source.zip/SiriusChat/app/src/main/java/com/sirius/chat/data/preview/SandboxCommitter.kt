package com.sirius.chat.data.preview

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import com.sirius.chat.domain.model.CommitResult
import com.sirius.chat.domain.model.ReviewEntry
import com.sirius.chat.domain.model.ReviewKind
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import com.sirius.chat.core.util.ProjectPaths
import kotlinx.coroutines.withContext

/**
 * Turns a finished preview sandbox into one reviewable change set, and writes it
 * to the real project only when the user says so.
 *
 * ### Why the review is one thing at the end
 * A repair loop deliberately passes through broken states: it writes a file,
 * looks at the crash, writes it again. Asking for confirmation per write means
 * eight prompts for eight states the user should never see, and the eighth one
 * gets approved without reading -- which is worse than no review at all, because
 * now the habit is trained. So the agent writes into a sandbox, and this class
 * asks once, about the difference that survived.
 *
 * ### Why the original bytes are kept
 * SAF has no atomic rename across providers and no undo. The only honest
 * rollback is to hold what was there and put it back, so [commit] reads every
 * original before it writes anything and restores in reverse order if any single
 * write fails. A half-applied project is the one outcome that must not happen:
 * it is the state where neither the user nor the agent can tell what the code
 * is.
 */
class SandboxCommitter(
    private val resolver: ContentResolver,
    private val index: SafProjectIndex,
    private val overlay: SandboxOverlay
) {
    private val commitMutex = Mutex()

    /**
     * What the sandbox would do to the project, one entry per file.
     *
     * Files the run changed and then changed back are left out. Their diff is
     * empty, and padding a review with empty diffs is how a user learns to stop
     * reading it.
     */
    suspend fun review(): List<ReviewEntry> = withContext(Dispatchers.IO) {
        overlay.touchedPaths().sorted().mapNotNull { path -> entryFor(path) }
    }

    /**
     * Writes [entries] to the project, restoring everything on the first failure.
     *
     * Returns [CommitResult.Failed] with the number of files put back rather than
     * a bare error: a rollback can itself fail on a provider that has gone away,
     * and "failed" without a count does not tell a clean abort from a project
     * left half-written.
     */
    suspend fun commit(treeUri: String, entries: List<ReviewEntry>): CommitResult =
        commitMutex.withLock { withContext(Dispatchers.IO) {
            val work = entries.filter { it.kind != ReviewKind.Reverted }
            if (work.isEmpty()) return@withContext CommitResult.Empty

            val tree = runCatching { Uri.parse(treeUri) }.getOrNull()
                ?: return@withContext CommitResult.Failed("the project uri is unusable", 0)

            val done = mutableListOf<Undo>()
            try {
                check(index.rebuild(treeUri) is SafProjectIndex.Result.Ok) { "Cannot refresh the project index." }
                for (entry in work) {
                    if (rejected(entry.path)) {
                        throw IllegalArgumentException(
                            "refusing to write outside the project: " + entry.path
                        )
                    }
                    checkFresh(entry.path)
                    when (entry.kind) {
                        ReviewKind.Deleted -> applyDelete(entry.path, done)
                        ReviewKind.Added -> applyCreate(tree, entry.path, done)
                        else -> applyWrite(tree, entry.path, done)
                    }
                }

                // The index points at documents that no longer describe the
                // project: files were added, some were deleted. Rebuilding is a
                // few hundred milliseconds once, against a preview that would
                // otherwise 404 on exactly the files that were just fixed.
                index.rebuild(treeUri)
                overlay.clear()
                CommitResult.Applied(work.size)
            } catch (failure: Throwable) {
                val restored = withContext(NonCancellable + Dispatchers.IO) { rollback(done) }
                if (failure is CancellationException) throw failure
                CommitResult.Failed(
                    failure.message ?: failure.javaClass.simpleName,
                    restored
                )
            }
        } }

    /** Throws away the sandbox without touching the project. */
    fun discard() {
        overlay.clear()
    }

    // ------------------------------------------------------------------ review

    private fun entryFor(path: String): ReviewEntry? {
        val deleted = overlay.isDeleted(path)
        val staged = overlay.resolve(path)
        val originalUri = index.resolve(path)
        val original = originalUri?.let { readBytes(it) }

        val sensitive = path.substringAfterLast('/') in ALWAYS_CONFIRM

        if (deleted) {
            // Created during the run and then deleted: nothing existed before and
            // nothing exists now, so there is nothing to show or to write.
            if (originalUri == null) return null
            return ReviewEntry(
                path = path,
                kind = ReviewKind.Deleted,
                originalBytes = original?.size ?: 0,
                newBytes = 0,
                sensitive = sensitive
            )
        }

        val next = staged?.let { runCatching { it.readBytes() }.getOrNull() } ?: return null

        if (originalUri == null) {
            return ReviewEntry(path, ReviewKind.Added, 0, next.size, sensitive)
        }

        if (original == null) {
            // The file is in the index but cannot be read now. Reported as a
            // conflict rather than a modification, because committing would
            // overwrite bytes nobody has seen.
            return ReviewEntry(path, ReviewKind.Conflict, 0, next.size, sensitive)
        }

        // Changed and changed back. Hidden rather than listed as Reverted: the
        // enum case exists so a caller can reason about it, but an entry whose
        // diff is empty has nothing for a person to decide.
        if (original.contentEquals(next)) return null

        // The user can edit the project in another app while the loop runs. The
        // overlay was built against the bytes that were there when the agent read
        // the file; if those have changed, committing silently discards their
        // edit. A conflict is shown here and checked again before any commit write.
        val base = overlay.baseHash(path)
        val drifted = base != null && base != SandboxOverlay.hash(original)

        return ReviewEntry(
            path = path,
            kind = if (drifted) ReviewKind.Conflict else ReviewKind.Modified,
            originalBytes = original.size,
            newBytes = next.size,
            sensitive = sensitive
        )
    }

    // ------------------------------------------------------------------ commit

    /** Check at commit time, not just when the review dialog was opened. */
    private fun checkFresh(path: String) {
        val base = overlay.baseHash(path) ?: error("Missing base version for $path; stage a fresh change.")
        val uri = index.resolve(path)
        if (base == SandboxOverlay.ABSENT) {
            check(uri == null) { "Conflict: $path now exists." }
        } else {
            val original = uri?.let(::readBytes) ?: error("Conflict: $path is missing or unreadable.")
            check(SandboxOverlay.hash(original) == base) { "Conflict: $path changed after staging." }
        }
    }

    private fun applyWrite(tree: Uri, path: String, journal: MutableList<Undo>) {
        val target = index.resolve(path) ?: error("Conflict: $path disappeared.")
        val original = readBytes(target) ?: error("Could not read $path.")
        check(original.size <= MAX_ROLLBACK_BYTES) { "$path is too large to recover safely." }
        val bytes = stagedBytes(path)
        // Write-ahead, including the very operation that may throw after truncating.
        ensureRecoveryCapacity(journal, original.size)
        journal += Undo.Restore(path, target, original)
        writeBytes(target, bytes)
    }

    private fun applyCreate(tree: Uri, path: String, journal: MutableList<Undo>) {
        val bytes = stagedBytes(path)
        val name = path.substringAfterLast('/')
        val parentPath = path.substringBeforeLast('/', "")
        val parent = ensureDir(tree, parentPath, journal)
        check(findChild(tree, parent, name) == null) { "Conflict: $path was created after review." }
        val created = DocumentsContract.createDocument(resolver, parent, mimeFor(name), name)
            ?: error("The folder refused to create $path.")
        journal += Undo.Remove(path, created)
        index.invalidate(path, created)
        writeBytes(created, bytes)
    }

    private fun applyDelete(path: String, journal: MutableList<Undo>) {
        val target = index.resolve(path) ?: error("$path is already gone.")
        val original = readBytes(target) ?: error("Could not read $path before deletion.")
        check(original.size <= MAX_ROLLBACK_BYTES) { "$path is too large to recover safely." }
        ensureRecoveryCapacity(journal, original.size)
        journal += Undo.Recreate(path, target, original)
        check(DocumentsContract.deleteDocument(resolver, target)) { "The folder refused to delete $path." }
        index.invalidate(path, null)
    }

    private fun ensureRecoveryCapacity(journal: List<Undo>, bytes: Int) {
        val retained = journal.sumOf { when (it) {
            is Undo.Restore -> it.original.size.toLong()
            is Undo.Recreate -> it.original.size.toLong()
            else -> 0L
        } }
        check(retained + bytes <= 32L * 1024 * 1024) { "Batch exceeds the 32 MiB recovery limit. Apply smaller batches." }
    }

    private fun rollback(done: List<Undo>): Int {
        var restored = 0
        // Reverse order so a create inside a directory this commit made is undone
        // before the directory itself.
        done.asReversed().forEach { step ->
            val ok = runCatching {
                when (step) {
                    is Undo.Restore -> writeBytes(step.uri, step.original)
                    is Undo.Remove -> {
                        check(DocumentsContract.deleteDocument(resolver, step.uri))
                        index.invalidate(step.path, null)
                    }
                    is Undo.RemoveDirectory -> {
                        val children = DocumentsContract.buildChildDocumentsUriUsingTree(step.uri, DocumentsContract.getDocumentId(step.uri))
                        val empty = resolver.query(children, arrayOf(DocumentsContract.Document.COLUMN_DOCUMENT_ID), null, null, null)
                            ?.use { !it.moveToFirst() } == true
                        check(empty) { "Recovery left a non-empty directory in place." }
                        check(DocumentsContract.deleteDocument(resolver, step.uri))
                        index.forgetDir(step.path)
                    }
                    is Undo.Recreate -> {
                        // A delete may throw without deleting anything. Do not create a duplicate.
                        val exists = runCatching { resolver.openInputStream(step.uri)?.use { true } }.getOrNull() == true
                        if (exists) writeBytes(step.uri, step.original) else recreate(step.path, step.original)
                    }
                }
            }.isSuccess
            if (ok) restored++
        }
        return restored
    }

    private fun recreate(path: String, bytes: ByteArray) {
        val name = path.substringAfterLast('/')
        val parentPath = path.substringBeforeLast('/', "")
        val parent = index.resolveDir(parentPath)
            ?: throw IllegalStateException("no parent folder for " + path)
        val created = DocumentsContract.createDocument(resolver, parent, mimeFor(name), name)
            ?: throw IllegalStateException("could not recreate " + path)
        writeBytes(created, bytes)
        index.invalidate(path, created)
    }

    // ----------------------------------------------------------------- plumbing

    private fun stagedBytes(path: String): ByteArray {
        val file = overlay.resolve(path)
            ?: throw IllegalStateException("the sandbox no longer holds " + path)
        check(file.length() <= MAX_ROLLBACK_BYTES) { "Staged file exceeds the recovery limit." }
        return runCatching { file.readBytes() }.getOrElse {
            throw IllegalStateException("the sandbox copy of " + path + " is unreadable")
        }
    }

    /**
     * Creates every missing directory along [path] and returns the deepest.
     *
     * Directories this call creates are collected so a rollback can remove them.
     * Ones that already existed are not, because deleting a folder the user has
     * other files in would be a far worse outcome than leaving an empty one.
     */
    private fun ensureDir(tree: Uri, path: String, journal: MutableList<Undo>): Uri {
        if (path.isEmpty()) {
            return index.resolveDir("")
                ?: throw IllegalStateException("the project root is not indexed")
        }
        var current = index.resolveDir("")
            ?: throw IllegalStateException("the project root is not indexed")
        var prefix = ""
        for (segment in path.split('/')) {
            if (segment.isEmpty()) continue
            prefix = if (prefix.isEmpty()) segment else prefix + "/" + segment
            val known = index.resolveDir(prefix)
            if (known != null) {
                current = known
                continue
            }
            val found = findChild(tree, current, segment)
            current = found ?: run {
                val dir = DocumentsContract.createDocument(
                    resolver,
                    current,
                    DocumentsContract.Document.MIME_TYPE_DIR,
                    segment
                ) ?: throw IllegalStateException("could not create the folder " + prefix)
                journal += Undo.RemoveDirectory(prefix, dir)
                dir
            }
            index.putDir(prefix, current)
        }
        return current
    }

    /** The child of [parent] called [name], or null. One query, not a walk. */
    private fun findChild(tree: Uri, parent: Uri, name: String): Uri? = runCatching {
        val parentId = DocumentsContract.getDocumentId(parent)
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, parentId)
        val columns = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME
        )
        resolver.query(children, columns, null, null, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                if (cursor.getString(1) == name) {
                    val id = cursor.getString(0) ?: continue
                    return@runCatching DocumentsContract.buildDocumentUriUsingTree(tree, id)
                }
            }
        }
        null
    }.getOrNull()

    private fun readBytes(uri: Uri): ByteArray? = runCatching {
        resolver.openInputStream(uri)?.use { stream ->
            val out = java.io.ByteArrayOutputStream()
            val buffer = ByteArray(8192)
            while (true) {
                val count = stream.read(buffer)
                if (count < 0) break
                check(out.size() + count <= MAX_ROLLBACK_BYTES) { "File exceeds recovery limit." }
                out.write(buffer, 0, count)
            }
            out.toByteArray()
        }
    }.getOrNull()

    private fun writeBytes(uri: Uri, bytes: ByteArray) {
        // "wt" truncates. Without it a file that got shorter keeps the tail of
        // the old version, which compiles, runs, and produces a bug that is not
        // in the code anyone is reading.
        val stream = runCatching { resolver.openOutputStream(uri, "wt") }.getOrNull()
            ?: throw IllegalStateException("the folder refused to open " + uri.lastPathSegment)
        stream.use { it.write(bytes); it.flush() }
    }

    private fun rejected(path: String): Boolean =
        runCatching { ProjectPaths.relative(path) }.isFailure

    private fun mimeFor(name: String): String = when (name.substringAfterLast('.', "").lowercase()) {
        "html", "htm" -> "text/html"
        "js", "mjs", "cjs" -> "application/javascript"
        "css" -> "text/css"
        "json", "map" -> "application/json"
        "svg" -> "image/svg+xml"
        "png" -> "image/png"
        "jpg", "jpeg" -> "image/jpeg"
        "webp" -> "image/webp"
        "wasm" -> "application/wasm"
        "txt", "md" -> "text/plain"
        "xml" -> "text/xml"
        else -> "application/octet-stream"
    }

    /** One undone step. Holds whatever putting it back requires. */
    private sealed interface Undo {
        /** A file that existed and was overwritten. */
        data class Restore(val path: String, val uri: Uri, val original: ByteArray) : Undo

        /** A file this commit created, plus the folders it had to make. */
        data class Remove(
            val path: String,
            val uri: Uri
        ) : Undo

        /** A file this commit deleted. */
        data class Recreate(val path: String, val uri: Uri, val original: ByteArray) : Undo
        data class RemoveDirectory(val path: String, val uri: Uri) : Undo
    }

    companion object {
        /**
         * Files that always need a deliberate yes, whatever else the run touched.
         *
         * Gated by what the file *is*, not by how many files changed. A wrong
         * edit to a screen costs a screen; a wrong edit to a build file or a
         * manifest costs the project, and a lockfile edit costs a dependency tree
         * nobody can reconstruct from the diff.
         */
        val ALWAYS_CONFIRM = setOf(
            "build.gradle",
            "build.gradle.kts",
            "settings.gradle",
            "settings.gradle.kts",
            "gradle.properties",
            "AndroidManifest.xml",
            "package.json",
            "package-lock.json",
            "pnpm-lock.yaml",
            "yarn.lock",
            ".env"
        )

        /**
         * Largest original this class will hold in memory to guarantee a rollback.
         *
         * Above it the commit refuses that file rather than writing something it
         * cannot undo.
         */
        const val MAX_ROLLBACK_BYTES = 8 * 1024 * 1024
    }
}
