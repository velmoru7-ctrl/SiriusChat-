package com.sirius.chat.ai.streaming;

import com.sirius.chat.core.util.BoundedIo;
import java.io.BufferedInputStream;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;

/** Bounded UTF-8 SSE lines. CR, LF and CRLF all delimit lines without waiting for EOF. */
public final class SseLines {
    private final InputStream input;
    private final int limit;
    private boolean skipLf;
    public SseLines(InputStream input, int limit) {
        if (limit < 0) throw new IllegalArgumentException("Negative line limit");
        this.input = new BufferedInputStream(input, 8192);
        this.limit = limit;
    }
    /** The response owner closes the stream; this reader never owns the HTTP call. */
    public String next() throws IOException {
        ByteArrayOutputStream line = new ByteArrayOutputStream(Math.min(limit, 256));
        while (true) {
            int b = input.read();
            if (skipLf) {
                skipLf = false;
                if (b == 10) continue;
            }
            if (b < 0) return line.size() == 0 ? null : BoundedIo.utf8(line.toByteArray());
            if (b == 13) { skipLf = true; return BoundedIo.utf8(line.toByteArray()); }
            if (b == 10) return BoundedIo.utf8(line.toByteArray());
            if (line.size() >= limit) throw new BoundedIo.LimitExceededException(limit);
            line.write(b);
        }
    }
}
