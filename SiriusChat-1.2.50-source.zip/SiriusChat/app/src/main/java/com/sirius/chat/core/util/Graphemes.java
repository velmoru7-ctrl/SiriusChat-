package com.sirius.chat.core.util;

import java.text.BreakIterator;
import java.util.ArrayList;
import java.util.Locale;

/** UTF-16 offsets, but never split a combining character or an emoji sequence. */
public final class Graphemes {
    private Graphemes() {}

    public static int[] boundaries(String text) {
        BreakIterator iterator = BreakIterator.getCharacterInstance(Locale.ROOT);
        iterator.setText(text);
        ArrayList<Integer> result = new ArrayList<>();
        result.add(0);
        int regionalRun = 0;
        int previous = -1;
        for (int index = 0; index < text.length();) {
            int current = text.codePointAt(index);
            if (index > 0 && iterator.isBoundary(index)) {
                boolean join = previous == 0x200D || current == 0x200D || combining(current) ||
                    (previous == '\r' && current == '\n') ||
                    (regional(previous) && regional(current) && regionalRun % 2 == 1);
                if (!join) result.add(index);
            }
            regionalRun = regional(current) ? regionalRun + 1 : 0;
            previous = current;
            index += Character.charCount(current);
        }
        if (text.length() > 0) result.add(text.length());
        int[] array = new int[result.size()];
        for (int i = 0; i < result.size(); i++) array[i] = result.get(i);
        return array;
    }

    private static boolean combining(int cp) {
        int type = Character.getType(cp);
        return type == Character.NON_SPACING_MARK || type == Character.COMBINING_SPACING_MARK ||
            type == Character.ENCLOSING_MARK || (cp >= 0xFE00 && cp <= 0xFE0F) ||
            (cp >= 0xE0100 && cp <= 0xE01EF) || (cp >= 0x1F3FB && cp <= 0x1F3FF) ||
            (cp >= 0xE0020 && cp <= 0xE007F);
    }

    private static boolean regional(int cp) { return cp >= 0x1F1E6 && cp <= 0x1F1FF; }

    public static Edit diff(String oldText, String newText) {
        int[] before = boundaries(oldText), after = boundaries(newText);
        int prefix = 0;
        while (prefix + 1 < before.length && prefix + 1 < after.length &&
                same(oldText, before, prefix, newText, after, prefix)) prefix++;
        int oldTail = before.length - 1, newTail = after.length - 1;
        while (oldTail > prefix && newTail > prefix &&
                same(oldText, before, oldTail - 1, newText, after, newTail - 1)) { oldTail--; newTail--; }
        return new Edit(before[prefix], before[oldTail], after[prefix], after[newTail]);
    }

    private static boolean same(String a, int[] ab, int ai, String b, int[] bb, int bi) {
        int length = ab[ai + 1] - ab[ai];
        return length == bb[bi + 1] - bb[bi] && a.regionMatches(ab[ai], b, bb[bi], length);
    }

    public static final class Edit {
        public final int oldStart, oldEnd, newStart, newEnd;
        public Edit(int oldStart, int oldEnd, int newStart, int newEnd) {
            this.oldStart = oldStart; this.oldEnd = oldEnd; this.newStart = newStart; this.newEnd = newEnd;
        }
    }
}
