package com.sirius.chat.ai.pricing;

/** Pure arithmetic, shared by production accounting and executable JVM tests. */
public final class CostMath {
    private CostMath() {}

    public static double tokenCost(long inputTokens, long outputTokens, double inputRate, double outputRate) {
        if (inputTokens < 0 || outputTokens < 0 || !validRate(inputRate) || !validRate(outputRate)) {
            throw new IllegalArgumentException("Invalid token counts or prices");
        }
        double result = inputTokens / 1_000_000.0 * inputRate + outputTokens / 1_000_000.0 * outputRate;
        if (!Double.isFinite(result)) throw new IllegalArgumentException("Cost overflow");
        return result;
    }

    public static boolean admits(double budget, double spent, double pending, double next) {
        if (!validRate(budget) || !validRate(spent) || !validRate(pending) || !validRate(next)) return false;
        double total = spent + pending + next;
        return Double.isFinite(total) && total <= budget + Math.ulp(budget) * 4;
    }

    private static boolean validRate(double value) { return Double.isFinite(value) && value >= 0.0; }
}
