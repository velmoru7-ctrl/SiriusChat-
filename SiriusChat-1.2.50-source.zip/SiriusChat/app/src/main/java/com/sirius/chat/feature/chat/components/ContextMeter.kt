package com.sirius.chat.feature.chat.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.SiriusRadius

/**
 * How full the model's context window is.
 *
 * ### Why it lives above the composer
 * This is context for what the user is about to type, not a statistic about
 * what already happened. Seeing that the window is nearly full is what makes
 * someone start a fresh chat instead of asking one more question into a
 * conversation that is about to start folding its own history away.
 *
 * ### Why it changes colour instead of warning
 * Past [FoldThreshold] the compactor will summarise the oldest turns on the
 * next send. That is a normal, recoverable thing, so it gets a colour and a
 * sentence -- not a dialog. The threshold matches the compactor's own trigger,
 * because a meter that turns amber at a different point than the behaviour it
 * describes is worse than no meter.
 */
@Composable
fun ContextMeter(fill: Float, modifier: Modifier = Modifier) {
    val colors = SiriusTheme.colors
    val known = fill.isFinite()
    val clamped = if (known) fill.coerceIn(0f, 1f) else 0f
    val folding = clamped >= FoldThreshold
    val animated by animateFloatAsState(targetValue = clamped, label = "contextFill")
    val tint = if (folding) colors.warning else colors.textTertiary

    Column(modifier = modifier.fillMaxWidth()) {
        Text(
            text = when {
                !known -> stringResource(R.string.chat_context_meter_unknown)
                folding -> stringResource(R.string.chat_context_meter_full)
                clamped > 0f && clamped < 0.01f -> stringResource(R.string.chat_context_meter_small)
                else -> stringResource(R.string.chat_context_meter, (clamped * 100).toInt())
            },
            style = MaterialTheme.typography.labelSmall,
            color = tint,
            maxLines = 1
        )
        Spacer(Modifier.height(3.dp))
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(BarHeight)
                .clip(RoundedCornerShape(SiriusRadius.pill))
                .background(colors.surfaceMuted)
        ) {
            Box(
                modifier = Modifier
                    // A genuinely empty/unknown context must not claim 2% usage.
                    .fillMaxWidth(animated.coerceIn(0f, 1f))
                    .height(BarHeight)
                    .background(tint)
            )
        }
    }
}

private const val FoldThreshold = 0.7f
private val BarHeight = 2.dp
