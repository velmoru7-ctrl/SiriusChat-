package com.sirius.chat.feature.diff

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.core.util.DiffEngine
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.ChangeKind
import com.sirius.chat.domain.model.FileDiff
import com.sirius.chat.domain.model.PendingChange
import com.sirius.chat.domain.model.Project
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

data class ReviewUiState(
    val changes: List<PendingChange> = emptyList(),
    val selectedId: String? = null,
    val diff: FileDiff? = null,
    val acceptedHunks: Set<Int> = emptySet(),
    val applying: Boolean = false,
    val message: String? = null,
    val project: Project? = null,
    /** Mirrors the global setting; the footer switch writes straight to it. */
    val autoApply: Boolean = false
) {
    val selected: PendingChange? get() = changes.firstOrNull { it.id == selectedId }
    val totalAdded: Int get() = changes.size
}

class ReviewViewModel(private val container: AppContainer) : ViewModel() {

    private data class Extras(
        val applying: Boolean,
        val message: String?,
        val project: Project?,
        val autoApply: Boolean
    )

    private val _selectedId = MutableStateFlow<String?>(null)
    private val _accepted = MutableStateFlow<Set<Int>>(emptySet())
    private val _applying = MutableStateFlow(false)
    private val _message = MutableStateFlow<String?>(null)
    private val _diff = MutableStateFlow<FileDiff?>(null)
    private var reviewed: PendingChange? = null
    private val _project = MutableStateFlow<Project?>(null)

    val state: StateFlow<ReviewUiState> = combine(
        container.changeStore.changes,
        _selectedId,
        _diff,
        _accepted,
        combine(
            _applying,
            _message,
            _project,
            container.settingsRepository.settings
        ) { applying, message, project, settings ->
            Extras(applying, message, project, settings.agentAutoApplyChanges)
        }
    ) { changes, selectedId, diff, accepted, extras ->
        ReviewUiState(
            changes = changes,
            selectedId = selectedId,
            diff = diff,
            acceptedHunks = accepted,
            applying = extras.applying,
            message = extras.message,
            project = extras.project,
            autoApply = extras.autoApply
        )
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), ReviewUiState())

    init {
        // Reading the project once meant applying failed with "no workspace"
        // whenever the folder was attached after this screen was created.
        viewModelScope.launch {
            combine(
                container.changeStore.changes,
                _selectedId,
                container.projectRepository.observeProjects()
            ) { changes, selectedId, projects ->
                val selected = changes.firstOrNull { it.id == selectedId } ?: changes.firstOrNull()
                projects.firstOrNull { it.id == selected?.projectId && it.treeUri == selected?.treeUri }
            }.distinctUntilChanged().collect { _project.value = it }
        }
        // Proposals can arrive while the screen is already open, and the very
        // first one has to become the visible diff.
        viewModelScope.launch {
            container.changeStore.changes.collect { changes ->
                val selected = _selectedId.value
                if (selected != null && changes.firstOrNull { it.id == selected }?.let { it != reviewed } == true) select(selected)
                if (selected == null || changes.none { it.id == selected }) {
                    val next = changes.firstOrNull()
                    if (next == null) {
                        _selectedId.value = null
                        _diff.value = null
                    } else {
                        select(next.id)
                    }
                }
            }
        }
    }

    fun select(changeId: String) {
        _selectedId.value = changeId
        reviewed = null
        _diff.value = null
        val change = container.changeStore.byId(changeId) ?: return
        viewModelScope.launch {
            val diff = DiffEngine.diff(
                path = change.path,
                oldText = change.oldContent,
                newText = change.newContent
            )
            if (_selectedId.value == changeId && container.changeStore.byId(changeId) == change) {
                reviewed = change
                _diff.value = diff
                _accepted.value = diff.hunks.map { it.id }.toSet()
            }
        }
    }

    fun toggleHunk(hunkId: Int) {
        val current = _accepted.value
        _accepted.value = if (hunkId in current) current - hunkId else current + hunkId
    }

    fun acceptAllHunks() {
        _accepted.value = _diff.value?.hunks?.map { it.id }?.toSet().orEmpty()
    }

    fun rejectAllHunks() {
        _accepted.value = emptySet()
    }

    /** Applies the selected change, honouring partial hunk selection. */
    fun applySelected() {
        if (_applying.value) return
        val change = container.changeStore.byId(_selectedId.value ?: return) ?: return
        if (reviewed != change) {
            select(change.id)
            _message.value = "Предложение обновилось. Проверь новый diff. / The proposal changed. Review it again."
            return
        }
        val tree = change.treeUri ?: run {
            _message.value = container.strings.get(R.string.review_no_workspace)
            return
        }
        val diff = _diff.value
        val accepted = _accepted.value

        // A partial apply needs both a diff and an old body to rebuild the file
        // from; holding them in one nullable keeps that fact in the type instead
        // of repeating the null checks at the rebuild.
        val oldContent = change.oldContent
        val partialSource = if (
            change.kind == ChangeKind.Modify &&
            diff != null &&
            oldContent != null &&
            accepted.size != diff.hunks.size
        ) {
            oldContent to diff
        } else {
            null
        }

        // Applying with every hunk excluded used to silently rewrite the file
        // with its old content.
        if (partialSource != null && accepted.isEmpty()) {
            _message.value = container.strings.get(R.string.review_nothing_selected)
            return
        }

        val effective = if (partialSource != null) {
            val (base, partialDiff) = partialSource
            change.copy(newContent = DiffEngine.applyHunks(base, partialDiff, accepted))
        } else {
            change
        }

        _applying.value = true
        viewModelScope.launch {
            val result = try { container.applyChanges(tree, listOf(effective)) }
                finally { _applying.value = false }
            if (result.success) {
                syncEditor(effective)
                container.changeStore.removeIfUnchanged(change)
                _message.value = container.strings.get(R.string.review_applied, change.path)
                container.projectContextBuilder.invalidate()
            } else {
                _message.value = result.failed.firstOrNull()?.error ?: container.strings.get(R.string.review_could_not_apply, change.path)
            }
        }
    }

    /** Keeps an open tab in sync with what was just written to disk. */
    private fun syncEditor(change: PendingChange) {
        val documentId = change.documentId ?: return
        when (change.kind) {
            // The document id these tabs point at stops existing after the
            // change lands, so keeping them open would only fail on save.
            ChangeKind.Delete, ChangeKind.Rename, ChangeKind.Move ->
                container.editorSessionStore.close(documentId, treeUri = change.treeUri)
            else -> container.editorSessionStore.syncExternalWrite(documentId, change.newContent.orEmpty(), change.treeUri)
        }
    }

    fun applyAll() {
        if (_applying.value) return
        val changes = container.changeStore.changes.value
        if (changes.isEmpty()) return
        _applying.value = true
        viewModelScope.launch {
            val results = try { changes.groupBy { it.treeUri }.map { (tree, group) ->
                if (tree.isNullOrBlank()) com.sirius.chat.domain.usecase.ApplyResult(0, group)
                else container.applyChanges(tree, group)
            } } finally { _applying.value = false }
            val result = com.sirius.chat.domain.usecase.ApplyResult(
                results.sumOf { it.applied }, results.flatMap { it.failed }
            )
            _applying.value = false
            // Only drop what actually landed; failed proposals stay so they can
            // be retried instead of disappearing.
            val failedIds = result.failed.map { it.id }.toSet()
            changes.forEach { change ->
                if (change.id !in failedIds) {
                    syncEditor(change)
                    container.changeStore.removeIfUnchanged(change)
                }
            }
            _message.value = container.strings.get(
                R.string.review_applied_count,
                result.applied,
                changes.size
            )
            container.projectContextBuilder.invalidate()
        }
    }

    fun reject(changeId: String) {
        container.changeStore.remove(changeId)
        if (_selectedId.value == changeId) {
            _selectedId.value = container.changeStore.changes.value.firstOrNull()?.id
            _selectedId.value?.let { select(it) } ?: run { _diff.value = null }
        }
    }

    fun rejectAll() {
        container.changeStore.clearAll()
        _selectedId.value = null
        _diff.value = null
    }

    fun consumeMessage() {
        _message.value = null
    }

    /**
     * Flips the global auto-apply setting from the footer.
     *
     * Offered here as well as in Settings because this is the screen where the
     * user finds out they are tired of confirming: making them leave, hunt
     * through Settings and come back is how a preference stays undiscovered.
     */
    fun setAutoApply(enabled: Boolean) {
        viewModelScope.launch {
            container.settingsRepository.update { it.copy(agentAutoApplyChanges = enabled) }
        }
    }
}
