package com.sirius.chat.domain.model

/**
 * Where a preview is in its life.
 *
 * [Running] is deliberately not the same as "loaded": a page that finished
 * loading and then threw on the first frame is the single most common failure
 * for generated games, and it looks identical to a working one in every signal
 * except the frame counter. Running means frames are actually arriving.
 */
enum class PreviewStatus {
    /** Nothing started yet. */
    Idle,

    /** Walking the project tree to build the path index. */
    Indexing,

    /** The WebView has the URL and has not finished loading it. */
    Loading,

    /** Loaded, and the frame counter is climbing. */
    Running,

    /** Loaded, but the page threw. The errors are the payload. */
    Crashed,

    /** Cannot start at all: no project, or access to it was withdrawn. */
    Unavailable
}

/** One line the page wrote to its console. */
data class ConsoleEntry(
    /** `log`, `info`, `warn`, `error` or `debug`. */
    val level: String,
    val timestampMs: Long,
    val message: String
)

/**
 * An uncaught error or a rejected promise that nobody handled.
 *
 * Kept apart from [ConsoleEntry] rather than folded in as another level. This is
 * the highest-value signal the agent gets -- it is the difference between "the
 * screen is white" and "line 41 dereferenced null" -- and burying it in a
 * hundred `console.log` lines is how a model concludes the run was fine.
 */
data class PreviewCrash(
    val message: String,
    val source: String,
    val line: Int,
    val column: Int,
    val stack: String,
    val timestampMs: Long
)

/**
 * Why a preview could not start.
 *
 * Named cases rather than a message string because the agent branches on them:
 * [AccessRevoked] means ask the user to re-pick the folder, [EntryMissing] means
 * write the file first. A model handed only prose will try to fix the game code
 * in both cases.
 */
enum class PreviewFailure {
    /** No project is attached to this conversation. */
    NoProject,

    /** The folder permission was withdrawn, or the folder is gone. */
    AccessRevoked,

    /** The entry file is not in the project. */
    EntryMissing,

    /** The page never finished loading. */
    LoadTimeout,

    /** No live WebView -- the preview screen is not on the stack. */
    NoSurface,

    /** The tree could not be read for a reason none of the above covers. */
    Unreadable
}

/** Everything the preview screen and the agent both need to know. */
data class PreviewState(
    val status: PreviewStatus = PreviewStatus.Idle,
    val url: String = "",
    val entry: String = DEFAULT_ENTRY,
    /** The page's own <title>, shown in the header once it has loaded. */
    val title: String = "",
    /**
     * Frames the page has drawn since it loaded.
     *
     * Proof of life, and the cheapest one there is. A static page reports zero
     * forever, which is correct: it is not animating.
     */
    val frames: Long = 0L,
    val errorCount: Int = 0,
    val consoleCount: Int = 0,
    val indexedFiles: Int = 0,
    val mirroredFiles: Int = 0,
    /**
     * Whether the page is running with a fixed random seed and a quantised
     * frame clock.
     *
     * Surfaced because it changes what the numbers mean. A seeded run is
     * reproducible and therefore comparable between iterations; an unseeded one
     * is not, and two screenshots that differ prove nothing.
     */
    val seeded: Boolean = false,
    /** Files the agent has written into the preview sandbox but not committed. */
    val staged: Int = 0,
    /** Frames sent to the model in this run, against [SHOT_BUDGET]. */
    val shotsTaken: Int = 0,
    val failure: PreviewFailure? = null,
    /** Human-readable detail for the failure, shown under it and sent to the model. */
    val detail: String = ""
) {
    val busy: Boolean
        get() = status == PreviewStatus.Indexing || status == PreviewStatus.Loading

    val live: Boolean
        get() = status == PreviewStatus.Running || status == PreviewStatus.Crashed

    companion object {
        const val DEFAULT_ENTRY = "index.html"

        /**
         * The origin every preview is served from.
         *
         * A real https origin, not `file://` and not a data url: ES modules,
         * `fetch`, `localStorage`, canvas textures and workers all check the
         * origin, and all of them fail or silently degrade without one.
         */
        const val ORIGIN = "https://sirius.preview/"

        /**
         * How many frames one run may send to the model.
         *
         * A compressed frame is 400-700 tokens. Ten of them is a chunk of the
         * window spent on pictures of a page whose console already said what was
         * wrong, so the budget is deliberately tight and the tool says what to
         * use instead when it runs out.
         */
        const val SHOT_BUDGET = 8
    }
}

/** Where a captured frame came from, which decides how much to trust it. */
enum class PreviewShotSource {
    /**
     * `PixelCopy` off the real window: the true composite, including WebGL and
     * CSS effects. Needs the preview screen to be on top.
     */
    Window,

    /**
     * `View.draw` into an offscreen bitmap. Works with the screen closed and
     * renders the DOM correctly, but a WebGL canvas usually comes out black --
     * the GL surface is not part of the view's own drawing.
     */
    Offscreen,

    /** `canvas.toDataURL` from inside the page. Exactly the game, nothing else. */
    Canvas,

    /** Nothing was captured. [PreviewShot.reason] says why. */
    None
}

/**
 * A captured frame, compressed and ready to travel to a vision model.
 *
 * ### Why the size is part of the type
 * An uncompressed phone frame is a megabyte, which is thousands of tokens and
 * two of them end a conversation. Every field that bounds the cost is visible
 * here so that the tool can report it and the loop can be stopped before the
 * window is gone rather than after.
 */
data class PreviewShot(
    val base64: String = "",
    val mediaType: String = "image/jpeg",
    val width: Int = 0,
    val height: Int = 0,
    val bytes: Int = 0,
    val source: PreviewShotSource = PreviewShotSource.None,
    /** Content hash, so an identical frame is not sent twice. */
    val hash: String = "",
    /**
     * Whether the frame is uniformly dark.
     *
     * Reported rather than hidden. A black frame from [PreviewShotSource.Offscreen]
     * usually means "WebGL, screen closed" and not "the game draws nothing", and a
     * model that is not told the difference rewrites a renderer that worked.
     */
    val black: Boolean = false,
    /** Elements the page is showing, as a text outline. Cheap, and often enough. */
    val outline: List<String> = emptyList(),
    val reason: String = ""
) {
    val ok: Boolean get() = base64.isNotEmpty()
    val sizeKb: Int get() = bytes / 1024
}

/** What one tap did, in the page's own words. */
data class PreviewTapResult(
    val ok: Boolean,
    val element: String = "",
    /** True when the synthetic events were followed by a real MotionEvent. */
    val real: Boolean = false,
    val framesBefore: Long = 0L,
    val framesAfter: Long = 0L,
    val errors: Int = 0,
    val reason: String = ""
) {
    val moved: Boolean get() = framesAfter > framesBefore
}

/**
 * How one file ended up after a run, against how it started.
 *
 * ### Why [Reverted] exists
 * A repair loop routinely breaks a file and then puts it back. That is two
 * writes and zero difference, and showing it as a change means the review is
 * padded with entries whose diff is empty -- which is how a user learns to press
 * Apply without reading.
 *
 * ### Why [Conflict] exists
 * The user can edit the project in another editor while the loop is running. The
 * overlay was computed against the older bytes, so committing it would delete
 * their edit without ever mentioning it.
 */
enum class ReviewKind { Added, Modified, Deleted, Reverted, Conflict }

data class ReviewEntry(
    val path: String,
    val kind: ReviewKind,
    val originalBytes: Int,
    val newBytes: Int,
    /**
     * Whether this file always needs a deliberate yes.
     *
     * Build files, manifests and lockfiles are the ones where a wrong edit
     * breaks the project rather than a screen, so they are gated by what the
     * file *is* and not by how many files the run touched.
     */
    val sensitive: Boolean = false
) {
    val delta: Int get() = newBytes - originalBytes
}

/** The outcome of writing a sandbox to the real project. */
sealed interface CommitResult {
    data class Applied(val files: Int) : CommitResult

    /** Nothing to write. Not an error -- the run may simply have read things. */
    data object Empty : CommitResult

    /**
     * A write failed and everything already written was put back.
     *
     * [rolledBack] is the count restored, and it is reported rather than assumed:
     * a rollback can itself fail on a provider that has gone away, and a user
     * told "failed" without a number cannot tell a clean abort from a half-
     * applied project.
     */
    data class Failed(val reason: String, val rolledBack: Int) : CommitResult
}

/**
 * The preview sandbox, as the agent's file tools see it.
 *
 * ### Why this is an interface in the domain layer
 * The write tools need to know whether a preview run is collecting their edits,
 * and the preview controller lives in `data`. Rather than have the tool layer
 * import a concrete WebView-owning class -- which would also make every tool
 * test drag a WebView in -- the tools depend on this, and the controller
 * implements it.
 *
 * ### Why reads matter as much as writes
 * If `read_file` keeps returning the committed original while the sandbox holds
 * a newer version, the model reads code it has already fixed and fixes it again.
 * [sandboxRead] is what stops that.
 */
interface PreviewSandbox {
    /** True while a preview run is collecting writes instead of proposing them. */
    val sandboxActive: Boolean

    /** The sandbox copy of [path] as text, or null when it holds none. */
    fun sandboxRead(path: String): String?

    /** True when the run deleted [path]; reads must not fall through to the original. */
    fun sandboxDeleted(path: String): Boolean

    /**
     * Stages [text] for [path].
     *
     * [baseText] is what the file held when the agent read it, and it is passed
     * as text rather than as a hash so that no caller outside the preview needs
     * to know how the sandbox identifies a version. It is what makes it possible
     * to notice later that the user edited the same file in another app while the
     * run was in progress.
     */
    fun sandboxWrite(path: String, text: String, baseText: String?)

    fun sandboxDelete(path: String, baseText: String?)

    /** How many paths the run has touched, for the review header. */
    val sandboxCount: Int
}
