package com.sirius.chat.domain.usecase

import com.sirius.chat.core.util.ProjectPaths
import com.sirius.chat.domain.model.ChangeKind
import com.sirius.chat.domain.model.ChangeStatus
import com.sirius.chat.domain.model.PendingChange
import com.sirius.chat.domain.repository.WorkspaceRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock

data class ApplyResult(val applied: Int, val failed: List<PendingChange>) {
    val success: Boolean get() = failed.isEmpty()
}

/** Serializes local review batches and refuses stale or unscoped proposals. */
class ApplyChangesUseCase(private val workspace: WorkspaceRepository) {
    private val mutex = Mutex()

    suspend operator fun invoke(treeUri: String, changes: List<PendingChange>): ApplyResult = mutex.withLock {
        var applied = 0
        val failed = ArrayList<PendingChange>()
        for (change in changes) {
            try {
                require(treeUri.isNotBlank() && change.treeUri == treeUri) { "The proposal belongs to a different workspace." }
                check(applyOne(treeUri, change)) { "Storage operation failed; the proposal was kept." }
                applied++
            } catch (cancel: CancellationException) {
                throw cancel
            } catch (error: Exception) {
                failed += change.copy(status = ChangeStatus.Failed, error = error.message)
            }
        }
        ApplyResult(applied, failed)
    }

    private suspend fun applyOne(tree: String, change: PendingChange): Boolean {
        val path = ProjectPaths.relative(change.path)
        when (change.kind) {
            ChangeKind.Create -> {
                check(!workspace.exists(tree, path)) { "Conflict: $path already exists. Review a fresh proposal." }
                val base = change.parentDocumentId ?: workspace.rootNode(tree)?.documentId ?: return false
                val parent = ensureFolders(tree, base, change.missingParents) ?: return false
                val content = change.newContent ?: error("New content is missing.")
                val created = workspace.createFile(tree, parent, path.substringAfterLast('/')) ?: return false
                if (workspace.writeText(tree, created.documentId, content)) return true
                workspace.delete(tree, created.documentId)
                return false
            }
            ChangeKind.Modify, ChangeKind.Delete -> {
                val node = workspace.findByPath(tree, path) ?: error("Conflict: $path no longer exists.")
                check(!node.isDirectory && node.documentId == change.documentId) { "Conflict: file identity changed." }
                val original = change.oldContent ?: error("The original content is missing; re-read the file.")
                check(workspace.readTextExact(tree, node.documentId) == original) {
                    "Conflict: $path changed since this proposal. Your newer edits were not overwritten."
                }
                if (change.kind == ChangeKind.Delete) return workspace.delete(tree, node.documentId)
                val next = change.newContent ?: error("New content is missing.")
                if (workspace.writeText(tree, node.documentId, next)) return true
                check(workspace.writeText(tree, node.documentId, original)) {
                    "Write and recovery failed. Keep this proposal: it contains the original file."
                }
                return false
            }
            ChangeKind.Move -> {
                check(!workspace.exists(tree, path)) { "Destination already exists; nothing was overwritten." }
                val sourcePath = ProjectPaths.relative(change.sourcePath ?: error("Source path is missing."))
                val source = workspace.findByPath(tree, sourcePath) ?: return false
                check(source.documentId == change.documentId) { "Source identity changed." }
                val sourceParent = change.sourceParentDocumentId ?: return false
                val target = change.parentDocumentId ?: return false
                // Move the actual bytes. Preview text (possibly truncated) is never a transfer primitive.
                return workspace.move(tree, source.documentId, sourceParent, target) != null
            }
            ChangeKind.Rename -> {
                val name = change.newName ?: return false
                require(ProjectPaths.relative(name) == name && !name.contains('/')) { "Invalid new name." }
                val source = workspace.findByPath(tree, path) ?: return false
                check(source.documentId == change.documentId) { "Source identity changed." }
                if (source.name == name) return true
                val parent = path.substringBeforeLast('/', "")
                val target = if (parent.isEmpty()) name else "$parent/$name"
                check(!workspace.exists(tree, target)) { "Destination already exists." }
                return workspace.rename(tree, source.documentId, name) != null
            }
        }
    }

    private suspend fun ensureFolders(tree: String, parentId: String, segments: List<String>): String? {
        var current = parentId
        for (segment in segments) {
            require(ProjectPaths.relative(segment) == segment && !segment.contains('/')) { "Invalid folder name." }
            val existing = workspace.listChildren(tree, current, "").firstOrNull { it.name == segment }
            check(existing == null || existing.isDirectory) { "A file blocks the destination folder." }
            current = (existing ?: workspace.createDirectory(tree, current, segment))?.documentId ?: return null
        }
        return current
    }
}
