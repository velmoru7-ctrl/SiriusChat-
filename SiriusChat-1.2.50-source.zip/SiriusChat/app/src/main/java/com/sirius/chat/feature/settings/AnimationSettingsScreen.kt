package com.sirius.chat.feature.settings

import android.os.Build
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.ArrowDownward
import androidx.compose.material.icons.rounded.AutoAwesome
import androidx.compose.material.icons.rounded.BlurOn
import androidx.compose.material.icons.rounded.RotateRight
import androidx.compose.material.icons.rounded.SpaceBar
import androidx.compose.material.icons.rounded.ZoomOutMap
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.components.decorative
import com.sirius.chat.core.designsystem.effects.AnimatedRevealText
import com.sirius.chat.core.designsystem.revealIn
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.domain.model.TextAnimationSettings
import kotlinx.coroutines.delay

/**
 * Everything about how characters arrive in the composer.
 *
 * Its own screen rather than a block on the main settings page for the same
 * reason the editor has one: thirteen controls that only make sense together,
 * and a preview that has to be on screen at the same time as the sliders that
 * change it. Folded into the main list they would be a wall of switches between
 * "Language" and "AI".
 */
@Composable
fun AnimationSettingsScreen(
    onBack: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: SettingsViewModel = siriusViewModel { SettingsViewModel(it) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val animation = state.settings.textAnimation
    val colors = SiriusTheme.colors
    val reduceMotion = SiriusTheme.reduceMotion

    val scroll = rememberScrollState()
    val scrolled by remember { derivedStateOf { scroll.value > 4 } }

    Column(modifier = Modifier.fillMaxSize()) {
        SiriusTopBar(
            title = stringResource(R.string.animation_title),
            subtitle = stringResource(R.string.animation_subtitle),
            scrolled = scrolled,
            onBack = onBack
        )
        Column(
            modifier = Modifier
                .verticalScroll(scroll)
                .padding(
                    start = SiriusSpacing.sm,
                    end = SiriusSpacing.sm,
                    top = SiriusSpacing.xs,
                    bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xl
                )
        ) {
            TextAnimationExtraControls(animation) { value -> viewModel.setTextAnimation { value } }
            VSpace(SiriusSpacing.sm)
            GlassCard(modifier = Modifier.revealIn(index = 0)) {
                SettingToggle(
                    icon = Icons.Rounded.AutoAwesome,
                    title = stringResource(R.string.animation_enable),
                    subtitle = stringResource(R.string.animation_enable_subtitle),
                    checked = animation.enabled,
                    // Reduce motion is a promise, not a preference to weigh
                    // against this one. The switch stays visible so the state is
                    // still readable, but it cannot be turned on from here.
                    enabled = !reduceMotion,
                    onCheckedChange = { on ->
                        viewModel.setTextAnimation { it.copy(enabled = on) }
                    }
                )
                if (reduceMotion) {
                    Text(
                        text = stringResource(R.string.animation_reduce_motion_note),
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textTertiary,
                        modifier = Modifier.padding(top = SiriusSpacing.xxs)
                    )
                }
                VSpace(SiriusSpacing.sm)
                // The preview runs the real effect with the real settings, so
                // there is nothing here that can agree with itself while
                // disagreeing with the composer.
                AnimationPreview(settings = animation)
            }

            AnimatedVisibility(visible = animation.enabled) {
                Column {
                    VSpace(SiriusSpacing.sm)
                    GlassCard(modifier = Modifier.revealIn(index = 1)) {
                        CardTitle(stringResource(R.string.animation_section_appearance))
                        SliderRow(
                            label = stringResource(R.string.animation_duration),
                            value = animation.durationMillis.toFloat(),
                            valueLabel = stringResource(
                                R.string.animation_value_ms,
                                animation.durationMillis
                            ),
                            range = TextAnimationSettings.DurationRange.asFloatRange(),
                            onChange = { value ->
                                viewModel.setTextAnimation {
                                    it.copy(durationMillis = value.toInt())
                                }
                            }
                        )
                        SettingToggle(
                            icon = Icons.Rounded.SpaceBar,
                            title = stringResource(R.string.animation_ignore_spaces),
                            subtitle = stringResource(
                                R.string.animation_ignore_spaces_subtitle
                            ),
                            checked = animation.ignoreSpaces,
                            onCheckedChange = { on ->
                                viewModel.setTextAnimation { it.copy(ignoreSpaces = on) }
                            }
                        )
                    }

                    VSpace(SiriusSpacing.sm)
                    GlassCard(modifier = Modifier.revealIn(index = 2)) {
                        CardTitle(stringResource(R.string.animation_section_blur))
                        SettingToggle(
                            icon = Icons.Rounded.BlurOn,
                            title = stringResource(R.string.animation_blur),
                            subtitle = stringResource(R.string.animation_blur_subtitle),
                            checked = animation.blurEnabled,
                            onCheckedChange = { on ->
                                viewModel.setTextAnimation { it.copy(blurEnabled = on) }
                            }
                        )
                        // Said once, where the switch is, rather than left for
                        // the user to discover by turning it on and seeing
                        // nothing change.
                        if (animation.blurEnabled &&
                            Build.VERSION.SDK_INT < Build.VERSION_CODES.S
                        ) {
                            Text(
                                text = stringResource(R.string.animation_blur_unsupported),
                                style = MaterialTheme.typography.bodySmall,
                                color = colors.textTertiary,
                                modifier = Modifier.padding(bottom = SiriusSpacing.xxs)
                            )
                        }
                        SliderRow(
                            label = stringResource(R.string.animation_blur_duration),
                            value = animation.blurDurationMillis.toFloat(),
                            valueLabel = stringResource(
                                R.string.animation_value_ms,
                                animation.blurDurationMillis
                            ),
                            range = TextAnimationSettings.DurationRange.asFloatRange(),
                            onChange = { value ->
                                viewModel.setTextAnimation {
                                    it.copy(blurDurationMillis = value.toInt())
                                }
                            }
                        )
                        SliderRow(
                            label = stringResource(R.string.animation_blur_radius),
                            value = animation.blurRadius.toFloat(),
                            valueLabel = animation.blurRadius.toString(),
                            range = TextAnimationSettings.BlurRadiusRange.asFloatRange(),
                            onChange = { value ->
                                viewModel.setTextAnimation {
                                    it.copy(blurRadius = value.toInt())
                                }
                            }
                        )
                        SliderRow(
                            label = stringResource(R.string.animation_blur_hold),
                            value = animation.blurHoldPercent.toFloat(),
                            valueLabel = stringResource(
                                R.string.animation_value_percent,
                                animation.blurHoldPercent
                            ),
                            range = TextAnimationSettings.BlurHoldRange.asFloatRange(),
                            onChange = { value ->
                                viewModel.setTextAnimation {
                                    it.copy(blurHoldPercent = value.toInt())
                                }
                            }
                        )
                    }

                    VSpace(SiriusSpacing.sm)
                    GlassCard(modifier = Modifier.revealIn(index = 3)) {
                        CardTitle(stringResource(R.string.animation_section_motion))
                        SettingToggle(
                            icon = Icons.Rounded.ArrowDownward,
                            title = stringResource(R.string.animation_slide),
                            subtitle = stringResource(R.string.animation_slide_subtitle),
                            checked = animation.slideEnabled,
                            onCheckedChange = { on ->
                                viewModel.setTextAnimation { it.copy(slideEnabled = on) }
                            }
                        )
                        if (animation.slideEnabled) {
                            SliderRow(
                                label = stringResource(R.string.animation_slide_distance),
                                value = animation.slideDistanceDp.toFloat(),
                                valueLabel = stringResource(
                                    R.string.animation_value_dp,
                                    animation.slideDistanceDp
                                ),
                                range = TextAnimationSettings.SlideDistanceRange
                                    .asFloatRange(),
                                onChange = { value ->
                                    viewModel.setTextAnimation {
                                        it.copy(slideDistanceDp = value.toInt())
                                    }
                                }
                            )
                        }
                        SettingToggle(
                            icon = Icons.Rounded.ZoomOutMap,
                            title = stringResource(R.string.animation_scale),
                            subtitle = stringResource(R.string.animation_scale_subtitle),
                            checked = animation.scaleEnabled,
                            onCheckedChange = { on ->
                                viewModel.setTextAnimation { it.copy(scaleEnabled = on) }
                            }
                        )
                        if (animation.scaleEnabled) {
                            SliderRow(
                                label = stringResource(R.string.animation_scale_start),
                                value = animation.scaleStart,
                                valueLabel = stringResource(
                                    R.string.animation_value_scale,
                                    animation.scaleStart
                                ),
                                range = TextAnimationSettings.ScaleStartMin..
                                    TextAnimationSettings.ScaleStartMax,
                                // One decimal is the whole useful resolution
                                // here, and stops let the handle land on it.
                                steps = SCALE_STEPS,
                                onChange = { value ->
                                    viewModel.setTextAnimation {
                                        it.copy(scaleStart = value)
                                    }
                                }
                            )
                        }
                        SettingToggle(
                            icon = Icons.Rounded.RotateRight,
                            title = stringResource(R.string.animation_rotate),
                            subtitle = stringResource(R.string.animation_rotate_subtitle),
                            checked = animation.rotateEnabled,
                            onCheckedChange = { on ->
                                viewModel.setTextAnimation { it.copy(rotateEnabled = on) }
                            }
                        )
                        if (animation.rotateEnabled) {
                            SliderRow(
                                label = stringResource(R.string.animation_rotate_angle),
                                value = animation.rotateDegrees.toFloat(),
                                valueLabel = stringResource(
                                    R.string.animation_value_degrees,
                                    animation.rotateDegrees
                                ),
                                range = TextAnimationSettings.RotateRange.asFloatRange(),
                                onChange = { value ->
                                    viewModel.setTextAnimation {
                                        it.copy(rotateDegrees = value.toInt())
                                    }
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}

/**
 * The sample the sliders are judged against.
 *
 * Types itself out on a loop rather than showing finished text, because every
 * control on this screen changes something that only exists while a character
 * is arriving. A static sample would show none of them.
 */
@Composable
private fun AnimationPreview(settings: TextAnimationSettings) {
    val colors = SiriusTheme.colors
    val sample = stringResource(R.string.animation_preview_sample)
    val reduceMotion = SiriusTheme.reduceMotion

    // Under Reduce Motion the sample is simply shown. A preview that retypes
    // itself forever is autoplaying motion, and the preference asks for none.
    var typed by remember(sample, reduceMotion) {
        mutableStateOf(if (reduceMotion) sample else "")
    }

    if (!reduceMotion) {
        // Deliberately not keyed on the settings. Restarting on every value would
        // reset the sample under a dragging thumb, so the one moment the preview
        // exists for -- watching a change take effect -- is the one it would miss.
        LaunchedEffectLoop(sample) { next -> typed = next }
    }

    Box(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(min = PreviewMinHeight)
            // Concentric with the card around it: its 24dp radius minus its
            // 16dp padding. A mismatch here is the detail that reads as sloppy.
            .clip(RoundedCornerShape(SiriusRadius.xs))
            .background(colors.surfaceMuted)
            .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs)
            // A sample that retypes itself every two seconds would be announced
            // every two seconds. The controls above already say what it shows.
            .decorative()
    ) {
        AnimatedRevealText(
            text = typed,
            // The composer's metrics, not this screen's, so the preview is the
            // size the effect will actually run at.
            style = MaterialTheme.typography.bodyLarge.copy(
                color = colors.textPrimary,
                fontSize = 19.sp,
                lineHeight = 26.sp
            ),
            settings = settings,
            modifier = Modifier.fillMaxWidth()
        )
    }
}

/** Types [sample] out, holds it, clears it, and starts again. */
@Composable
private fun LaunchedEffectLoop(sample: String, onText: (String) -> Unit) {
    LaunchedEffect(sample) {
        while (true) {
            val boundaries = com.sirius.chat.core.util.Graphemes.boundaries(sample)
            for (end in boundaries.drop(1)) {
                onText(sample.substring(0, end))
                delay(TypeDelayMs)
            }
            delay(HoldMs)
            for (end in boundaries.dropLast(1).reversed()) {
                onText(sample.substring(0, end))
                delay(TypeDelayMs)
            }
            delay(RestartDelayMs)
        }
    }
}

@Composable
private fun CardTitle(text: String) {
    Text(
        text = text,
        style = MaterialTheme.typography.titleSmall,
        color = SiriusTheme.colors.textPrimary,
        modifier = Modifier.padding(bottom = SiriusSpacing.xxs)
    )
}

/** Sliders take a float range; the settings are stored as the ints they are. */
private fun IntRange.asFloatRange(): ClosedFloatingPointRange<Float> =
    first.toFloat()..last.toFloat()

/** 0.0 to 1.0 in tenths. */
private const val SCALE_STEPS = 9

private const val TypeDelayMs = 90L
private const val HoldMs = 900L
private const val RestartDelayMs = 420L

private val PreviewMinHeight = 44.dp
