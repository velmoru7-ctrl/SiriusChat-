package com.sirius.chat.core.util;

import java.util.ArrayList;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

/** Identity-based selection. Never fall back to unowned ids or timestamp ranges. */
public final class MessageSelection {
    private MessageSelection() {}

    public static List<String> ownedSelection(List<String> orderedIds, Collection<String> requestedIds) {
        Set<String> requested = new HashSet<>(requestedIds);
        List<String> result = new ArrayList<>();
        for (String id : orderedIds) {
            if (requested.remove(id)) result.add(id);
        }
        return result;
    }

    public static List<String> fromAnchor(List<String> orderedIds, String anchorId) {
        int index = orderedIds.indexOf(anchorId);
        return index < 0 ? new ArrayList<>() : new ArrayList<>(orderedIds.subList(index, orderedIds.size()));
    }
}
