package com.sirius.chat.data.preview

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.view.MotionEvent
import android.view.View
import android.webkit.WebChromeClient
import android.webkit.WebResourceError
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.webkit.WebViewAssetLoader
import androidx.webkit.WebViewCompat
import androidx.webkit.WebViewFeature
import com.sirius.chat.domain.model.CommitResult
import com.sirius.chat.domain.model.ConsoleEntry
import com.sirius.chat.domain.model.PreviewCrash
import com.sirius.chat.domain.model.PreviewFailure
import com.sirius.chat.domain.model.PreviewSandbox
import com.sirius.chat.domain.model.PreviewShot
import com.sirius.chat.domain.model.PreviewShotSource
import com.sirius.chat.domain.model.PreviewState
import com.sirius.chat.domain.model.PreviewStatus
import com.sirius.chat.domain.model.PreviewTapResult
import com.sirius.chat.domain.model.ReviewEntry
import java.io.ByteArrayInputStream
import java.io.File
import kotlin.coroutines.resume
import kotlinx.coroutines.CompletableDeferred
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import org.json.JSONArray
import org.json.JSONObject
import org.json.JSONTokener

/** What the page reported the last time it was asked. */
data class PreviewReport(
    val ok: Boolean,
    val frames: Long = 0L,
    val uptimeMs: Long = 0L,
    val url: String = "",
    val title: String = "",
    val throttled: Boolean = false,
    val logs: List<ConsoleEntry> = emptyList(),
    val errors: List<PreviewCrash> = emptyList(),
    val reason: String = ""
)

/** The result of holding still for a while. */
data class PreviewWait(
    val frames: Long,
    val advancedBy: Long,
    val elapsedMs: Long,
    val throttled: Boolean,
    val errors: Int
)

/**
 * Owns the previewed page: its origin, its WebView, and everything the agent
 * asks it.
 *
 * ### Why the WebView lives here and not on the screen
 * The agent starts previews while the user is reading the chat. If the WebView
 * belonged to the preview screen then every tool call would depend on which tab
 * happened to be open, and leaving the screen mid-run would destroy the page the
 * next tool call was about to inspect. So the controller owns one long-lived
 * WebView and the screen borrows it.
 *
 * The cost of that choice is real and worth naming: an unattached WebView is
 * throttled, and `requestAnimationFrame` may not fire at all. Script execution,
 * console capture and error capture are unaffected -- which is precisely the
 * part stage two needs -- and the harness falls back to a coarse heartbeat so
 * "is it alive" stays answerable. True frame rate and real screenshots need the
 * screen open, and the tools say so rather than returning a plausible zero.
 */
class PreviewController(context: Context) : PreviewSandbox {

    private val app: Context = context.applicationContext
    @Volatile private var ownerTree: String? = null
    @Volatile private var ownerSession: String? = null
    @Volatile private var committing = false
    private val startMutex = kotlinx.coroutines.sync.Mutex()

    @Synchronized
    fun claimSession(sessionId: String, treeUri: String?): Boolean {
        if (committing || treeUri.isNullOrBlank() || ownerTree != treeUri) return false
        if (ownerSession == null) ownerSession = sessionId
        return ownerSession == sessionId
    }

    fun sandboxFor(sessionId: String, treeUri: String?): PreviewSandbox = object : PreviewSandbox {
        private fun owns() = claimSession(sessionId, treeUri)
        override val sandboxActive: Boolean get() = this@PreviewController.sandboxActive && owns()
        override fun sandboxRead(path: String): String? = if (owns()) this@PreviewController.sandboxRead(path) else null
        override fun sandboxDeleted(path: String): Boolean = owns() && this@PreviewController.sandboxDeleted(path)
        override fun sandboxWrite(path: String, text: String, baseText: String?) {
            synchronized(this@PreviewController) {
                check(owns()) { "Preview belongs to a different project or chat." }
                this@PreviewController.sandboxWrite(path, text, baseText)
            }
        }
        override fun sandboxDelete(path: String, baseText: String?) {
            synchronized(this@PreviewController) {
                check(owns()) { "Preview belongs to a different project or chat." }
                this@PreviewController.sandboxDelete(path, baseText)
            }
        }
        override val sandboxCount: Int get() = if (owns()) this@PreviewController.sandboxCount else 0
    }

    private val resolver = app.contentResolver

    private val mirrorRoot = File(app.cacheDir, "preview/mirror")
    private val overlayRoot = File(app.cacheDir, "preview/overlay")

    val index = SafProjectIndex(resolver, mirrorRoot)
    val overlay = SandboxOverlay(overlayRoot)

    private val committer = SandboxCommitter(resolver, index, overlay)

    private val loader: WebViewAssetLoader = WebViewAssetLoader.Builder()
        .setDomain(HOST)
        .addPathHandler("/", PreviewPathHandler(resolver, index, overlay))
        .build()

    private val _state = MutableStateFlow(PreviewState())
    val state: StateFlow<PreviewState> = _state.asStateFlow()

    private var web: WebView? = null
    private var pageLoad: CompletableDeferred<Boolean>? = null
    private var startedAtMs: Long = 0L

    /**
     * Per-run state: determinism, and the budget that keeps vision affordable.
     *
     * A seed of zero means "leave the page alone". Anything higher travels to the
     * harness through the URL, the only channel that reaches a page before its
     * own scripts run.
     */
    private var seed: Int = 0
    private var shots: Int = 0
    private var lastShotHash: String = ""

    // ---------------------------------------------------------------- surface

    /**
     * The WebView, created on first use. Main thread only.
     *
     * The preview screen adds this to its own container and removes it again on
     * dispose; it never creates one of its own.
     */
    @SuppressLint("SetJavaScriptEnabled")
    fun obtainView(): WebView {
        web?.let { return it }
        val view = WebView(app)
        view.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            // The two that matter. With file access on, one line of injected
            // script reads the user's whole filesystem through the origin we
            // just handed the page.
            allowFileAccess = false
            allowContentAccess = false
            mediaPlaybackRequiresUserGesture = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            loadWithOverviewMode = true
            useWideViewPort = true
            cacheMode = WebSettings.LOAD_NO_CACHE
            setSupportZoom(false)
            builtInZoomControls = false
        }
        view.setBackgroundColor(Color.BLACK)
        view.isVerticalScrollBarEnabled = false
        view.isHorizontalScrollBarEnabled = false
        view.webViewClient = client()
        view.webChromeClient = WebChromeClient()

        // The correct injection point: this runs before the document's own
        // scripts, so a module that throws while parsing is still captured.
        // onPageStarted below is the fallback for devices without it, and it is
        // a worse one -- it can lose the very first exception.
        if (WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
            runCatching {
                WebViewCompat.addDocumentStartJavaScript(
                    view,
                    PreviewHarness.SOURCE,
                    setOf(ORIGIN_RULE)
                )
            }
        }
        web = view
        return view
    }

    private fun client(): WebViewClient = object : WebViewClient() {

        override fun shouldInterceptRequest(
            view: WebView,
            request: WebResourceRequest
        ): WebResourceResponse? {
            val url = request.url
            if (!HOST.equals(url.host, ignoreCase = true)) {
                // Refused rather than allowed through. A generated page that
                // pulls a CDN script would work on the desk and fail on a plane,
                // and worse, it would be running code nobody reviewed inside an
                // origin that can read the project.
                return blocked()
            }
            return loader.shouldInterceptRequest(url)
        }

        override fun onPageStarted(view: WebView, url: String, favicon: Bitmap?) {
            if (!WebViewFeature.isFeatureSupported(WebViewFeature.DOCUMENT_START_SCRIPT)) {
                view.evaluateJavascript(PreviewHarness.SOURCE, null)
            }
            _state.update { it.copy(status = PreviewStatus.Loading, url = url) }
        }

        override fun onPageFinished(view: WebView, url: String) {
            pageLoad?.complete(true)
        }

        override fun onReceivedError(
            view: WebView,
            request: WebResourceRequest,
            error: WebResourceError
        ) {
            // Only a failure of the main document stops the preview. A missing
            // sprite is a 404 the agent should read in the console, not a reason
            // to declare the page dead.
            if (!request.isForMainFrame) return
            pageLoad?.complete(false)
            _state.update {
                it.copy(
                    status = PreviewStatus.Crashed,
                    detail = error.description?.toString().orEmpty()
                )
            }
        }
    }

    private fun blocked(): WebResourceResponse = WebResourceResponse(
        "text/plain",
        "utf-8",
        403,
        "Blocked by Sirius preview",
        mapOf("Access-Control-Allow-Origin" to "*"),
        ByteArrayInputStream(ByteArray(0))
    )

    // ------------------------------------------------------------------ start

    /**
     * Indexes the project and loads [entry].
     *
     * Returns the state rather than throwing, because every one of these
     * failures is something the model has to read and act on differently.
     */
    suspend fun start(
        treeUri: String?,
        entry: String,
        width: Int,
        height: Int,
        seed: Int = 0,
        sessionId: String? = null
    ): PreviewState {
        startMutex.lock()
        try { return startOwned(treeUri, entry, width, height, seed, sessionId) }
        finally { startMutex.unlock() }
    }

    private suspend fun startOwned(treeUri: String?, entry: String, width: Int, height: Int,
        seed: Int, sessionId: String?): PreviewState {
        if (treeUri.isNullOrBlank()) {
            return fail(PreviewFailure.NoProject, "no project folder is attached to this chat")
        }
        synchronized(this) {
        if (committing || (ownerTree != null &&
                (ownerTree != treeUri || (sessionId != null && ownerSession != null && ownerSession != sessionId)) &&
                (sandboxActive || !overlay.isEmpty))) {
            return _state.value.copy(failure = PreviewFailure.Unreadable,
                detail = "Preview belongs to another project or chat. Stop it and apply or discard its changes first.")
        }
        if (ownerTree != treeUri) ownerSession = null
        ownerTree = treeUri
        if (sessionId != null) ownerSession = sessionId
        }
        // Both belong to the page that is about to load, not to the controller's
        // lifetime: a restart is the documented way out of a spent budget, and a
        // stale frame hash would silently swallow the first frame of a new page.
        this.seed = seed.coerceAtLeast(0)
        shots = 0
        lastShotHash = ""
        _state.update {
            it.copy(status = PreviewStatus.Indexing, failure = null, detail = "", frames = 0L)
        }

        when (val result = withContext(Dispatchers.IO) { index.rebuild(treeUri) }) {
            is SafProjectIndex.Result.AccessRevoked -> return fail(
                PreviewFailure.AccessRevoked,
                "the folder permission was withdrawn; ask the user to pick the project folder again"
            )

            is SafProjectIndex.Result.Unreadable -> return fail(
                PreviewFailure.Unreadable,
                result.reason
            )

            is SafProjectIndex.Result.Ok -> _state.update {
                it.copy(indexedFiles = result.files, mirroredFiles = result.mirrored)
            }
        }

        val target = entryOrDefault(entry)
        if (overlay.isDeleted(target) ||
            (overlay.resolve(target) == null && index.resolve(target) == null)
        ) {
            return fail(
                PreviewFailure.EntryMissing,
                "the project has no file called " + target + "; write it first"
            )
        }

        return load(target, width, height)
    }

    /** Reloads the current entry without re-walking the tree. */
    suspend fun reload(width: Int, height: Int): PreviewState =
        load(_state.value.entry, width, height)

    private suspend fun load(target: String, width: Int, height: Int): PreviewState {
        val signal = CompletableDeferred<Boolean>()
        withContext(Dispatchers.Main) {
            val view = obtainView()
            pageLoad = signal
            startedAtMs = System.currentTimeMillis()
            // An unattached view has no size, and a page laid out at zero width
            // renders as a blank strip that looks exactly like a crash.
            if (view.parent == null && width > 0 && height > 0) {
                val spec = View.MeasureSpec.EXACTLY
                view.measure(
                    View.MeasureSpec.makeMeasureSpec(width, spec),
                    View.MeasureSpec.makeMeasureSpec(height, spec)
                )
                view.layout(0, 0, width, height)
            }
            // The query string is the only channel that reaches the page before
            // its own scripts run. The asset loader hands the path handler a path
            // alone, so a seed never takes part in file lookup.
            val url = PreviewState.ORIGIN + target +
                if (seed > 0) "?" + PreviewHarness.SEED_PARAM + "=" + seed else ""
            _state.update {
                it.copy(
                    status = PreviewStatus.Loading,
                    entry = target,
                    url = url,
                    frames = 0L,
                    errorCount = 0,
                    consoleCount = 0,
                    seeded = seed > 0,
                    failure = null,
                    detail = ""
                )
            }
            view.loadUrl(url)
        }

        val finished = withTimeoutOrNull(LOAD_TIMEOUT_MS) { signal.await() }
        if (finished == null) {
            return fail(PreviewFailure.LoadTimeout, "the page did not finish loading in 15s")
        }
        if (finished == false) return _state.value

        // One settle frame before the first read: a page that throws does so in
        // its first tick, and reporting Running and then Crashed a moment later
        // makes the UI flicker and the model disbelieve both.
        delay(SETTLE_MS)
        val report = report(0L, "all")
        return applyReport(report)
    }

    // ------------------------------------------------------------------- read

    /** Asks the page for its counters, its console and its crashes. */
    suspend fun report(sinceMs: Long, level: String): PreviewReport {
        val view = withContext(Dispatchers.Main) { web } ?: return PreviewReport(
            ok = false,
            reason = "the preview is not running; call preview_start first"
        )
        val raw = withContext(Dispatchers.Main) {
            view.evaluate(PreviewHarness.reportScript(sinceMs, level))
        }
        return parseReport(raw)
    }

    /**
     * Holds still, then reports what moved.
     *
     * [frames] is the useful unit for anything animated -- "three frames" means
     * the same thing on a fast phone and a slow one, where "50 ms" does not.
     * Milliseconds remain available for waiting on a timer or a fetch.
     */
    suspend fun await(frames: Int, ms: Long): PreviewWait {
        val before = report(0L, "none")
        val startedAt = System.currentTimeMillis()
        if (frames > 0) {
            val deadline = startedAt + ms.coerceIn(MIN_WAIT_MS, MAX_WAIT_MS)
            while (System.currentTimeMillis() < deadline) {
                delay(FRAME_POLL_MS)
                val now = report(0L, "none")
                if (now.frames - before.frames >= frames) {
                    return waitResult(before, now, startedAt)
                }
            }
        } else {
            delay(ms.coerceIn(MIN_WAIT_MS, MAX_WAIT_MS))
        }
        val after = report(0L, "none")
        return waitResult(before, after, startedAt)
    }

    private fun waitResult(before: PreviewReport, after: PreviewReport, startedAt: Long) = PreviewWait(
        frames = after.frames,
        advancedBy = (after.frames - before.frames).coerceAtLeast(0L),
        elapsedMs = System.currentTimeMillis() - startedAt,
        throttled = after.throttled,
        errors = after.errors.size
    ).also { applyReport(after) }

    // ------------------------------------------------------------------ sight

    /**
     * A frame the model can look at, or an explanation instead of one.
     *
     * Three things are deliberately *not* sent as pictures:
     *
     * - A frame identical to the last one. Nothing changed, and the sentence
     *   saying so costs a few tokens against several hundred for a duplicate.
     * - A black offscreen frame. That is the known WebGL-without-a-window case,
     *   not evidence that the renderer is broken, and a model shown black
     *   rewrites code that works.
     * - Anything past the run's budget. At that point the console and a couple of
     *   expressions are better value than another look.
     *
     * In all three cases the DOM outline goes instead: what elements exist, where
     * they are, how big they are. It is a fraction of the cost and it answers
     * most of the questions a screenshot is asked.
     */
    suspend fun screenshot(mode: String, maxWidth: Int, quality: Int): PreviewShot {
        if (!_state.value.live) {
            return PreviewShot(
                source = PreviewShotSource.None,
                reason = "the preview is not running; call preview_start first"
            )
        }
        val view = withContext(Dispatchers.Main) { web } ?: return PreviewShot(
            source = PreviewShotSource.None,
            reason = "the preview has no page loaded"
        )

        if (shots >= PreviewState.SHOT_BUDGET) {
            return PreviewShot(
                source = PreviewShotSource.None,
                outline = snapshot(),
                reason = "the screenshot budget for this run is spent (" +
                    PreviewState.SHOT_BUDGET + " frames). Read preview_read_console for " +
                    "errors and use preview_eval_js to inspect state; restart the preview " +
                    "if you genuinely need to look again"
            )
        }

        val shot = if (mode.equals("canvas", ignoreCase = true)) {
            val dataUrl = withContext(Dispatchers.Main) {
                view.evaluate(PreviewHarness.captureScript(quality))
            }
            PreviewCapture.fromDataUrl(dataUrl, maxWidth, quality)
        } else {
            PreviewCapture.window(view, maxWidth, quality)
        }

        if (!shot.ok) return shot.copy(outline = snapshot())

        if (shot.hash == lastShotHash) {
            return shot.copy(
                base64 = "",
                outline = snapshot(),
                reason = "identical to the frame you were already sent -- nothing on screen " +
                    "changed. Advance time with preview_wait, or send input, before looking again"
            )
        }

        if (shot.black && shot.source == PreviewShotSource.Offscreen) {
            return shot.copy(
                base64 = "",
                outline = snapshot(),
                reason = "the offscreen frame came out black, which is what a WebGL canvas " +
                    "does when the preview screen is not in front -- it is not evidence that " +
                    "the page draws nothing. Use mode \"canvas\" to ask the canvas itself, or " +
                    "ask the user to open the preview screen"
            )
        }

        lastShotHash = shot.hash
        shots++
        _state.update { it.copy(shotsTaken = shots) }
        return shot
    }

    /** The page's interactive elements as text. The cheap alternative to looking. */
    suspend fun snapshot(): List<String> {
        val view = withContext(Dispatchers.Main) { web } ?: return emptyList()
        val raw = withContext(Dispatchers.Main) {
            view.evaluate(PreviewHarness.snapshotScript())
        }
        val array = runCatching { JSONArray(raw) }.getOrNull() ?: return emptyList()
        return buildList {
            for (i in 0 until array.length()) {
                val line = array.optString(i, "")
                if (line.isNotBlank()) add(line)
            }
        }
    }

    // ------------------------------------------------------------------ hands

    /**
     * Taps a point, and escalates to a real touch if the synthetic one did
     * nothing.
     *
     * Synthetic events are tried first because they are instant and they carry
     * the element description, which is what makes the result readable: "tapped
     * button#start" is worth more than "tapped 360,640". But Phaser, Cocos and
     * anything built on pointer capture check `event.isTrusted`, and synthetic
     * events are not trusted, so a game can ignore the tap entirely and report
     * nothing at all. The fallback is a genuine `MotionEvent` through
     * `dispatchTouchEvent`, which the engine cannot tell from a finger.
     *
     * The escalation trigger is deliberately not just "did the frame counter
     * move". An unattached WebView reports a heartbeat rather than real frames,
     * so that number cannot answer the question; when it cannot, the element
     * description decides instead.
     */
    suspend fun tap(x: Int, y: Int, forceReal: Boolean): PreviewTapResult {
        if (!_state.value.live) {
            return PreviewTapResult(
                ok = false,
                reason = "the preview is not running; call preview_start first"
            )
        }
        val view = withContext(Dispatchers.Main) { web } ?: return PreviewTapResult(
            ok = false,
            reason = "the preview has no page loaded"
        )

        val before = report(0L, "none")
        val element = if (forceReal) {
            ""
        } else {
            withContext(Dispatchers.Main) { view.evaluate(PreviewHarness.tapScript(x, y)) }
        }
        delay(TAP_SETTLE_MS)
        var after = report(0L, "none")

        val moved = after.frames > before.frames
        val needsReal = forceReal || element.isBlank() || (!after.throttled && !moved)
        var real = false
        if (needsReal) {
            realTap(view, x, y)
            delay(TAP_SETTLE_MS)
            after = report(0L, "none")
            real = true
        }

        applyReport(after)
        return PreviewTapResult(
            ok = true,
            element = element.ifBlank { "no element reported at that point" },
            real = real,
            framesBefore = before.frames,
            framesAfter = after.frames,
            errors = after.errors.size,
            reason = if (after.throttled) {
                "the preview screen is not in front, so the frame counter is a heartbeat " +
                    "and cannot prove the tap had an effect"
            } else {
                ""
            }
        )
    }

    /** Holds a key down for [holdMs], then reports what moved. */
    suspend fun key(code: String, holdMs: Long): PreviewWait {
        val view = withContext(Dispatchers.Main) { web }
            ?: return PreviewWait(0L, 0L, 0L, throttled = true, errors = 0)
        val before = report(0L, "none")
        val startedAt = System.currentTimeMillis()
        withContext(Dispatchers.Main) {
            view.evaluate(PreviewHarness.keyScript(code, holdMs))
        }
        // Long enough for the hold plus a frame or two of consequence: a keydown
        // that starts a jump has not moved anything yet when it returns.
        delay(holdMs.coerceIn(MIN_WAIT_MS, MAX_WAIT_MS) + TAP_SETTLE_MS)
        val after = report(0L, "none")
        return waitResult(before, after, startedAt)
    }

    /**
     * Evaluates an expression inside the page.
     *
     * The cheapest instrument here by a wide margin, and the one that answers
     * questions pixels cannot: whether the array is empty, what the flag is set
     * to, whether the listener was ever attached.
     */
    suspend fun evalJs(expression: String): PreviewEval {
        if (expression.isBlank()) {
            return PreviewEval(ok = false, reason = "no expression was given")
        }
        val view = withContext(Dispatchers.Main) { web } ?: return PreviewEval(
            ok = false,
            reason = "the preview is not running; call preview_start first"
        )
        val raw = withContext(Dispatchers.Main) {
            view.evaluate(PreviewHarness.evalScript(expression))
        }
        val json = runCatching { JSONObject(raw) }.getOrNull()
            ?: return PreviewEval(ok = false, reason = "the page returned no readable result")
        if (!json.optBoolean("ok", false)) {
            return PreviewEval(
                ok = false,
                reason = json.optString("reason", "the expression threw"),
                stack = json.optString("stack", "")
            )
        }
        return PreviewEval(
            ok = true,
            type = json.optString("type", ""),
            value = json.optString("value", "")
        )
    }

    private suspend fun realTap(view: WebView, x: Int, y: Int) {
        // CSS pixels to device pixels. Skipping this lands every tap in the top
        // left quarter of the screen on a modern phone, which looks exactly like
        // a game that ignores input.
        val density = app.resources.displayMetrics.density
        val px = x * density
        val py = y * density
        val downAt = System.currentTimeMillis()
        withContext(Dispatchers.Main) {
            view.dispatch(MotionEvent.ACTION_DOWN, downAt, downAt, px, py)
        }
        // A real gesture has time between down and up. Some engines measure it to
        // tell a tap from a cancelled touch, so the delay is part of the input,
        // not politeness.
        delay(REAL_TAP_HOLD_MS)
        withContext(Dispatchers.Main) {
            view.dispatch(MotionEvent.ACTION_UP, downAt, System.currentTimeMillis(), px, py)
        }
    }

    private fun WebView.dispatch(action: Int, downAt: Long, at: Long, x: Float, y: Float) {
        runCatching {
            val event = MotionEvent.obtain(downAt, at, action, x, y, 0)
            dispatchTouchEvent(event)
            event.recycle()
        }
    }

    // ------------------------------------------------------------- sandboxing

    /**
     * True while a run is in progress, which is what makes the write tools stage
     * instead of proposing.
     *
     * Tied to the preview being up rather than to a separate flag, because those
     * two could disagree -- and the state where the tools think they are
     * sandboxed and the preview is gone is one where edits vanish.
     */
    override val sandboxActive: Boolean
        get() = _state.value.let { it.live || it.busy }

    override fun sandboxRead(path: String): String? {
        val file = overlay.resolve(path) ?: return null
        if (!file.isFile || file.length() > MAX_STAGED_TEXT_BYTES) return null
        return runCatching { file.readText() }.getOrNull()
    }

    override fun sandboxDeleted(path: String): Boolean = overlay.isDeleted(path)

    @Synchronized
    override fun sandboxWrite(path: String, text: String, baseText: String?) {
        check(!committing) { "Preview is being committed." }
        overlay.write(path, text.toByteArray(), baseText?.let { hashOf(it) })
        publishStaged()
    }

    @Synchronized
    override fun sandboxDelete(path: String, baseText: String?) {
        check(!committing) { "Preview is being committed." }
        overlay.delete(path, baseText?.let { hashOf(it) })
        publishStaged()
    }

    private fun hashOf(text: String): String = SandboxOverlay.hash(text.toByteArray())

    override val sandboxCount: Int get() = overlay.touchedPaths().size

    /**
     * Records a write that the preview should serve but the project must not see
     * yet.
     */
    @Synchronized
    fun stageWrite(path: String, bytes: ByteArray, baseHash: String?) {
        check(!committing) { "Preview is being committed." }
        overlay.write(path, bytes, baseHash)
        publishStaged()
    }

    @Synchronized
    fun stageDelete(path: String, baseHash: String?) {
        check(!committing) { "Preview is being committed." }
        overlay.delete(path, baseHash)
        publishStaged()
    }

    /** What the sandbox would do to the project, collapsed to one entry per file. */
    suspend fun review(): List<ReviewEntry> = committer.review()

    /** Writes [entries] to the project, restoring everything if any write fails. */
    suspend fun commit(treeUri: String?, entries: List<ReviewEntry>): CommitResult {
        if (treeUri.isNullOrBlank()) {
            return CommitResult.Failed("no project folder is attached to this chat", 0)
        }
        synchronized(this) {
            if (treeUri != ownerTree || committing) {
                return CommitResult.Failed("Preview belongs to a different workspace or is already committing.", 0)
            }
            committing = true
        }
        try {
            val result = committer.commit(treeUri, entries)
            publishStaged()
            return result
        } finally { committing = false }
    }

    /** Throws away everything the run wrote. The project was never touched. */
    @Synchronized
    fun discardSandbox() {
        if (committing) return
        committer.discard()
        if (!sandboxActive) { ownerTree = null; ownerSession = null }
        publishStaged()
    }

    private fun publishStaged() {
        val count = overlay.touchedPaths().size
        _state.update { it.copy(staged = count) }
    }

    // ------------------------------------------------------------------- stop

    fun stop() {
        if (committing) return
        val view = web
        runCatching {
            view?.stopLoading()
            view?.loadUrl("about:blank")
        }
        _state.update {
            PreviewState(indexedFiles = it.indexedFiles, entry = it.entry, staged = overlay.touchedPaths().size)
        }
        if (overlay.isEmpty) { ownerTree = null; ownerSession = null }
    }

    /** Releases the page and the caches. Called when the project closes. */
    fun release() {
        if (committing || !overlay.isEmpty) { stop(); return }
        ownerTree = null
        ownerSession = null
        val view = web
        web = null
        runCatching {
            (view?.parent as? android.view.ViewGroup)?.removeView(view)
            view?.stopLoading()
            view?.destroy()
        }
        index.clear()
        overlay.clear()
        _state.value = PreviewState()
    }

    // ---------------------------------------------------------------- helpers

    private fun fail(reason: PreviewFailure, detail: String): PreviewState {
        _state.update {
            it.copy(status = PreviewStatus.Unavailable, failure = reason, detail = detail)
        }
        return _state.value
    }

    private fun applyReport(report: PreviewReport): PreviewState {
        if (!report.ok) return _state.value
        _state.update {
            it.copy(
                status = if (report.errors.isEmpty()) PreviewStatus.Running else PreviewStatus.Crashed,
                frames = report.frames,
                errorCount = report.errors.size,
                consoleCount = report.logs.size,
                title = report.title
            )
        }
        return _state.value
    }

    private fun entryOrDefault(entry: String): String {
        val trimmed = entry.trim().trimStart('/')
        return if (trimmed.isEmpty()) PreviewState.DEFAULT_ENTRY else trimmed
    }

    private fun parseReport(raw: String): PreviewReport {
        val json = runCatching { JSONObject(raw) }.getOrNull()
            ?: return PreviewReport(ok = false, reason = "the page returned no readable report")
        if (!json.optBoolean("ok", false)) {
            return PreviewReport(
                ok = false,
                reason = json.optString("reason", "the harness is not installed on this page")
            )
        }
        val logs = json.optJSONArray("logs")
        val errors = json.optJSONArray("errors")
        return PreviewReport(
            ok = true,
            frames = json.optLong("frames", 0L),
            uptimeMs = json.optLong("uptime", 0L),
            url = json.optString("url", ""),
            title = json.optString("title", ""),
            throttled = json.optBoolean("throttled", false),
            logs = buildList {
                for (i in 0 until (logs?.length() ?: 0)) {
                    val item = logs?.optJSONObject(i) ?: continue
                    add(
                        ConsoleEntry(
                            level = item.optString("level", "log"),
                            timestampMs = item.optLong("timestamp", 0L),
                            message = item.optString("message", "")
                        )
                    )
                }
            },
            errors = buildList {
                for (i in 0 until (errors?.length() ?: 0)) {
                    val item = errors?.optJSONObject(i) ?: continue
                    add(
                        PreviewCrash(
                            message = item.optString("message", ""),
                            source = item.optString("source", ""),
                            line = item.optInt("line", 0),
                            column = item.optInt("col", 0),
                            stack = item.optString("stack", ""),
                            timestampMs = item.optLong("timestamp", 0L)
                        )
                    )
                }
            }
        )
    }

    private companion object {
        const val HOST = "sirius.preview"
        const val ORIGIN_RULE = "https://sirius.preview"
        const val LOAD_TIMEOUT_MS = 15_000L
        const val SETTLE_MS = 350L
        const val FRAME_POLL_MS = 60L
        const val MIN_WAIT_MS = 16L
        const val MAX_WAIT_MS = 10_000L
        const val TAP_SETTLE_MS = 140L
        const val REAL_TAP_HOLD_MS = 60L
        const val MAX_STAGED_TEXT_BYTES = 2L * 1024 * 1024
    }
}

/**
 * `evaluateJavascript` as a suspending call.
 *
 * The result arrives JSON-encoded, so a JS string comes back wearing quotes.
 * Unwrapping here means every caller does not have to remember that.
 */
private suspend fun WebView.evaluate(script: String): String =
    suspendCancellableCoroutine { continuation ->
        runCatching {
            evaluateJavascript(script) { value ->
                if (!continuation.isActive) return@evaluateJavascript
                val decoded = when (val parsed = runCatching { JSONTokener(value).nextValue() }.getOrNull()) {
                    is String -> parsed
                    null -> ""
                    else -> value.orEmpty()
                }
                continuation.resume(decoded)
            }
        }.onFailure { if (continuation.isActive) continuation.resume("") }
    }

/**
 * What an expression evaluated to inside the page.
 *
 * The cheapest signal in the whole subsystem: a number or a flag settles in one
 * call what a screenshot can only hint at. A failure carries the page's own
 * reason and stack, because "the expression threw" without the throw is a dead
 * end for whoever has to fix it.
 */
data class PreviewEval(
    val ok: Boolean,
    val type: String = "",
    val value: String = "",
    val reason: String = "",
    val stack: String = ""
)
