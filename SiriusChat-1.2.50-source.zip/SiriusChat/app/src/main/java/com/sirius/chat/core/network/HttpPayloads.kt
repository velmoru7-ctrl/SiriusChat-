package com.sirius.chat.core.network

import com.sirius.chat.core.util.BoundedIo
import okhttp3.ResponseBody

/** Bounded non-streaming payload; SSE has separate per-line and per-event limits. */
fun ResponseBody.readLimitedText(maxBytes: Int = 8 * 1024 * 1024): String {
    if (contentLength() > maxBytes) throw BoundedIo.LimitExceededException(maxBytes.toLong())
    val charset = contentType()?.charset(Charsets.UTF_8) ?: Charsets.UTF_8
    val bytes = byteStream().use { BoundedIo.readBytes(it, maxBytes) }
    return bytes.toString(charset).removePrefix("\uFEFF")
}
