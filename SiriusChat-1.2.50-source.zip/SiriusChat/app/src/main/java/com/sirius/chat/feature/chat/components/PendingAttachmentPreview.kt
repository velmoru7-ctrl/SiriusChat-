package com.sirius.chat.feature.chat.components

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.media.ExifInterface
import android.net.Uri
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.window.Dialog
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.core.util.BoundedIo
import com.sirius.chat.domain.model.AttachmentKind
import com.sirius.chat.domain.model.MessageAttachment
import java.io.ByteArrayInputStream
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.sync.Semaphore
import kotlinx.coroutines.sync.withPermit
import kotlinx.coroutines.withContext

private data class AttachmentPixels(val image: ImageBitmap? = null, val loading: Boolean = true)
private val previewSlots = Semaphore(2)
private const val PREVIEW_MAX_BYTES = 5 * 1024 * 1024

@Composable
fun PromptAttachmentTile(attachment: MessageAttachment, onOpen: () -> Unit, onRemove: () -> Unit) {
    val colors = SiriusTheme.colors
    val pixels by rememberAttachmentPixels(attachment, 192)
    val openLabel = stringResource(R.string.input_preview_attachment, attachment.name)
    val removeLabel = stringResource(R.string.input_remove_named_attachment, attachment.name)
    val shape = RoundedCornerShape(14.dp)
    Row(Modifier.clip(shape).background(colors.surfaceMuted, shape).border(1.dp, colors.outline, shape),
        verticalAlignment = Alignment.CenterVertically) {
        // Preview and remove are SIBLING 48+dp controls. No hover-only or nested button.
        Row(Modifier.heightIn(min = 56.dp).clickable(role = Role.Button, onClick = onOpen)
            .semantics { contentDescription = openLabel }.padding(start = 6.dp, end = 4.dp),
            verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(44.dp).clip(RoundedCornerShape(10.dp)).background(colors.backgroundElevated),
                contentAlignment = Alignment.Center) {
                val bitmap = pixels.image
                if (bitmap != null) Image(bitmap, null, modifier = Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                else Icon(attachmentIcon(attachment.kind), null, tint = colors.textSecondary, modifier = Modifier.size(20.dp))
            }
            Spacer(Modifier.width(6.dp))
            Text(attachment.name, style = MaterialTheme.typography.labelMedium, color = colors.textSecondary,
                maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.widthIn(max = 120.dp))
        }
        IconButton(onClick = onRemove, modifier = Modifier.size(48.dp)) {
            Icon(Icons.Rounded.Close, removeLabel, tint = colors.textSecondary, modifier = Modifier.size(18.dp))
        }
    }
}

@Composable
fun PendingAttachmentPreview(attachment: MessageAttachment, onDismiss: () -> Unit) {
    val colors = SiriusTheme.colors
    val pixels by rememberAttachmentPixels(attachment, 1536)
    var visible by remember(attachment.id) { mutableStateOf(false) }
    LaunchedEffect(attachment.id) { visible = true }
    val appear by animateFloatAsState(if (visible) 1f else 0f, animationSpec = siriusTween(220), label = "attachmentPreview")
    val reduceMotion = SiriusTheme.reduceMotion
    Dialog(onDismissRequest = onDismiss) {
        Column(Modifier.fillMaxWidth().graphicsLayer {
            alpha = appear
            scaleX = if (reduceMotion) 1f else 0.96f + 0.04f * appear
            scaleY = scaleX
        }.clip(RoundedCornerShape(22.dp)).background(colors.surface)
            .verticalScroll(rememberScrollState()).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text(attachment.name, style = MaterialTheme.typography.titleSmall, color = colors.textPrimary,
                    maxLines = 2, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
                IconButton(onClick = onDismiss, modifier = Modifier.size(48.dp)) {
                    Icon(Icons.Rounded.Close, stringResource(R.string.action_close), tint = colors.textSecondary)
                }
            }
            val bitmap = pixels.image
            if (bitmap != null) {
                Image(bitmap, attachment.name, contentScale = ContentScale.Fit,
                    modifier = Modifier.fillMaxWidth().heightIn(min = 80.dp, max = 440.dp))
            } else {
                Text(stringResource(when {
                    attachment.kind != AttachmentKind.Image -> R.string.input_preview_file_info
                    pixels.loading -> R.string.input_preview_loading
                    else -> R.string.input_preview_unavailable
                }), style = MaterialTheme.typography.bodyMedium, color = colors.textSecondary)
            }
            attachment.mimeType?.takeIf { it.isNotBlank() }?.let {
                Text(it, style = MaterialTheme.typography.bodySmall, color = colors.textTertiary)
            }
            if (attachment.sizeBytes > 0) Text(stringResource(R.string.input_attachment_bytes, attachment.sizeBytes),
                style = MaterialTheme.typography.bodySmall, color = colors.textTertiary)
        }
    }
}

@Composable
private fun rememberAttachmentPixels(attachment: MessageAttachment, maxSide: Int): androidx.compose.runtime.State<AttachmentPixels> {
    val context = LocalContext.current.applicationContext
    return produceState(AttachmentPixels(), attachment.uri, attachment.kind, maxSide) {
        val loaded = withContext(Dispatchers.IO) {
            previewSlots.withPermit {
                val cancellation = currentCoroutineContext()
                val uri = Uri.parse(attachment.uri)
                // Local grants only. Never fetch remote URLs embedded in a message.
                if (attachment.kind != AttachmentKind.Image || uri.scheme != "content") return@withPermit null
                try {
                    val bytes = context.contentResolver.openInputStream(uri)?.use {
                        BoundedIo.readBytes(it, PREVIEW_MAX_BYTES) { cancellation.ensureActive() }
                    } ?: return@withPermit null
                    cancellation.ensureActive()
                    val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
                    BitmapFactory.decodeByteArray(bytes, 0, bytes.size, bounds)
                    if (bounds.outWidth !in 1..32768 || bounds.outHeight !in 1..32768) return@withPermit null
                    if (bounds.outWidth.toLong() * bounds.outHeight > 64_000_000L) return@withPermit null
                    val target = maxSide.coerceIn(64, 1536)
                    var sample = 1
                    while (bounds.outWidth / sample > target || bounds.outHeight / sample > target) sample *= 2
                    val decoded = BitmapFactory.decodeByteArray(bytes, 0, bytes.size, BitmapFactory.Options().apply {
                        inSampleSize = sample
                        inPreferredConfig = Bitmap.Config.ARGB_8888
                    }) ?: return@withPermit null
                    cancellation.ensureActive()
                    orientPreview(decoded, bytes).asImageBitmap()
                } catch (cancel: CancellationException) { throw cancel }
                catch (_: Exception) { null }
                catch (_: OutOfMemoryError) { null }
            }
        }
        value = AttachmentPixels(loaded, loading = false)
    }
}

/** Camera thumbnails honour orientation without adding a new image/network dependency. */
private fun orientPreview(bitmap: Bitmap, bytes: ByteArray): Bitmap {
    val orientation = try {
        ExifInterface(ByteArrayInputStream(bytes)).getAttributeInt(ExifInterface.TAG_ORIENTATION, ExifInterface.ORIENTATION_NORMAL)
    } catch (_: Exception) { ExifInterface.ORIENTATION_NORMAL }
    val matrix = Matrix()
    when (orientation) {
        ExifInterface.ORIENTATION_FLIP_HORIZONTAL -> matrix.setScale(-1f, 1f)
        ExifInterface.ORIENTATION_ROTATE_180 -> matrix.setRotate(180f)
        ExifInterface.ORIENTATION_FLIP_VERTICAL -> { matrix.setRotate(180f); matrix.postScale(-1f, 1f) }
        ExifInterface.ORIENTATION_TRANSPOSE -> { matrix.setRotate(90f); matrix.postScale(-1f, 1f) }
        ExifInterface.ORIENTATION_ROTATE_90 -> matrix.setRotate(90f)
        ExifInterface.ORIENTATION_TRANSVERSE -> { matrix.setRotate(-90f); matrix.postScale(-1f, 1f) }
        ExifInterface.ORIENTATION_ROTATE_270 -> matrix.setRotate(-90f)
        else -> return bitmap
    }
    val oriented = Bitmap.createBitmap(bitmap, 0, 0, bitmap.width, bitmap.height, matrix, true)
    if (oriented !== bitmap) bitmap.recycle()
    return oriented
}
