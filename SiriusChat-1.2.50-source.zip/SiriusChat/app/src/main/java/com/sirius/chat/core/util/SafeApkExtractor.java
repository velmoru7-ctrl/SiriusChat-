package com.sirius.chat.core.util;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** Bounded extraction. Neither artifact names nor ZIP paths become output paths. */
public final class SafeApkExtractor {
    public static final long MAX_APK_BYTES = 256L * 1024 * 1024;
    public static final long MAX_EXPANDED_BYTES = 512L * 1024 * 1024;
    public static final int MAX_ENTRIES = 4096;
    private SafeApkExtractor() {}
    private static final OutputStream DISCARD = new OutputStream() {
        @Override public void write(int b) {}
        @Override public void write(byte[] b, int off, int count) {}
    };
    public static File extract(File archive, File directory, Runnable check) throws IOException {
        return extract(archive, directory, MAX_APK_BYTES, MAX_EXPANDED_BYTES, MAX_ENTRIES, check);
    }
    /** Configurable limits allow actual fault-injection tests with small archives. */
    public static File extract(File archive, File directory, long maxApk, long maxExpanded,
                               int maxEntries, Runnable check) throws IOException {
        if (maxApk < 0 || maxExpanded < 0 || maxEntries <= 0)
            throw new IllegalArgumentException("Invalid archive limits");
        if (!directory.isDirectory() && !directory.mkdirs()) throw new IOException("APK directory unavailable");
        File pending = null;
        long expanded = 0;
        int entries = 0;
        try (ZipInputStream input = new ZipInputStream(new BufferedInputStream(new FileInputStream(archive)))) {
            while (true) {
                check.run();
                ZipEntry entry = input.getNextEntry();
                if (entry == null) return null;
                if (++entries > maxEntries) throw new IOException("Artifact contains too many entries");
                boolean apk = !entry.isDirectory() && entry.getName().toLowerCase(Locale.ROOT).endsWith(".apk");
                long remaining = maxExpanded - expanded;
                long limit = apk ? Math.min(maxApk, remaining) : remaining;
                if (entry.getSize() > limit) throw new BoundedIo.LimitExceededException(limit);
                if (apk) {
                    pending = File.createTempFile("sirius-", ".part", directory);
                    long copied;
                    try (FileOutputStream output = new FileOutputStream(pending)) {
                        copied = BoundedIo.copy(input, output, limit, check);
                        output.getFD().sync();
                    }
                    input.closeEntry(); // CRC must be valid before publication.
                    check.run();
                    if (copied == 0) throw new IOException("Artifact contains an empty APK");
                    String name = pending.getName().substring(0, pending.getName().length() - 5) + ".apk";
                    File complete = new File(directory, name);
                    if (complete.exists() || !pending.renameTo(complete))
                        throw new IOException("Could not publish the extracted APK");
                    pending = null;
                    return complete;
                }
                // closeEntry alone could inflate a bomb in a file we never wanted.
                expanded += BoundedIo.copy(input, DISCARD, limit, check);
                input.closeEntry();
            }
        } finally {
            if (pending != null) pending.delete();
        }
    }
}
