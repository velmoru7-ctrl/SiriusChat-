package com.sirius.chat.core.util;

/** Main-thread draft initialization guard; a quick Back must not save a placeholder. */
public final class DraftLifecycle {
    private boolean loaded;
    private boolean edited;
    public void markLoaded() { loaded = true; }
    public void markEdited() { edited = true; }
    public boolean isLoaded() { return loaded; }
    public boolean hasEdits() { return edited; }
    public boolean mayPersist() { return loaded || edited; }
}
