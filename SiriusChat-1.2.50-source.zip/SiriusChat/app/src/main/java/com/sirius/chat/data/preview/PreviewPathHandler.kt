package com.sirius.chat.data.preview

import android.content.ContentResolver
import android.net.Uri
import android.webkit.WebResourceResponse
import androidx.webkit.WebViewAssetLoader
import com.sirius.chat.domain.model.PreviewState
import java.io.FileInputStream
import java.io.FileNotFoundException
import java.io.InputStream

/**
 * Serves the project over a real origin, from three layers in order.
 *
 * `overlay -> mirror cache -> SAF index -> 404`
 *
 * The overlay is first because it is where the agent's unreviewed edits live: a
 * repair loop that wrote a fix and then read the old file back would spend its
 * remaining iterations fixing a bug it had already fixed. The mirror is second
 * because it only ever holds media and wasm, which the agent does not edit. SAF
 * is last and is the source of truth for everything untouched.
 *
 * ### Threading
 * `handle` is called on a WebView background thread, never the main one, so
 * opening a SAF stream here is allowed to block. That is the whole reason this
 * design is affordable.
 */
class PreviewPathHandler(
    private val resolver: ContentResolver,
    private val index: SafProjectIndex,
    private val overlay: SandboxOverlay
) : WebViewAssetLoader.PathHandler {

    override fun handle(path: String): WebResourceResponse? {
        val clean = normalize(path) ?: return null

        overlay.resolve(clean)?.let { file ->
            return runCatching { respond(clean, FileInputStream(file)) }.getOrNull()
        }

        // A file the run deleted must 404, not fall through to the original that
        // is still sitting in the project folder. Otherwise the agent deletes a
        // script and the page keeps executing it.
        if (overlay.isDeleted(clean)) return null

        index.mirrorOf(clean)?.let { file ->
            return runCatching { respond(clean, FileInputStream(file)) }.getOrNull()
        }

        val document = index.resolve(clean) ?: return null
        return try {
            val stream = resolver.openInputStream(document) ?: return null
            respond(clean, stream)
        } catch (missing: FileNotFoundException) {
            // The index was right when it was built and is wrong now. Drop the
            // entry so a later rebuild is not needed for the rest of the page.
            index.invalidate(clean, null)
            null
        } catch (denied: SecurityException) {
            null
        } catch (failure: Exception) {
            null
        }
    }

    /**
     * Turns a request path into an index key, or null when it is not one.
     *
     * Traversal cannot escape anywhere here -- the result is a map key, not a
     * path joined onto a root -- but `..` is still rejected rather than looked
     * up, because a project that genuinely contains a file called `..` does not
     * exist and a request for one is somebody probing.
     */
    private fun normalize(raw: String): String? {
        var value = raw
        // Decoded twice on purpose: WebView hands over a decoded path, and an
        // encoded segment that survived that first pass would otherwise reach
        // the map still wearing its escape.
        repeat(2) { value = runCatching { Uri.decode(value) }.getOrDefault(value) }
        value = value.replace('\\', '/').trimStart('/')
        if (value.contains('\u0000')) return null
        if (value.isEmpty() || value.endsWith("/")) value += PreviewState.DEFAULT_ENTRY
        val segments = value.split('/')
        if (segments.any { it == ".." || it == "." }) return null
        return value
    }

    private fun respond(path: String, stream: InputStream): WebResourceResponse {
        val response = WebResourceResponse(mimeOf(path), "utf-8", stream)
        response.responseHeaders = mapOf(
            // Not negotiable in a repair loop. With any caching at all the
            // WebView re-serves the previous iteration's file and the model
            // spends its next turn fixing a bug that is already gone.
            "Cache-Control" to "no-store",
            "Access-Control-Allow-Origin" to "*"
        )
        return response
    }

    private fun mimeOf(path: String): String =
        when (path.substringAfterLast('.', "").lowercase()) {
            "html", "htm" -> "text/html"
            "js", "mjs", "cjs" -> "text/javascript"
            "css" -> "text/css"
            "json", "map", "webmanifest" -> "application/json"
            "wasm" -> "application/wasm"
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "svg" -> "image/svg+xml"
            "ico" -> "image/x-icon"
            "bmp" -> "image/bmp"
            "mp3" -> "audio/mpeg"
            "ogg", "oga" -> "audio/ogg"
            "wav" -> "audio/wav"
            "m4a", "aac" -> "audio/mp4"
            "mp4", "mov" -> "video/mp4"
            "webm" -> "video/webm"
            "woff" -> "font/woff"
            "woff2" -> "font/woff2"
            "ttf" -> "font/ttf"
            "otf" -> "font/otf"
            "txt", "md" -> "text/plain"
            "xml" -> "text/xml"
            "csv" -> "text/csv"
            "glsl", "vert", "frag" -> "text/plain"
            else -> "application/octet-stream"
        }
}
