package com.sirius.chat.core.util;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;

/** Enforces limits while reading, even when a provider omits or lies about size. */
public final class BoundedIo {
    private BoundedIo() {}
    private static final Runnable NO_CHECK = () -> {};

    public static final class LimitExceededException extends IOException {
        public final long limit;
        public LimitExceededException(long limit) {
            super("The response or file exceeds the safe limit of " + limit + " bytes.");
            this.limit = limit;
        }
    }

    /** Streams are owned and closed by the caller. At most one excess byte is probed. */
    public static long copy(InputStream in, OutputStream out, long limit, Runnable check)
            throws IOException {
        if (limit < 0) throw new IllegalArgumentException("Negative byte limit");
        if (in == null || out == null || check == null) throw new NullPointerException();
        byte[] buffer = new byte[8192];
        long total = 0;
        while (true) {
            check.run();
            long remaining = limit - total;
            int wanted = remaining >= buffer.length ? buffer.length : (int) remaining + 1;
            int count = in.read(buffer, 0, wanted);
            if (count < 0) return total;
            // Defensive against unusual content providers returning a zero-length read.
            if (count == 0) {
                int next = in.read();
                if (next < 0) return total;
                buffer[0] = (byte) next;
                count = 1;
            }
            if (count > remaining) throw new LimitExceededException(limit);
            out.write(buffer, 0, count);
            total += count;
        }
    }

    public static byte[] readBytes(InputStream in, int limit) throws IOException {
        return readBytes(in, limit, NO_CHECK);
    }

    public static byte[] readBytes(InputStream in, int limit, Runnable check) throws IOException {
        if (limit < 0) throw new IllegalArgumentException("Negative byte limit");
        ByteArrayOutputStream out = new ByteArrayOutputStream(Math.min(limit, 8192));
        copy(in, out, limit, check);
        return out.toByteArray();
    }

    /** Do not silently replace invalid UTF-8 bytes in source code or config files. */
    public static String utf8(byte[] bytes) throws CharacterCodingException {
        return StandardCharsets.UTF_8.newDecoder()
            .onMalformedInput(CodingErrorAction.REPORT)
            .onUnmappableCharacter(CodingErrorAction.REPORT)
            .decode(ByteBuffer.wrap(bytes)).toString();
    }

    /** A character budget must not split a UTF-16 surrogate pair or be negative. */
    public static String prefix(String text, int maxChars) {
        int end = Math.max(0, Math.min(maxChars, text.length()));
        if (end > 0 && end < text.length()
                && Character.isHighSurrogate(text.charAt(end - 1))
                && Character.isLowSurrogate(text.charAt(end))) end--;
        return text.substring(0, end);
    }
}
