package com.sirius.chat.feature.preview

import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.core.locale.AppStrings
import com.sirius.chat.data.preview.PreviewCapture
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.CommitResult
import com.sirius.chat.domain.model.ConsoleEntry
import com.sirius.chat.domain.model.PreviewCrash
import com.sirius.chat.domain.model.PreviewShot
import com.sirius.chat.domain.model.PreviewState
import com.sirius.chat.domain.model.Project
import com.sirius.chat.domain.model.ReviewEntry
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

data class PreviewUiState(
    val preview: PreviewState = PreviewState(),
    val project: Project? = null,
    val entry: String = PreviewState.DEFAULT_ENTRY,
    val logs: List<ConsoleEntry> = emptyList(),
    val errors: List<PreviewCrash> = emptyList(),
    val logOpen: Boolean = false,
    val fullscreen: Boolean = false,
    val throttled: Boolean = false,
    val review: List<ReviewEntry> = emptyList(),
    val reviewOpen: Boolean = false,
    val committing: Boolean = false,
    val capturing: Boolean = false,
    val message: String? = null,
    val messageIsError: Boolean = false
) {
    val hasWorkspace: Boolean get() = project?.hasWorkspace == true

    val hasStaged: Boolean get() = preview.staged > 0
}

/**
 * Drives the preview screen.
 *
 * The WebView itself belongs to [AppContainer.previewController], not to this
 * class, because the agent starts and inspects previews while the user is
 * somewhere else entirely. This view model observes that controller and offers
 * the manual controls; it never owns the page. That is also why leaving the
 * screen does not stop a run.
 */
class PreviewViewModel(private val container: AppContainer) : ViewModel() {

    private val _state = MutableStateFlow(PreviewUiState())
    val state: StateFlow<PreviewUiState> = _state.asStateFlow()

    val controller = container.previewController

    private var surfaceWidth = 0
    private var surfaceHeight = 0

    init {
        // The active project can change from the Projects screen while this is
        // open, so follow it rather than reading it once.
        viewModelScope.launch {
            combine(
                container.settingsRepository.settings,
                container.projectRepository.observeProjects()
            ) { settings, projects ->
                projects.firstOrNull { it.id == settings.activeProjectId }
                    ?: projects.firstOrNull { it.hasWorkspace }
            }.distinctUntilChanged().collect { project ->
                _state.update { it.copy(project = project) }
            }
        }
        viewModelScope.launch {
            controller.state.collect { preview ->
                _state.update {
                    it.copy(preview = preview, entry = preview.entry.ifBlank { it.entry })
                }
            }
        }
    }

    /** The Compose surface reports its size so an offscreen load is laid out correctly. */
    fun onSurfaceSize(width: Int, height: Int) {
        if (width > 0) surfaceWidth = width
        if (height > 0) surfaceHeight = height
    }

    fun setEntry(entry: String) = _state.update { it.copy(entry = entry) }

    fun start() {
        val tree = _state.value.project?.treeUri
        viewModelScope.launch {
            controller.start(tree, _state.value.entry, surfaceWidth, surfaceHeight)
            refreshConsole()
        }
    }

    fun reload() {
        viewModelScope.launch {
            controller.reload(surfaceWidth, surfaceHeight)
            refreshConsole()
        }
    }

    fun stop() {
        controller.stop()
        _state.update { it.copy(logs = emptyList(), errors = emptyList(), logOpen = false) }
    }

    fun refreshConsole() {
        viewModelScope.launch {
            val report = controller.report(0L, "all")
            if (!report.ok) return@launch
            _state.update {
                it.copy(logs = report.logs, errors = report.errors, throttled = report.throttled)
            }
        }
    }

    fun toggleLog() {
        val opening = !_state.value.logOpen
        _state.update { it.copy(logOpen = opening) }
        if (opening) refreshConsole()
    }

    fun setFullscreen(value: Boolean) = _state.update { it.copy(fullscreen = value) }

    /**
     * Captures one frame and reports what came back.
     *
     * Deliberately a diagnostic rather than a way to hand the model a picture.
     * Sending a user-initiated frame into the conversation belongs to the
     * composer's attachment path, which lives in the chat feature; wiring a
     * second, parallel route into the message history from here is exactly the
     * kind of duplicate plumbing that later disagrees with itself. What this does
     * answer is the question the agent cannot: whether capture works on this
     * device, by which route, and at what size.
     */
    fun capture() {
        if (_state.value.capturing) return
        _state.update { it.copy(capturing = true) }
        viewModelScope.launch {
            val shot = controller.screenshot(
                mode = "window",
                maxWidth = PreviewCapture.MAX_WIDTH,
                quality = PreviewCapture.QUALITY
            )
            _state.update {
                it.copy(
                    capturing = false,
                    message = describe(shot),
                    messageIsError = !shot.ok || shot.black
                )
            }
        }
    }

    private fun describe(shot: PreviewShot): String = when {
        !shot.ok -> AppStrings.format(
            R.string.preview_capture_failed,
            shot.reason,
            fallback = "Could not capture a frame: " + shot.reason
        )

        // Worth its own message rather than a size: a black frame is almost
        // always a WebGL page without preserveDrawingBuffer, and reporting it as
        // a successful capture sends the agent looking at the wrong thing.
        shot.black -> AppStrings.get(
            R.string.preview_capture_black,
            fallback = "Frame is black. A WebGL page needs preserveDrawingBuffer"
        )

        else -> AppStrings.format(
            R.string.preview_capture_ok,
            shot.width,
            shot.height,
            shot.sizeKb,
            shot.source.name,
            fallback = "Captured"
        )
    }

    /** Opens the one review the run gets, and loads the diff behind it. */
    fun openReview() {
        _state.update { it.copy(reviewOpen = true) }
        viewModelScope.launch {
            val entries = controller.review()
            _state.update { it.copy(review = entries) }
        }
    }

    fun closeReview() = _state.update { it.copy(reviewOpen = false) }

    fun applyStaged() {
        val current = _state.value
        if (current.committing || current.review.isEmpty()) return
        _state.update { it.copy(committing = true) }
        viewModelScope.launch {
            val result = controller.commit(current.project?.treeUri, current.review)
            val message = when (result) {
                is CommitResult.Applied -> AppStrings.format(
                    R.string.preview_review_applied,
                    result.files,
                    fallback = "Applied"
                )

                CommitResult.Empty -> AppStrings.get(
                    R.string.preview_review_none,
                    fallback = "Nothing to apply"
                )

                is CommitResult.Failed -> AppStrings.format(
                    R.string.preview_review_failed,
                    result.rolledBack,
                    fallback = result.reason
                )
            }
            val failed = result is CommitResult.Failed
            _state.update {
                it.copy(
                    committing = false,
                    // A failed commit keeps the panel open with its list intact.
                    // Closing it would leave the user with a toast and no way
                    // back to the changes that are still staged.
                    review = if (failed) it.review else emptyList(),
                    reviewOpen = failed,
                    message = message,
                    messageIsError = failed
                )
            }
        }
    }

    fun discardStaged() {
        controller.discardSandbox()
        _state.update {
            it.copy(
                review = emptyList(),
                reviewOpen = false,
                message = AppStrings.get(
                    R.string.preview_review_discarded,
                    fallback = "Discarded"
                ),
                messageIsError = false
            )
        }
    }

    /**
     * Closes the review and leaves everything staged.
     *
     * The quietest of the three buttons and the one that gets used most: the
     * answer to "is this right" is often "not yet, keep playing with it", and
     * without this the only ways out are committing something unfinished or
     * throwing away work that was nearly there.
     */
    fun keepStaged() = _state.update { it.copy(reviewOpen = false) }

    fun dismissMessage() = _state.update { it.copy(message = null, messageIsError = false) }
}
