package com.sirius.chat.feature.chat.components

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsFocusedAsState
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.layout.wrapContentWidth
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.Description
import androidx.compose.material.icons.rounded.Edit
import androidx.compose.material.icons.rounded.Folder
import androidx.compose.material.icons.rounded.Image
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.PictureAsPdf
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material.icons.rounded.Warning
import androidx.compose.material3.Icon
import androidx.compose.material3.LocalTextStyle
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import kotlinx.coroutines.flow.StateFlow
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.TextRange
import androidx.compose.ui.text.input.TextFieldValue
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.sirius.chat.R
import com.sirius.chat.domain.model.PowerMode
import com.sirius.chat.domain.model.ComposerStyle
import com.sirius.chat.data.voice.SpeechPhase
import com.sirius.chat.core.designsystem.LocalTextAnimation
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.MorphMenu
import com.sirius.chat.core.designsystem.components.MorphMenuItem
import com.sirius.chat.core.designsystem.effects.LiquidMetalPreset
import com.sirius.chat.core.designsystem.effects.SiriusHairline
import com.sirius.chat.core.designsystem.effects.TextRevealOverlay
import com.sirius.chat.core.designsystem.effects.ambientGlow
import com.sirius.chat.core.designsystem.effects.glassSurface
import com.sirius.chat.core.designsystem.effects.liquidMetalRing
import com.sirius.chat.core.designsystem.effects.metalBevelBrush
import com.sirius.chat.core.designsystem.effects.rememberHidingTransformation
import com.sirius.chat.core.designsystem.effects.rememberTextRevealState
import com.sirius.chat.core.designsystem.siriusFadeThrough
import com.sirius.chat.core.designsystem.siriusRise
import com.sirius.chat.core.designsystem.siriusSpring
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.core.designsystem.touchTarget
import com.sirius.chat.core.util.rememberHaptics
import com.sirius.chat.domain.model.MessageAttachment
import com.sirius.chat.domain.model.AttachmentKind

/**
 * Composer.
 *
 * One flat panel, one line of controls: attach, mode, model, send. Everything is
 * inert dark chrome except the send button, which wears the liquid-metal ring —
 * it is the only decorated pixel on the screen, which is precisely what makes it
 * read as "this is the action" without a coloured fill or a label.
 *
 * The ring also carries state instead of a second signal being invented for it:
 * dormant while there is nothing to send, chromatic once the field is armed, gold
 * while the model is answering. The old composer stacked a focus bloom, a
 * travelling beam border, a tinted gradient send plate and a metal-plate body on
 * top of each other; all four are gone.
 */
@Composable
fun ChatInputBar(
    /**
     * The composer's text, as a flow.
     *
     * ### Why a flow and not a String
     * A `String` parameter forces whoever calls this to read the text, and in
     * Compose reading a state is what subscribes you to it. `ChatScreen` would
     * therefore recompose on every keystroke, and with it the transcript and every
     * visible bubble -- which is exactly the typing lag this replaces.
     *
     * Collected here instead, so the only thing that recomposes while typing is
     * the composer itself. The flow reference is stable, so passing it costs
     * nothing.
     */
    input: StateFlow<String>,
    /** New text and the caret offset after it, which is where files anchor. */
    onValueChange: (String, Int) -> Unit,
    onSend: () -> Unit,
    onStop: () -> Unit,
    onAttach: () -> Unit,
    onPickModel: () -> Unit,
    composerStyle: ComposerStyle,
    voice: ChatVoiceInput,
    voiceEnabled: Boolean,
    /** Sources the attach button offers; rendered as a menu morphing out of it. */
    attachMenuItems: List<MorphMenuItem> = emptyList(),
    /** Whether that menu is open. Owned by the screen, like every other overlay. */
    attachMenuExpanded: Boolean = false,
    onAttachMenuDismiss: () -> Unit = {},
    generating: Boolean,
    modelLabel: String,
    attachments: List<MessageAttachment>,
    onRemoveAttachment: (String) -> Unit,
    /** True while an existing message is being edited in place. */
    editing: Boolean = false,
    onCancelEdit: () -> Unit = {},
    modifier: Modifier = Modifier,
    /**
     * Window fill from 0..1, or `null` to hide the meter entirely.
     *
     * Nullable rather than a `Boolean` plus a `Float`: the two can never
     * disagree this way, and "no number to show" and "switched off" want the
     * same rendering anyway.
     */
    contextFill: Float? = null,
    /**
     * Current answer power, or null when this endpoint has no knob at all.
     *
     * Nullable rather than a mode plus a Boolean: "nothing to show" and "showing
     * a control that cannot move" are not the same thing, and only the first is
     * honest on an endpoint with no power settings.
     */
    powerMode: PowerMode? = null,
    onPickPower: (() -> Unit)? = null,
    sendEnabled: Boolean = true
) {
    val colors = SiriusTheme.colors
    val haptics = rememberHaptics()
    val pickModelLabel = stringResource(R.string.chat_pick_model)
    val interaction = remember { MutableInteractionSource() }
    val focused by interaction.collectIsFocusedAsState()
    val promptStyle = composerStyle == ComposerStyle.Prompt
    val splitControls = LocalConfiguration.current.screenWidthDp < 360 || LocalDensity.current.fontScale > 1.3f
    val composerShape = RoundedCornerShape(if (promptStyle) 24.dp else 28.dp)
    val voiceState by voice.controller.state.collectAsStateWithLifecycle()
    var previewAttachment by remember { mutableStateOf<MessageAttachment?>(null) }

    // The composer owns selection state so the caret offset can be reported: an
    // attachment is anchored where the user is typing, and a plain String field
    // cannot say where that is. The text itself stays owned by the ViewModel, so
    // clearing it after send and filling it for an edit keep working.
    var field by remember { mutableStateOf(TextFieldValue("")) }

    // Collected with `collectAsStateWithLifecycle` rather than read from a
    // parameter, so this subscription belongs to the composer and not to the
    // screen above it.
    val external by input.collectAsStateWithLifecycle()
    LaunchedEffect(external) {
        // Guarded, and the guard matters: without it every keystroke would round
        // trip through the ViewModel and come back to reset the caret to the end
        // of the text, so editing anywhere but the end would be impossible.
        if (field.text != external) {
            field = TextFieldValue(external, TextRange(external.length))
        }
    }

    // Derived locally from the text the composer already owns, instead of being
    // passed in. Sending depends on the text, so a `canSend` parameter would drag
    // the text back up into the caller's recomposition scope and undo the split
    // above.
    val hasPayload = field.text.isNotBlank() || attachments.isNotEmpty()
    val canSend = sendEnabled && !generating && !voiceState.active && hasPayload
    val primaryVoice = promptStyle && !generating && (voiceState.active || !hasPayload)
    val action = when {
        generating -> ComposerAction.Stop
        !primaryVoice -> ComposerAction.Send
        voiceState.phase == SpeechPhase.Listening -> ComposerAction.FinishVoice
        voiceState.active -> ComposerAction.CancelVoice
        else -> ComposerAction.Microphone
    }
    val armed = canSend || generating || (primaryVoice && (voiceEnabled || voiceState.active))
    val compactPrompt = promptStyle && !focused && !hasPayload && !voiceState.active && !editing
    val textMinHeight = if (!promptStyle) 48.dp else if (compactPrompt) 44.dp else 68.dp
    val textSize = if (promptStyle) 17.sp else 19.sp
    val textLine = if (promptStyle) 24.sp else 26.sp
    val chrome = if (promptStyle) {
        Modifier.clip(composerShape).background(colors.surface, composerShape)
            .border(SiriusHairline, if (focused) colors.primary.copy(alpha = 0.5f) else colors.outline, composerShape)
            .animateContentSize(animationSpec = siriusTween(220))
    } else Modifier

    val sendScale by animateFloatAsState(
        targetValue = if (armed) 1f else 0.94f,
        animationSpec = siriusSpring(SiriusMotion.SpringBouncy),
        label = "sendScale"
    )
    // Focus is worth exactly one hairline getting brighter. Anything louder and
    // the ring next to it stops being the thing you look at.
    val edgeAlpha by animateFloatAsState(
        targetValue = if (focused) 1f else 0.55f,
        animationSpec = siriusSpring(),
        label = "composerEdge"
    )

    Column(
        modifier = modifier
            .fillMaxWidth()
            .wrapContentWidth(Alignment.CenterHorizontally)
            .widthIn(max = if (promptStyle) 640.dp else Dp.Infinity)
            .fillMaxWidth()
            .imePadding()
            .navigationBarsPadding()
            .padding(horizontal = SiriusSpacing.sm, vertical = SiriusSpacing.xs)
            .then(if (promptStyle) chrome else Modifier.glassSurface(shape = composerShape, elevation = 0.dp, borderAlpha = edgeAlpha))
            // While answering, the panel edge picks up the same metal as the
            // button: one material saying "live", not a second colour.
            .liquidMetalRing(
                shape = composerShape,
                width = SiriusHairline,
                preset = LiquidMetalPreset.Gold,
                active = generating && !promptStyle,
                opacity = if (generating && !promptStyle) 0.85f else 0f
            )
            .padding(SiriusSpacing.sm)
    ) {
        VoiceInputPanel(voice = voice, state = voiceState)
        contextFill?.let { fill ->
            ContextMeter(
                fill = fill,
                modifier = Modifier.padding(bottom = SiriusSpacing.xs)
            )
        }

        // Editing is a mode, and a mode needs to be visible: without this the
        // composer looks like a normal draft and pressing send silently rewrites
        // history instead of adding a message.
        AnimatedVisibility(visible = editing) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = SiriusSpacing.xs),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Icon(
                    imageVector = Icons.Rounded.Edit,
                    contentDescription = null,
                    tint = colors.accent,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(Modifier.width(SiriusSpacing.xxs))
                Text(
                    text = stringResource(R.string.chat_editing_banner),
                    style = MaterialTheme.typography.labelMedium,
                    color = colors.textSecondary,
                    modifier = Modifier.weight(1f)
                )
                Icon(
                    imageVector = Icons.Rounded.Close,
                    contentDescription = stringResource(R.string.chat_editing_cancel),
                    tint = colors.textTertiary,
                    modifier = Modifier
                        .clip(CircleShape)
                        .clickable(role = Role.Button, onClick = onCancelEdit)
                        .touchTarget(36.dp)
                        .size(16.dp)
                )
            }
        }

        val (chipEnter, chipExit) = siriusRise(distancePx = 16)
        AnimatedVisibility(visible = attachments.isNotEmpty(), enter = chipEnter, exit = chipExit) {
            LazyRow(
                modifier = Modifier.padding(bottom = SiriusSpacing.xs),
                horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
            ) {
                items(attachments, key = { it.id }) { attachment ->
                    if (promptStyle) {
                        PromptAttachmentTile(
                            attachment = attachment,
                            onOpen = { voice.controller.cancel(); previewAttachment = attachment },
                            onRemove = { onRemoveAttachment(attachment.id) }
                        )
                    } else Row(
                        modifier = Modifier
                            .clip(RoundedCornerShape(SiriusRadius.pill))
                            .background(colors.surfaceMuted, RoundedCornerShape(SiriusRadius.pill))
                            .border(SiriusHairline, metalBevelBrush(colors), RoundedCornerShape(SiriusRadius.pill))
                            .padding(start = SiriusSpacing.xs, end = 2.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // The icon carries the one thing the name often does not:
                        // whether the model will actually be able to read it.
                        Icon(
                            imageVector = attachmentIcon(attachment.kind),
                            contentDescription = null,
                            tint = if (attachment.kind == AttachmentKind.Opaque) {
                                colors.warning
                            } else {
                                colors.textTertiary
                            },
                            modifier = Modifier.size(14.dp)
                        )
                        Spacer(Modifier.width(4.dp))
                        Text(
                            text = attachment.name,
                            style = MaterialTheme.typography.labelMedium,
                            color = colors.textSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.widthIn(max = 160.dp)
                        )
                        Spacer(Modifier.width(2.dp))
                        Icon(
                            imageVector = Icons.Rounded.Close,
                            contentDescription = stringResource(R.string.chat_remove_attachment),
                            tint = colors.textTertiary,
                            modifier = Modifier
                                .clip(CircleShape)
                                .clickable(
                                    role = Role.Button,
                                    onClick = { onRemoveAttachment(attachment.id) }
                                )
                                // 15dp of ink, 36dp of target.
                                .touchTarget(36.dp)
                                .size(15.dp)
                        )
                    }
                }
            }
        }

        // Hoisted out of the call below because the reveal overlay draws the
        // characters this field is hiding. The two have to agree on the style
        // exactly -- one different metric and an animated glyph lands somewhere
        // other than the space the field reserved for it.
        val composerTextStyle = LocalTextStyle.current.merge(
            MaterialTheme.typography.bodyLarge.copy(
                color = colors.textPrimary,
                // The prompt is the primary content of this screen, so it is
                // set larger than body text rather than at chrome size.
                fontSize = textSize,
                lineHeight = textLine
            )
        )
        // Switched off, this is inert: the transformation returns the text
        // untouched, the overlay returns before it composes anything, and the
        // frame loop never starts. The composer keeps the path it always had.
        val inputScroll = rememberScrollState()
        val reveal = rememberTextRevealState(
            settings = LocalTextAnimation.current,
            text = field.text,
            selection = field.selection,
            composition = field.composition,
            focused = focused,
            scroll = inputScroll
        )
        // A fresh instance whenever the hidden set changes. The field caches its
        // transformed text on (value, transformation), and a character that has
        // finished animating changes neither -- without this the field would keep
        // painting it transparent and the character would never come back.
        val revealTransformation = reveal.rememberHidingTransformation()

        // One explicit scroll container for both the real field and its overlay.
        // The field itself is unbounded vertically; no guessed bottom-scroll offset.
        Box(Modifier.fillMaxWidth().heightIn(min = textMinHeight, max = 192.dp).verticalScroll(inputScroll)) {
        BasicTextField(
            value = field,
            onValueChange = {
                reveal.onInput(it.text, it.selection, it.composition, focused)
                field = it
                onValueChange(it.text, it.selection.start)
            },
            textStyle = composerTextStyle,
            cursorBrush = SolidColor(if (reveal.hasCursor) androidx.compose.ui.graphics.Color.Transparent else colors.textPrimary),
            interactionSource = interaction,
            keyboardOptions = KeyboardOptions(imeAction = ImeAction.Default),
            // Recolours in-flight characters to transparent and nothing else,
            // so the field still measures, scrolls and places the caret over
            // text it believes is fully there.
            visualTransformation = revealTransformation,
            // The field's own measurement, borrowed rather than repeated. A
            // second measurement would drift on ligatures, emoji and bidi.
            onTextLayout = reveal::onTextLayout,
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(min = textMinHeight)
                .padding(horizontal = SiriusSpacing.xs, vertical = SiriusSpacing.xxs),
            decorationBox = { inner ->
                Box {
                    if (field.text.isEmpty()) {
                        Text(
                            text = stringResource(R.string.chat_input_hint),
                            style = MaterialTheme.typography.bodyLarge.copy(
                                fontSize = textSize,
                                lineHeight = textLine
                            ),
                            color = colors.textTertiary
                        )
                    }
                    inner()
                    // Inside the decoration box and next to inner(), so it
                    // shares an origin with the layout whose coordinates it is
                    // using. matchParentSize keeps it from ever growing the
                    // field it is drawing over.
                    TextRevealOverlay(
                        state = reveal,
                        style = composerTextStyle,
                        modifier = Modifier.matchParentSize()
                    )
                }
            }
        )
        }

        Spacer(Modifier.size(if (promptStyle) SiriusSpacing.xxs else SiriusSpacing.sm))
        if (splitControls) {
            ComposerSelectors(modelLabel, onPickModel, pickModelLabel, powerMode, onPickPower,
                modifier = Modifier.fillMaxWidth().padding(bottom = SiriusSpacing.xxs))
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
        ) {
            // The menu is anchored to this button and grows out of it, so the
            // control and the surface it produces are visibly the same object.
            MorphMenu(
                expanded = attachMenuExpanded,
                onDismissRequest = onAttachMenuDismiss,
                items = attachMenuItems
            ) { menuOpen ->
                ComposerCircleButton(
                    icon = Icons.Rounded.Add,
                    description = stringResource(R.string.chat_attach_file),
                    onClick = onAttach,
                    menuOpen = menuOpen
                )
            }

            if (splitControls) Spacer(Modifier.weight(1f)) else {
                ComposerSelectors(modelLabel, onPickModel, pickModelLabel, powerMode, onPickPower,
                    modifier = Modifier.weight(1f))
            }

            if (!primaryVoice) VoiceInputButton(voice = voice, state = voiceState, enabled = voiceEnabled)

            Box(
                modifier = Modifier
                    .scale(sendScale)
                    .ambientGlow(
                        color = if (generating) colors.warning else colors.accent,
                        shape = CircleShape,
                        radius = if (armed && !promptStyle) 16.dp else 0.dp,
                        alpha = if (armed && !promptStyle) 0.35f else 0f
                    )
                    .size(48.dp)
                    .clip(CircleShape)
                    .background(if (promptStyle && armed) colors.primary else if (armed) colors.surfaceMuted else colors.metalTrough, CircleShape)
                    .border(SiriusHairline, metalBevelBrush(colors), CircleShape)
                    // The ring is the whole affordance: 2dp of live metal when
                    // armed, nothing at all when there is no message to send.
                    .liquidMetalRing(
                        shape = CircleShape,
                        width = 2.dp,
                        preset = if (generating) LiquidMetalPreset.Gold else LiquidMetalPreset.Chromatic,
                        active = armed && !promptStyle,
                        opacity = if (armed && !promptStyle) 1f else 0f
                    )
                    .clickable(enabled = armed, role = Role.Button) {
                        haptics.light()
                        when (action) {
                            ComposerAction.Stop -> onStop()
                            ComposerAction.Send -> onSend()
                            else -> voice.onMicrophone()
                        }
                    },
                contentAlignment = Alignment.Center
            ) {
                // Send and stop are the same button doing two jobs, so the glyph
                // is swapped with a fade-through rather than replaced between
                // frames: at this size a hard cut looks like a rendering glitch.
                val (glyphEnter, glyphExit) = siriusFadeThrough()
                AnimatedContent(
                    targetState = action,
                    transitionSpec = { glyphEnter togetherWith glyphExit },
                    label = "sendGlyph"
                ) { currentAction ->
                    Icon(
                        imageVector = when (currentAction) {
                            ComposerAction.Stop, ComposerAction.FinishVoice -> Icons.Rounded.Stop
                            ComposerAction.CancelVoice -> Icons.Rounded.Close
                            ComposerAction.Microphone -> Icons.Rounded.Mic
                            ComposerAction.Send -> Icons.Rounded.ArrowUpward
                        },
                        contentDescription = stringResource(when (currentAction) {
                            ComposerAction.Stop -> R.string.action_stop
                            ComposerAction.FinishVoice -> R.string.voice_finish
                            ComposerAction.CancelVoice -> R.string.voice_cancel
                            ComposerAction.Microphone -> R.string.voice_start
                            ComposerAction.Send -> R.string.chat_send
                        }),
                        tint = if (promptStyle && armed) colors.onPrimary else if (armed) colors.textPrimary else colors.textTertiary,
                        modifier = Modifier.size(22.dp)
                    )
                }
            }
        }
    }
    previewAttachment?.let { attachment ->
        PendingAttachmentPreview(attachment = attachment, onDismiss = { previewAttachment = null })
    }
}

private enum class ComposerAction { Send, Stop, Microphone, FinishVoice, CancelVoice }

@Composable
private fun ComposerSelectors(
    modelLabel: String,
    onPickModel: () -> Unit,
    pickModelLabel: String,
    powerMode: PowerMode?,
    onPickPower: (() -> Unit)?,
    modifier: Modifier = Modifier
) {
    Row(modifier, verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)) {
        ComposerPill(label = modelLabel, onClick = onPickModel, onClickLabel = pickModelLabel,
            modifier = Modifier.weight(1f, fill = false), maxWidth = 180.dp)
        if (powerMode != null && onPickPower != null) ComposerPowerButton(mode = powerMode, onClick = onPickPower)
    }
}

/** Compact, honest power selector: same real sheet, 48 dp touch target. */
@Composable
private fun ComposerPowerButton(mode: PowerMode, onClick: () -> Unit) {
    val label = stringResource(R.string.chat_power_title) + ": " + stringResource(powerLabelRes(mode))
    androidx.compose.material3.IconButton(onClick = onClick, modifier = Modifier.size(48.dp)
        .semantics { contentDescription = label }) {
        PowerLevelBars(mode = mode, active = true, height = 16.dp)
    }
}

/**
 * Icon for an attachment kind, shared with the transcript.
 *
 * Same glyph in the composer and in the sent message, so a chip stays
 * recognisable after it scrolls up.
 */
internal fun attachmentIcon(kind: AttachmentKind): ImageVector = when (kind) {
    AttachmentKind.Image -> Icons.Rounded.Image
    AttachmentKind.Document -> Icons.Rounded.PictureAsPdf
    AttachmentKind.TextFile -> Icons.Rounded.Description
    AttachmentKind.WorkspaceFile -> Icons.Rounded.Folder
    AttachmentKind.Opaque -> Icons.Rounded.Warning
}

/**
 * Round control in the composer row: attach, and nothing else so far.
 *
 * [menuOpen] is not decoration. The button opens a menu that covers part of the
 * transcript, and a plus sign that stays a plus sign gives no way to tell that
 * tapping again will close it. Rotating it 45 degrees turns it into a close
 * glyph without swapping icons, which keeps the motion continuous with the
 * panel unfolding above it.
 */
@Composable
private fun ComposerCircleButton(
    icon: ImageVector,
    description: String,
    onClick: () -> Unit,
    menuOpen: Boolean = false
) {
    val colors = SiriusTheme.colors
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val rotation by animateFloatAsState(
        targetValue = if (menuOpen) 45f else 0f,
        animationSpec = siriusSpring(SiriusMotion.SpringGentle),
        label = "composerAddRotation"
    )
    val plate by animateColorAsState(
        targetValue = if (menuOpen) colors.primarySoft else colors.surfaceMuted,
        animationSpec = siriusTween(SiriusMotion.Quick),
        label = "composerAddPlate"
    )
    val ink by animateColorAsState(
        targetValue = if (menuOpen) colors.primary else colors.textSecondary,
        animationSpec = siriusTween(SiriusMotion.Quick),
        label = "composerAddInk"
    )
    // Flat chrome gives no shading to press "into", so the press has to be felt
    // in the geometry instead.
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.92f else 1f,
        animationSpec = siriusSpring(SiriusMotion.SpringBouncy),
        label = "composerIconPress"
    )
    Box(
        modifier = Modifier
            .clickable(
                interactionSource = interaction,
                indication = null,
                role = Role.Button,
                onClick = onClick
            )
            .touchTarget(48.dp)
            // Smaller plate, same 48dp target: the row got crowded, the finger
            // did not get smaller.
            .size(40.dp)
            .scale(scale)
            .clip(CircleShape)
            .background(plate, CircleShape)
            .border(SiriusHairline, metalBevelBrush(colors), CircleShape),
        contentAlignment = Alignment.Center
    ) {
        Icon(
            imageVector = icon,
            contentDescription = description,
            tint = ink,
            modifier = Modifier
                .size(20.dp)
                .rotate(rotation)
        )
    }
}

/**
 * A value-and-chevron pill. The chevron is not decoration: both pills open a
 * picker, and without it the mode pill would look like a static badge.
 */
@Composable
private fun ComposerPill(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    onClickLabel: String? = null,
    role: Role = Role.Button,
    maxWidth: Dp = 132.dp,
    tint: Color? = null
) {
    val colors = SiriusTheme.colors
    val shape = RoundedCornerShape(SiriusRadius.pill)
    val interaction = remember { MutableInteractionSource() }
    val pressed by interaction.collectIsPressedAsState()
    val scale by animateFloatAsState(
        targetValue = if (pressed) 0.96f else 1f,
        animationSpec = siriusSpring(SiriusMotion.SpringBouncy),
        label = "composerPillPress"
    )
    Row(
        modifier = modifier
            // Click node above the press-scale, like every other pressable in
            // the app: below it, the outer pixels stop answering mid-shrink.
            .clickable(
                interactionSource = interaction,
                indication = null,
                role = role,
                onClickLabel = onClickLabel,
                onClick = onClick
            )
            .scale(scale)
            .clip(shape)
            .background(colors.surfaceMuted, shape)
            .border(SiriusHairline, metalBevelBrush(colors), shape)
            .heightIn(min = 48.dp)
            .animateContentSize(animationSpec = siriusTween(180))
            .padding(start = SiriusSpacing.sm, end = SiriusSpacing.xs),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.labelLarge,
            color = tint ?: colors.textSecondary,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false).widthIn(max = maxWidth)
        )
        Spacer(Modifier.width(SiriusSpacing.xxs))
        Icon(
            imageVector = Icons.Rounded.KeyboardArrowDown,
            contentDescription = null,
            tint = colors.textTertiary,
            modifier = Modifier.size(16.dp)
        )
    }
}
