package com.sirius.chat.ai.streaming

import okio.BufferedSource

/** One server-sent event. */
data class SseEvent(val event: String?, val data: String)

/** Bounded incremental reader, including CR-only streams and an EOF tail. */
object SseParser {
    const val DONE = "[DONE]"
    const val MAX_LINE_BYTES = 2L * 1024 * 1024

    inline fun read(
        source: BufferedSource,
        onKeepAlive: () -> Unit = {},
        onEvent: (SseEvent) -> Boolean
    ) {
        val lines = SseLines(source.inputStream(), MAX_LINE_BYTES.toInt())
        val decoder = SseDecoder()
        while (true) {
            val line = lines.next() ?: break
            val frame = decoder.accept(line) ?: continue
            if (frame.keepAlive) onKeepAlive()
            else if (!onEvent(SseEvent(frame.event, frame.data))) return
        }
        decoder.finish()?.let { onEvent(SseEvent(it.event, it.data)) }
    }
}
