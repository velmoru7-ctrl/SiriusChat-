package com.sirius.chat.ai.streaming;

/** Stateful SSE field decoding, shared by the Android reader and portable JVM tests. */
public final class SseDecoder {
    public static final int DEFAULT_MAX_EVENT_CHARS = 4 * 1024 * 1024;
    private final int maxChars;
    private final StringBuilder data = new StringBuilder();
    private String event;
    private boolean hasData;
    private boolean firstLine = true;

    public static final class Frame {
        public final String event;
        public final String data;
        public final boolean keepAlive;
        private Frame(String event, String data, boolean keepAlive) {
            this.event = event; this.data = data; this.keepAlive = keepAlive;
        }
    }

    public SseDecoder() { this(DEFAULT_MAX_EVENT_CHARS); }
    public SseDecoder(int maxChars) {
        if (maxChars < 0) throw new IllegalArgumentException("Negative event limit");
        this.maxChars = maxChars;
    }

    public Frame accept(String line) {
        if (firstLine) {
            firstLine = false;
            if (line.startsWith("\uFEFF")) line = line.substring(1);
        }
        if (line.isEmpty()) return finish();
        if (line.charAt(0) == ':') return new Frame(null, "", true);
        int colon = line.indexOf(':');
        String field = colon < 0 ? line : line.substring(0, colon);
        String value = colon < 0 ? "" : line.substring(colon + 1);
        // The protocol removes ONE optional ASCII space, not trim() whitespace.
        if (value.startsWith(" ")) value = value.substring(1);
        if (field.equals("event")) {
            if (value.length() > maxChars) throw new IllegalArgumentException("SSE event name is too large");
            event = value.isEmpty() ? null : value;
        } else if (field.equals("data")) {
            long nextSize = (long) data.length() + value.length() + (hasData ? 1 : 0);
            if (nextSize > maxChars) throw new IllegalArgumentException("SSE event exceeds the safe size limit");
            if (hasData) data.append('\n');
            data.append(value);
            hasData = true;
        }
        return null;
    }

    /** Also used at EOF for providers that omit the final blank line. */
    public Frame finish() {
        Frame frame = hasData ? new Frame(event, data.toString(), false) : null;
        event = null;
        hasData = false;
        data.setLength(0);
        return frame;
    }
}
