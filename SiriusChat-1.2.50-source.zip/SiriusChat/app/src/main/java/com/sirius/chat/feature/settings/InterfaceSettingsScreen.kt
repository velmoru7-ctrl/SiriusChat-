package com.sirius.chat.feature.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.selection.selectable
import androidx.compose.foundation.selection.selectableGroup
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Add
import androidx.compose.material.icons.rounded.ArrowUpward
import androidx.compose.material.icons.rounded.KeyboardArrowDown
import androidx.compose.material.icons.rounded.Mic
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.RadioButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.semantics.Role
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.domain.model.ComposerStyle

@Composable
fun InterfaceSettingsScreen(onBack: () -> Unit, contentPadding: PaddingValues) {
    val model: SettingsViewModel = siriusViewModel { SettingsViewModel(it) }
    val state by model.state.collectAsStateWithLifecycle()
    val busy by model.interfaceBusy.collectAsStateWithLifecycle()
    val error by model.interfaceError.collectAsStateWithLifecycle()
    val colors = SiriusTheme.colors
    val scroll = rememberScrollState()
    Column(Modifier.fillMaxSize()) {
        SiriusTopBar(title = stringResource(R.string.interface_title),
            subtitle = stringResource(R.string.interface_subtitle), onBack = onBack, scrolled = scroll.value > 4)
        Column(Modifier.weight(1f).verticalScroll(scroll).padding(
            start = SiriusSpacing.sm, end = SiriusSpacing.sm,
            bottom = contentPadding.calculateBottomPadding() + SiriusSpacing.xl
        ), verticalArrangement = Arrangement.spacedBy(SiriusSpacing.sm)) {
            GlassCard {
                Text(stringResource(R.string.interface_input_title), style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                Text(stringResource(R.string.interface_input_hint), style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
            }
            Column(Modifier.selectableGroup(), verticalArrangement = Arrangement.spacedBy(SiriusSpacing.sm)) {
                ComposerStyle.entries.forEach { style ->
                    ComposerStyleCard(style = style, selected = state.settings.composerStyle == style,
                        enabled = !busy, onSelect = { model.setComposerStyle(style) })
                }
            }
            if (busy) Text(stringResource(R.string.interface_saving), color = colors.textSecondary, style = MaterialTheme.typography.bodySmall)
            error?.let { Text(it, color = colors.warning, style = MaterialTheme.typography.bodySmall) }
            GlassCard {
                Text(stringResource(R.string.voice_title), style = MaterialTheme.typography.titleMedium, color = colors.textPrimary)
                Text(stringResource(R.string.interface_voice_hint), style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                if (state.settings.systemVoiceAllowed) {
                    Text(stringResource(R.string.voice_system_allowed), style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
                    TextButton(enabled = !busy, onClick = model::resetSystemVoiceConsent) {
                        Text(stringResource(R.string.voice_reset_consent))
                    }
                }
            }
        }
    }
}

@Composable
private fun ComposerStyleCard(style: ComposerStyle, selected: Boolean, enabled: Boolean, onSelect: () -> Unit) {
    val colors = SiriusTheme.colors
    val shape = RoundedCornerShape(22.dp)
    Column(Modifier.fillMaxWidth().clip(shape)
        .selectable(selected = selected, enabled = enabled, role = Role.RadioButton, onClick = onSelect)
        .background(colors.surface, shape)
        .border(if (selected) 1.5.dp else 1.dp, if (selected) colors.primary else colors.outline, shape)
        .padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(stringResource(if (style == ComposerStyle.Classic) R.string.input_style_classic else R.string.input_style_prompt),
                    style = MaterialTheme.typography.titleSmall, color = colors.textPrimary)
                Text(stringResource(if (style == ComposerStyle.Classic) R.string.input_style_classic_hint else R.string.input_style_prompt_hint),
                    style = MaterialTheme.typography.bodySmall, color = colors.textSecondary)
            }
            RadioButton(selected = selected, onClick = null, enabled = enabled, modifier = Modifier.size(48.dp))
        }
        // An inert illustration, not a fake microphone or a second editable draft.
        ComposerStylePreview(style)
    }
}

@Composable
private fun ComposerStylePreview(style: ComposerStyle) {
    val colors = SiriusTheme.colors
    val prompt = style == ComposerStyle.Prompt
    val shape = RoundedCornerShape(if (prompt) 18.dp else 24.dp)
    Column(Modifier.fillMaxWidth().clearAndSetSemantics { }
        .background(if (prompt) colors.backgroundElevated else colors.surfaceMuted, shape)
        .border(1.dp, colors.outline, shape).padding(12.dp)) {
        Text(stringResource(R.string.chat_input_hint), style = MaterialTheme.typography.bodyMedium,
            color = colors.textTertiary, modifier = Modifier.heightIn(min = if (prompt) 32.dp else 48.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Rounded.Add, null, tint = colors.textSecondary, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(10.dp))
            Text(stringResource(R.string.interface_model_placeholder), style = MaterialTheme.typography.labelSmall,
                color = colors.textSecondary, maxLines = 1, overflow = TextOverflow.Ellipsis, modifier = Modifier.weight(1f))
            Icon(Icons.Rounded.KeyboardArrowDown, null, tint = colors.textSecondary, modifier = Modifier.size(14.dp))
            Spacer(Modifier.width(12.dp))
            Icon(Icons.Rounded.Mic, null, tint = colors.textSecondary, modifier = Modifier.size(16.dp))
            Spacer(Modifier.width(10.dp))
            Box(Modifier.size(30.dp).background(if (prompt) colors.primary else colors.surface, CircleShape)
                .border(1.dp, colors.outline, CircleShape), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.ArrowUpward, null, tint = if (prompt) colors.onPrimary else colors.textPrimary, modifier = Modifier.size(17.dp))
            }
        }
    }
}
