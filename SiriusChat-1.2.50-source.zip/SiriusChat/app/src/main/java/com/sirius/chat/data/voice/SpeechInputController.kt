package com.sirius.chat.data.voice

import android.Manifest
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import androidx.core.content.ContextCompat
import com.sirius.chat.core.util.DictationText
import com.sirius.chat.core.util.VoiceSession
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

enum class SpeechPhase { Idle, Permission, Starting, Listening, Finishing }
enum class SpeechProblem { Unavailable, Permission, Audio, Network, Busy, NoMatch, Timeout, Language, TooLong, ChangedDraft, Failed, ConsentSave }

data class SpeechInputState(
    val phase: SpeechPhase = SpeechPhase.Idle,
    val partial: String = "",
    val level: Float = 0f,
    val onDevice: Boolean = false,
    val problem: SpeechProblem? = null
) {
    val active: Boolean get() = phase != SpeechPhase.Idle
    val capturing: Boolean get() = phase == SpeechPhase.Starting || phase == SpeechPhase.Listening
}

data class SpeechRequest(
    val ticket: Long,
    val onDevice: Boolean,
    val languageTag: String,
    val systemApproved: Boolean
)

/**
 * One user-initiated utterance. No audio files, service, continuous restart,
 * synthetic transcript, remote AI call or silent on-device -> network fallback.
 * All public methods and callbacks run on the main thread.
 */
class SpeechInputController(
    context: Context,
    private val eligible: () -> Boolean,
    private val appendFinal: (String) -> Boolean
) {
    private val context = context.applicationContext
    private val gate = VoiceSession()
    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private var deadline: Runnable? = null
    private var hardDeadline: Runnable? = null
    private val _state = MutableStateFlow(SpeechInputState())
    val state: StateFlow<SpeechInputState> = _state.asStateFlow()
    val closed: Boolean get() = gate.isClosed()

    fun reserve(languageTag: String, systemApproved: Boolean): SpeechRequest? {
        mainThread()
        if (closed || gate.isActive() || !eligible()) return null
        val onDevice = try {
            Build.VERSION.SDK_INT >= Build.VERSION_CODES.S && SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
        } catch (_: RuntimeException) { false }
        val available = onDevice || try { SpeechRecognizer.isRecognitionAvailable(context) } catch (_: RuntimeException) { false }
        if (!available) { _state.value = SpeechInputState(problem = SpeechProblem.Unavailable); return null }
        val ticket = gate.begin()
        if (ticket == 0L) return null
        _state.value = SpeechInputState(phase = SpeechPhase.Permission, onDevice = onDevice)
        return SpeechRequest(ticket, onDevice, languageTag, systemApproved)
    }

    fun current(request: SpeechRequest): Boolean = gate.isCurrent(request.ticket) && eligible()

    fun start(request: SpeechRequest) {
        mainThread()
        if (!current(request)) { if (gate.isCurrent(request.ticket)) cancel(); return }
        if (!request.onDevice && !request.systemApproved) { fail(request, SpeechProblem.Permission); return }
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            fail(request, SpeechProblem.Permission); return
        }
        // Duplicate permission/consent callbacks cannot bind another engine.
        if (_state.value.phase != SpeechPhase.Permission || recognizer != null) return
        _state.value = SpeechInputState(phase = SpeechPhase.Starting, onDevice = request.onDevice)
        try {
            val engine = if (request.onDevice && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
            } else {
                SpeechRecognizer.createSpeechRecognizer(context)
            }
            recognizer = engine
            engine.setRecognitionListener(listener(request))
            val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, request.languageTag)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
                // A hint for the system engine, NOT a claim that it is offline.
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            }
            deadline(request, START_TIMEOUT_MS) { fail(request, SpeechProblem.Timeout) }
            hardDeadline = Runnable {
                if (valid(request) && _state.value.capturing) stop()
            }.also { handler.postDelayed(it, MAX_CAPTURE_MS) }
            engine.startListening(intent)
        } catch (_: SecurityException) {
            fail(request, SpeechProblem.Permission)
        } catch (_: RuntimeException) {
            // The mode selected before consent is immutable for this request.
            fail(request, SpeechProblem.Unavailable)
        }
    }

    fun stop() {
        mainThread()
        if (!gate.isActive()) return
        val current = _state.value
        if (current.phase == SpeechPhase.Permission || current.phase == SpeechPhase.Starting) { cancel(); return }
        if (current.phase != SpeechPhase.Listening) return
        _state.value = current.copy(phase = SpeechPhase.Finishing, level = 0f)
        try {
            recognizer?.stopListening()
            // Listener's onEndOfSpeech may also schedule this; always one deadline.
            if (gate.isActive() && _state.value.phase == SpeechPhase.Finishing) finishDeadline()
        } catch (_: RuntimeException) {
            cancel()
            _state.value = SpeechInputState(problem = SpeechProblem.Failed)
        }
    }

    /** Cancel discards partial speech only; previously typed/inserted text is untouched. */
    fun cancel() {
        mainThread()
        gate.cancel() // invalidate BEFORE cancel/destroy can deliver a callback
        cleanup(cancel = true)
        _state.value = SpeechInputState()
    }
    fun close() {
        mainThread()
        gate.close()
        cleanup(cancel = true)
        _state.value = SpeechInputState()
    }
    fun dismissProblem() { mainThread(); if (!gate.isActive()) _state.value = SpeechInputState() }
    fun fail(request: SpeechRequest, problem: SpeechProblem) {
        mainThread()
        if (!gate.finish(request.ticket)) return
        cleanup(cancel = true)
        _state.value = SpeechInputState(onDevice = request.onDevice, problem = problem)
    }

    private fun listener(request: SpeechRequest) = object : RecognitionListener {
        override fun onReadyForSpeech(params: Bundle?) {
            if (!valid(request)) return
            if (_state.value.phase == SpeechPhase.Starting || _state.value.phase == SpeechPhase.Listening) {
                clearDeadline()
                _state.value = _state.value.copy(phase = SpeechPhase.Listening)
            }
        }
        override fun onBeginningOfSpeech() {
            if (!valid(request)) return
            if (_state.value.phase == SpeechPhase.Starting || _state.value.phase == SpeechPhase.Listening) {
                clearDeadline()
                _state.value = _state.value.copy(phase = SpeechPhase.Listening)
            }
        }
        override fun onRmsChanged(rmsdB: Float) {
            if (valid(request) && _state.value.phase == SpeechPhase.Listening) {
                _state.value = _state.value.copy(level = DictationText.level(rmsdB))
            }
        }
        override fun onBufferReceived(buffer: ByteArray?) = Unit // do not store/log audio
        override fun onEndOfSpeech() {
            if (!valid(request)) return
            _state.value = _state.value.copy(phase = SpeechPhase.Finishing, level = 0f)
            finishDeadline()
        }
        override fun onError(error: Int) {
            if (!valid(request)) return
            val problem = when (error) {
                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> SpeechProblem.Permission
                SpeechRecognizer.ERROR_AUDIO -> SpeechProblem.Audio
                SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> SpeechProblem.Network
                SpeechRecognizer.ERROR_RECOGNIZER_BUSY, SpeechRecognizer.ERROR_TOO_MANY_REQUESTS -> SpeechProblem.Busy
                SpeechRecognizer.ERROR_NO_MATCH -> SpeechProblem.NoMatch
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> SpeechProblem.Timeout
                SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED, SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE -> SpeechProblem.Language
                else -> SpeechProblem.Failed
            }
            fail(request, problem)
        }
        override fun onResults(results: Bundle?) {
            if (!valid(request)) return
            val text = firstResult(results)
            if (text.isNullOrBlank()) { fail(request, SpeechProblem.NoMatch); return }
            if (text.length > DictationText.MAX_UTTERANCE_CHARS) { fail(request, SpeechProblem.TooLong); return }
            if (!gate.finish(request.ticket)) return
            cleanup(cancel = false)
            val accepted = try { appendFinal(text) } catch (_: IllegalArgumentException) { false }
            _state.value = SpeechInputState(
                onDevice = request.onDevice,
                problem = if (accepted) null else SpeechProblem.ChangedDraft
            )
        }
        override fun onPartialResults(partialResults: Bundle?) {
            if (!valid(request)) return
            _state.value = _state.value.copy(partial = DictationText.preview(firstResult(partialResults)))
        }
        override fun onEvent(eventType: Int, params: Bundle?) = Unit
    }

    private fun firstResult(bundle: Bundle?): String? = try {
        bundle?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
    } catch (_: RuntimeException) { null }

    private fun valid(request: SpeechRequest): Boolean {
        if (!gate.isCurrent(request.ticket)) return false
        if (!eligible()) { cancel(); return false }
        return true
    }
    private fun deadline(request: SpeechRequest, delay: Long, action: () -> Unit) {
        clearDeadline()
        deadline = Runnable { if (valid(request)) action() }.also { handler.postDelayed(it, delay) }
    }
    private fun finishDeadline() {
        clearDeadline()
        deadline = Runnable {
            if (gate.isActive() && _state.value.phase == SpeechPhase.Finishing) {
                gate.cancel()
                cleanup(cancel = true)
                _state.value = SpeechInputState(problem = SpeechProblem.Timeout)
            }
        }.also { handler.postDelayed(it, RESULT_TIMEOUT_MS) }
    }
    private fun clearDeadline() { deadline?.let(handler::removeCallbacks); deadline = null }
    private fun cleanup(cancel: Boolean) {
        clearDeadline()
        hardDeadline?.let(handler::removeCallbacks); hardDeadline = null
        val engine = recognizer; recognizer = null
        if (cancel) try { engine?.cancel() } catch (_: RuntimeException) { }
        try { engine?.destroy() } catch (_: RuntimeException) { }
    }
    private fun mainThread() { check(Looper.myLooper() == Looper.getMainLooper()) { "Speech input requires main thread" } }
    companion object {
        private const val START_TIMEOUT_MS = 10_000L
        private const val RESULT_TIMEOUT_MS = 8_000L
        private const val MAX_CAPTURE_MS = 60_000L
    }
}
