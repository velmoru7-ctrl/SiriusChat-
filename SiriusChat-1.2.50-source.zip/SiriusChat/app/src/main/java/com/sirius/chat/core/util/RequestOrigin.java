package com.sirius.chat.core.util;

/** Inputs are normalized HttpUrl fields, including their effective ports. */
public final class RequestOrigin {
    private RequestOrigin() {}
    public static boolean same(String schemeA, String hostA, int portA,
                               String schemeB, String hostB, int portB) {
        return schemeA != null && hostA != null && schemeB != null && hostB != null
            && !schemeA.isEmpty() && !hostA.isEmpty() && !schemeB.isEmpty() && !hostB.isEmpty()
            && portA > 0 && portA <= 65535 && portB > 0 && portB <= 65535
            && schemeA.equalsIgnoreCase(schemeB)
            && hostA.equalsIgnoreCase(hostB) && portA == portB;
    }
}
