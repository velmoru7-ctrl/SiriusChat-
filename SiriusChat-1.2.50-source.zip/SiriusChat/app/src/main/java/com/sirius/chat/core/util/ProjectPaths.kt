package com.sirius.chat.core.util

import java.io.File

/** Kotlin facade over the same policy exercised by the portable JVM regression tests. */
object ProjectPaths {
    fun relative(path: String, allowRoot: Boolean = false): String = SafeProjectPaths.relative(path, allowRoot)
    fun file(root: File, path: String): File = SafeProjectPaths.file(root, path)
}
