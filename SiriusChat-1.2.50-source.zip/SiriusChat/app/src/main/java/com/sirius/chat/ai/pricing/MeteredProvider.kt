package com.sirius.chat.ai.pricing

import com.sirius.chat.ai.model.AiContentPart
import com.sirius.chat.ai.model.AiError
import com.sirius.chat.ai.model.ChatRequest
import com.sirius.chat.ai.model.ChatStreamEvent
import com.sirius.chat.ai.provider.AiProvider
import com.sirius.chat.domain.model.TokenUsage
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.flow
import kotlin.math.ceil

/** Inside RetryingProvider: each network attempt gets its own reservation and row. */
class MeteredProvider(private val delegate: AiProvider, private val ledger: UsageLedger) : AiProvider by delegate {
    override fun chat(request: ChatRequest): Flow<ChatStreamEvent> = flow {
        val chars = (request.systemPrompt?.length ?: 0).toLong() + request.messages.sumOf { it.content.length.toLong() } +
            request.tools.sumOf { (it.name.length + it.description.length + it.parametersJson.length).toLong() }
        val hasMedia = request.messages.any { message -> message.parts.any { it is AiContentPart.Image || it is AiContentPart.Document } }
        val inputEstimate = ceil(chars / TokenEstimate.CHARS_PER_TOKEN.toDouble()).toLong() + request.messages.size * 8L
        // Conservative text reservation; still not a provider-enforced billing cap.
        val inputReserve = (chars + request.messages.size * 16L + 256L).coerceAtLeast(inputEstimate)
        val row = try {
            ledger.before(id, request.model, request.purpose, inputReserve,
                request.params.maxTokens.toLong().coerceAtLeast(1), hasMedia)
        } catch (stop: BudgetStoppedException) {
            emit(ChatStreamEvent.Failure(AiError(AiError.Kind.BadRequest, stop.message.orEmpty())))
            return@flow
        }
        var usage: TokenUsage? = null
        var receivedChars = 0L
        var success = false
        try {
            delegate.chat(request).collect { event ->
                when (event) {
                    is ChatStreamEvent.Delta -> receivedChars += event.text.length
                    is ChatStreamEvent.Reasoning -> receivedChars += event.text.length
                    is ChatStreamEvent.Completed -> {
                        success = true
                        usage = event.usage
                        receivedChars = maxOf(receivedChars, event.fullText.length.toLong() + event.reasoningChars +
                            event.toolCalls.sumOf { it.argumentsJson.length.toLong() + it.name.length })
                    }
                    is ChatStreamEvent.Failure -> success = false
                    else -> Unit
                }
                emit(event)
            }
        } finally {
            ledger.finish(row, usage, inputEstimate,
                ceil(receivedChars / TokenEstimate.CHARS_PER_TOKEN.toDouble()).toLong(), success, hasMedia)
        }
    }
}
