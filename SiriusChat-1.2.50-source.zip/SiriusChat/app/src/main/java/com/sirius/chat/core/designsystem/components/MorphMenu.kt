package com.sirius.chat.core.designsystem.components

import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.widthIn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.SiriusTheme

/** A menu action. The shared contract is retained for existing callers. */
data class MorphMenuItem(
    val icon: ImageVector,
    val label: String,
    val onClick: () -> Unit,
    val enabled: Boolean = true,
    val destructive: Boolean = false,
    val selected: Boolean = false
)

/**
 * Platform-backed anchored menu: focus, scrolling, placement and dismissal are
 * owned by Material. The trigger stays in the layout and the message is never
 * removed or faded to make room for actions. No staggered invisible hit targets.
 */
@Composable
fun MorphMenu(
    expanded: Boolean,
    onDismissRequest: () -> Unit,
    items: List<MorphMenuItem>,
    modifier: Modifier = Modifier,
    minWidth: Dp = 216.dp,
    trigger: @Composable (expanded: Boolean) -> Unit
) {
    val colors = SiriusTheme.colors
    var consumed by remember(expanded) { mutableStateOf(false) }
    Box(modifier = modifier) {
        trigger(expanded)
        DropdownMenu(
            expanded = expanded,
            onDismissRequest = onDismissRequest,
            modifier = Modifier.widthIn(min = minWidth, max = 320.dp)
        ) {
            items.forEachIndexed { index, item ->
                if (item.destructive && index > 0) {
                    HorizontalDivider(modifier = Modifier.padding(vertical = 4.dp))
                }
                val tint = when {
                    !item.enabled -> colors.textTertiary
                    item.destructive -> colors.error
                    else -> colors.textPrimary
                }
                DropdownMenuItem(
                    text = {
                        Text(item.label, color = tint, style = MaterialTheme.typography.bodyMedium,
                            maxLines = 2, overflow = TextOverflow.Ellipsis)
                    },
                    leadingIcon = {
                        Icon(item.icon, contentDescription = null, tint = tint, modifier = Modifier.size(20.dp))
                    },
                    trailingIcon = {
                        if (item.selected) Icon(Icons.Rounded.Check, contentDescription = null,
                            tint = colors.primary, modifier = Modifier.size(18.dp))
                    },
                    enabled = item.enabled,
                    modifier = Modifier.heightIn(min = 48.dp),
                    onClick = {
                        // A closing popup can outlive the Boolean for a frame.
                        // Never dispatch a second action or an action from that frame.
                        if (expanded && item.enabled && !consumed) {
                            consumed = true
                            onDismissRequest()
                            item.onClick()
                        }
                    }
                )
            }
        }
    }
}
