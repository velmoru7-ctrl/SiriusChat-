package com.sirius.chat.ai.provider

import com.sirius.chat.core.util.RequestOrigin
import okhttp3.Interceptor
import java.io.IOException

/**
 * OkHttp drops Authorization across hosts, but does not drop arbitrary API-key headers.
 * A network interceptor checks every redirected request before any headers are sent.
 * Authenticated API calls must use their final origin; unauthenticated CDN downloads
 * can still redirect. No key or full request URL is included in the failure message.
 */
object CredentialRedirectGuard {
    private val credentialHeaders = listOf(
        "Authorization", "Proxy-Authorization", "x-api-key", "x-goog-api-key", "api-key"
    )
    val interceptor = Interceptor { chain ->
        val initial = chain.call().request()
        val request = chain.request()
        val a = initial.url
        val b = request.url
        if ((initial.body != null || credentialHeaders.any { initial.header(it) != null }) &&
            !RequestOrigin.same(a.scheme, a.host, a.port, b.scheme, b.host, b.port)
        ) {
            throw CredentialRedirectException(
                "Blocked a redirect to a different origin to protect the request data and credentials. " +
                    "Set the provider's final HTTPS base URL."
            )
        }
        chain.proceed(request)
    }
}

/** A configuration/security refusal, not a retryable network outage. */
class CredentialRedirectException(message: String) : IOException(message)
