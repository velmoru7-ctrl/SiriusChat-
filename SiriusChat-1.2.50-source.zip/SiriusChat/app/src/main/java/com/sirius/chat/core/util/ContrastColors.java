package com.sirius.chat.core.util;

/** WCAG sRGB contrast for opaque accent fills; not a whole-screen accessibility audit. */
public final class ContrastColors {
    private ContrastColors() {}
    private static double linear(int channel) {
        double s = channel / 255.0;
        return s <= 0.04045 ? s / 12.92 : Math.pow((s + 0.055) / 1.055, 2.4);
    }
    public static double luminance(int argb) {
        return 0.2126 * linear((argb >>> 16) & 255)
            + 0.7152 * linear((argb >>> 8) & 255) + 0.0722 * linear(argb & 255);
    }
    public static double contrast(int first, int second) {
        double a = luminance(first), b = luminance(second);
        return (Math.max(a, b) + 0.05) / (Math.min(a, b) + 0.05);
    }
    public static int ink(int opaqueBackground) {
        return contrast(opaqueBackground, 0xFF000000) >= contrast(opaqueBackground, 0xFFFFFFFF)
            ? 0xFF000000 : 0xFFFFFFFF;
    }
}
