package com.sirius.chat.data.repository

import com.sirius.chat.domain.model.ChangeStatus
import com.sirius.chat.domain.model.PendingChange
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.update

/** Scoped proposals; compare the original contents again at apply time. */
class ChangeStore {
    private val _changes = MutableStateFlow<List<PendingChange>>(emptyList())
    val changes: StateFlow<List<PendingChange>> = _changes.asStateFlow()
    val pendingCount = changes.map { list -> list.count { it.status == ChangeStatus.Pending } }

    fun submit(newChanges: List<PendingChange>) {
        if (newChanges.isEmpty()) return
        _changes.update { current ->
            current.filterNot { existing ->
                existing.status == ChangeStatus.Pending && newChanges.any {
                    it.treeUri == existing.treeUri && it.projectId == existing.projectId &&
                        it.sessionId == existing.sessionId && it.path == existing.path
                }
            } + newChanges
        }
    }

    fun pendingFor(sessionId: String): List<PendingChange> =
        _changes.value.filter { it.sessionId == sessionId && it.status == ChangeStatus.Pending }
    fun byId(id: String): PendingChange? = _changes.value.firstOrNull { it.id == id }
    fun update(change: PendingChange) {
        _changes.update { list -> list.map { if (it.id == change.id) change else it } }
    }
    fun replaceContent(id: String, newContent: String) {
        _changes.update { list -> list.map { if (it.id == id) it.copy(newContent = newContent) else it } }
    }
    fun remove(id: String) { _changes.update { list -> list.filterNot { it.id == id } } }
    fun removeIfUnchanged(change: PendingChange) {
        _changes.update { list -> list.filterNot { it == change } }
    }
    fun clearResolved() { _changes.update { list -> list.filter { it.status == ChangeStatus.Pending } } }
    fun clearAll() { _changes.value = emptyList() }
}
