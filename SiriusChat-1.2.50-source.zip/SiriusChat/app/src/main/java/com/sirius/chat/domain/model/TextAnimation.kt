package com.sirius.chat.domain.model

/**
 * How single characters arrive in the composer.
 *
 * ### Why a nested object and not thirteen fields on [AppSettings]
 * Every value here is meaningless on its own -- a blur radius with no blur
 * switch is not a setting, it is a number -- and they are read together, by one
 * screen and one effect. Flattening them would put thirteen loosely named
 * `textAnimation*` fields in a class that is otherwise one field per concept,
 * and every call site would have to re-assemble them anyway.
 *
 * ### Why the numbers are stored, not derived
 * The tempo, distance and angle are the whole point of the feature: this is a
 * decorative animation, so the only honest default is "what the user liked".
 * The ranges below are the same ones the original plugin exposed, so a value
 * that looked right there looks right here.
 */
@kotlinx.serialization.Serializable
data class TextAnimationSettings(
    /**
     * Master switch.
     *
     * When false the composer takes its original path exactly: no layout
     * capture, no hidden characters, no overlay. An animation that cannot be
     * fully switched off is a bug, not a preference.
     */
    val enabled: Boolean = true,

    /** How long one character takes to settle, in milliseconds. */
    val durationMillis: Int = 300,

    /** Whether characters resolve out of a blur instead of only fading. */
    val blurEnabled: Boolean = true,

    /**
     * How long the blur takes to clear, in milliseconds.
     *
     * Separate from [durationMillis] on purpose: a slow sharpen under a quick
     * rise is the difference between "typed" and "materialised", and collapsing
     * the two into one number removes the only interesting thing about it.
     */
    val blurDurationMillis: Int = 300,

    /**
     * Blur strength, as an abstract 0..30 dial rather than pixels.
     *
     * Pixels would mean something different on every screen density, and dp
     * would invite the user to reason about a radius they cannot see. The dial
     * is mapped to a density-correct radius at draw time.
     */
    val blurRadius: Int = 10,

    /**
     * Percentage of the blur duration the character stays soft before it starts
     * sharpening. Buys the eye a moment to register that something appeared.
     */
    val blurHoldPercent: Int = 20,

    /** Whether characters drop into place from slightly above. */
    val slideEnabled: Boolean = true,

    /** How far above the baseline a character starts, in dp. */
    val slideDistanceDp: Int = 20,

    /** Whether characters grow into place. */
    val scaleEnabled: Boolean = false,

    /** The size a character starts at, 0..1 of its final size. */
    val scaleStart: Float = 0f,

    /** Whether characters straighten out as they land. */
    val rotateEnabled: Boolean = false,

    /** The angle a character starts at, in degrees. Negative leans left. */
    val rotateDegrees: Int = -15,

    /**
     * Whether spaces are skipped.
     *
     * On by default because a space has no ink: animating it spends a whole
     * layer on moving nothing, and the gap between two animating words then
     * lags behind both of them.
     */
    val ignoreSpaces: Boolean = true,
    val deleteAnimationEnabled: Boolean = true,
    val particleStyle: Int = 0,
    val particleCount: Int = 5,
    val particleSpeed: Int = 50,
    val particleSpread: Int = 50,
    val particleSize: Int = 50,
    val cursorEnabled: Boolean = true,
    val cursorSpeed: Int = 25,
    val cursorWidthDp: Int = 5,
    val liquidCursorEnabled: Boolean = false,
    val liquidScaleFactor: Int = 15,
    val selectionCursorEffect: Int = 0,
    val selectionLiquidStretch: Int = 60,
    val selectionLiquidSide: Int = 50,
    val animateAllLines: Boolean = false,
    val debugMode: Boolean = false
) {

    /**
     * The same settings with every number inside its range.
     *
     * Applied on read rather than trusted, because these values survive an app
     * update: a range that narrows in a later build would otherwise leave a
     * stored value that the slider cannot represent and the effect cannot draw.
     */
    fun coerced(): TextAnimationSettings = copy(
        durationMillis = durationMillis.coerceIn(DurationRange),
        blurDurationMillis = blurDurationMillis.coerceIn(DurationRange),
        blurRadius = blurRadius.coerceIn(BlurRadiusRange),
        blurHoldPercent = blurHoldPercent.coerceIn(BlurHoldRange),
        slideDistanceDp = slideDistanceDp.coerceIn(SlideDistanceRange),
        scaleStart = scaleStart.takeIf { it.isFinite() }?.coerceIn(ScaleStartMin, ScaleStartMax) ?: 0f,
        rotateDegrees = rotateDegrees.coerceIn(RotateRange),
        particleStyle = particleStyle.coerceIn(0..4),
        particleCount = particleCount.coerceIn(0..12),
        particleSpeed = particleSpeed.coerceIn(0..120),
        particleSpread = particleSpread.coerceIn(0..120),
        particleSize = particleSize.coerceIn(10..120),
        cursorSpeed = cursorSpeed.coerceIn(1..60),
        cursorWidthDp = cursorWidthDp.coerceIn(1..12),
        liquidScaleFactor = liquidScaleFactor.coerceIn(0..40),
        selectionCursorEffect = selectionCursorEffect.coerceIn(0..1),
        selectionLiquidStretch = selectionLiquidStretch.coerceIn(0..200),
        selectionLiquidSide = selectionLiquidSide.coerceIn(0..200)
    )

    /**
     * How long a character is still moving, in milliseconds.
     *
     * The blur can outlast the motion, so the character is only finished when
     * both are -- releasing its layer earlier would snap it sharp mid-fade.
     */
    val lifetimeMillis: Int
        get() = maxOf(durationMillis, if (blurEnabled) blurDurationMillis else 0)

    companion object {
        val DurationRange = 80..900
        val BlurRadiusRange = 0..30
        val BlurHoldRange = 0..100
        val SlideDistanceRange = 0..60
        val RotateRange = -45..45
        const val ScaleStartMin = 0f
        const val ScaleStartMax = 1f

        /**
         * Dial-to-dp factor for [blurRadius].
         *
         * 10 on the dial lands on ~3.3dp, which is the point where a 19sp glyph
         * reads as "resolving" rather than "broken", and 30 stays short of the
         * radius where neighbouring characters bleed into each other.
         */
        const val BlurRadiusToDp = 1f / 3f
    }
}
