package com.sirius.chat.data.attachment

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Base64
import com.sirius.chat.core.util.BoundedIo
import com.sirius.chat.core.util.MediaTypes
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import com.sirius.chat.domain.model.AttachmentKind
import com.sirius.chat.domain.model.MessageAttachment
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

/** What an attachment can contribute to a request. */
sealed interface AttachmentPayload {
    /**
     * Inlined text. [omittedChars] is non-zero when the file was longer than its
     * budget, and is reported to the model rather than hidden: a model that knows
     * it is looking at the first 60 000 characters of a file asks for the rest,
     * while a model handed a silent fragment answers as if it had the whole file.
     */
    data class Text(val text: String, val omittedChars: Int = 0) : AttachmentPayload

    /** Base64 for a native image or document block. */
    data class Binary(val base64: String, val mediaType: String) : AttachmentPayload

    /** Nothing can be sent, and this is the reason to tell the model. */
    data class Unavailable(val reason: String) : AttachmentPayload
}

/**
 * Resolves picked files into something a model can be given.
 *
 * Everything a `content://` uri does not tell you up front is settled here, once,
 * at pick time: the display name, the size, and — the part that matters — which
 * of the four possible fates the file has. A PNG becomes an image block, a PDF a
 * document block, a `.kt` file inlined text, and a `.zip` a description of
 * itself. Deciding this when the file is attached rather than when the request is
 * built is what lets the composer show the right icon and refuse an oversized
 * file while the user is still looking at it.
 */
class AttachmentReader(private val appContext: Context) {

    /**
     * Metadata for a picked uri, or null when the provider will not describe it.
     *
     * [anchor] is supplied by the caller because only the composer knows where
     * the caret was.
     */
    suspend fun describe(uri: Uri, anchor: Int): MessageAttachment? =
        withContext(Dispatchers.IO) {
            val resolver = appContext.contentResolver
            var name: String? = null
            var size = 0L
            runCatching {
                resolver.query(uri, null, null, null, null)?.use { cursor ->
                    if (cursor.moveToFirst()) {
                        val nameIndex = cursor.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                        if (nameIndex >= 0 && !cursor.isNull(nameIndex)) {
                            name = cursor.getString(nameIndex)
                        }
                        val sizeIndex = cursor.getColumnIndex(OpenableColumns.SIZE)
                        if (sizeIndex >= 0 && !cursor.isNull(sizeIndex)) {
                            size = cursor.getLong(sizeIndex)
                        }
                    }
                }
            }
            // Some providers answer neither name nor size. A last path segment is
            // still better than an opaque uri in the transcript.
            val resolved = name ?: uri.lastPathSegment?.substringAfterLast('/') ?: return@withContext null
            val mime = runCatching { resolver.getType(uri) }.getOrNull() ?: guessMime(resolved)
            MessageAttachment(
                id = UUID.randomUUID().toString(),
                name = resolved,
                uri = uri.toString(),
                sizeBytes = size.coerceAtLeast(0),
                mimeType = mime,
                kind = classify(resolved, mime),
                anchor = anchor
            )
        }

    /**
     * Reads the attachment for a request.
     *
     * [maxTextChars] is the caller's remaining budget for inlined text, so the
     * conversation as a whole cannot be pushed out of the context window by one
     * large file.
     */
    suspend fun payload(attachment: MessageAttachment, maxTextChars: Int): AttachmentPayload =
        withContext(Dispatchers.IO) {
            val uri = runCatching { Uri.parse(attachment.uri) }.getOrNull()
                ?: return@withContext AttachmentPayload.Unavailable("the file reference is invalid")
            try {
                // Re-evaluate legacy picks that treated a missing MIME as image/png.
                val kind = if (attachment.kind == AttachmentKind.WorkspaceFile) attachment.kind
                    else classify(attachment.name, attachment.mimeType)
                when (kind) {
                    AttachmentKind.Image -> {
                        val bytes = read(uri, MAX_IMAGE_BYTES)
                            ?: return@withContext AttachmentPayload.Unavailable(
                                "the image is larger than ${MAX_IMAGE_BYTES / (1024 * 1024)} MB, " +
                                    "which is more than the model accepts"
                            )
                        val media = MediaTypes.detectImageType(bytes)
                        if (media.isEmpty()) return@withContext AttachmentPayload.Unavailable(
                            "the file is not a supported PNG, JPEG, GIF or WebP image"
                        )
                        AttachmentPayload.Binary(encode(bytes), media)
                    }

                    AttachmentKind.Document -> {
                        val bytes = read(uri, MAX_DOCUMENT_BYTES)
                            ?: return@withContext AttachmentPayload.Unavailable(
                                "the document is larger than " +
                                    "${MAX_DOCUMENT_BYTES / (1024 * 1024)} MB"
                            )
                        AttachmentPayload.Binary(encode(bytes), "application/pdf")
                    }

                    AttachmentKind.TextFile -> {
                        val bytes = read(uri, MAX_TEXT_BYTES)
                            ?: return@withContext AttachmentPayload.Unavailable(
                                "the text file is larger than " +
                                    "${MAX_TEXT_BYTES / (1024 * 1024)} MB"
                            )
                        val full = BoundedIo.utf8(bytes)
                        val selected = BoundedIo.prefix(full, maxTextChars)
                        AttachmentPayload.Text(selected, omittedChars = full.length - selected.length)
                    }

                    AttachmentKind.Opaque -> AttachmentPayload.Unavailable(
                        "its type (${attachment.mimeType ?: "unknown"}) cannot be read by the model"
                    )

                    // Project files are read through the workspace tree, not here.
                    AttachmentKind.WorkspaceFile -> AttachmentPayload.Unavailable(
                        "it is a project file and is read from the workspace"
                    )
                }
            } catch (cancel: CancellationException) {
                throw cancel
            } catch (error: SecurityException) {
                // The persisted permission was revoked, or the app was reinstalled.
                AttachmentPayload.Unavailable("Sirius no longer has permission to read it")
            } catch (error: Exception) {
                AttachmentPayload.Unavailable(error.message ?: "it could not be read")
            }
        }

    /** The size hint is advisory; stop at the limit instead of allocating the whole file. */
    private suspend fun read(uri: Uri, limit: Long): ByteArray? {
        val context = currentCoroutineContext()
        return appContext.contentResolver.openInputStream(uri)?.use { stream ->
            try {
                BoundedIo.readBytes(stream, limit.toInt()) { context.ensureActive() }
            } catch (_: BoundedIo.LimitExceededException) {
                null
            }
        }
    }

    private fun encode(bytes: ByteArray): String = Base64.encodeToString(bytes, Base64.NO_WRAP)

    companion object {
        /** Ceiling for any single attachment, enforced when it is picked. */
        const val MAX_FILE_BYTES = 20L * 1024 * 1024

        /** Attachments per message. */
        const val MAX_ATTACHMENTS = 10

        /** Anthropic rejects images above 5 MB outright. */
        const val MAX_IMAGE_BYTES = 5L * 1024 * 1024
        const val MAX_DOCUMENT_BYTES = 20L * 1024 * 1024
        const val MAX_TEXT_BYTES = 8L * 1024 * 1024

        private val TEXT_EXTENSIONS = setOf(
            "txt", "md", "markdown", "rst", "log", "csv", "tsv", "json", "xml", "yaml", "yml",
            "toml", "ini", "cfg", "conf", "properties", "env", "gitignore", "dockerfile",
            "gradle", "kts", "kt", "java", "scala", "groovy", "py", "rb", "php", "pl", "lua",
            "js", "mjs", "cjs", "ts", "tsx", "jsx", "vue", "svelte", "html", "htm", "css",
            "scss", "sass", "less", "c", "h", "cc", "cpp", "hpp", "cs", "go", "rs", "swift",
            "m", "mm", "sh", "bash", "zsh", "fish", "bat", "ps1", "sql", "graphql", "proto",
            "pro", "cmake", "mk", "srt", "vtt", "tex", "diff", "patch"
        )

        private val TEXT_MIME_PREFIXES = listOf("text/")

        private val TEXT_MIME_TYPES = setOf(
            "application/json", "application/xml", "application/javascript",
            "application/x-yaml", "application/yaml", "application/x-sh",
            "application/x-httpd-php", "application/sql", "application/toml",
            "application/x-ndjson", "application/graphql"
        )

        /** Where a name and a mime type disagree, both get a vote. */
        fun classify(name: String, mime: String?): AttachmentKind {
            val extension = name.substringAfterLast('.', "").lowercase()
            val type = MediaTypes.normalize(mime)
            return when {
                MediaTypes.isSupportedImage(type) -> AttachmentKind.Image
                extension in setOf("png", "jpg", "jpeg", "gif", "webp") -> AttachmentKind.Image
                type == "application/pdf" || extension == "pdf" -> AttachmentKind.Document
                TEXT_MIME_PREFIXES.any { type.startsWith(it) } -> AttachmentKind.TextFile
                type in TEXT_MIME_TYPES -> AttachmentKind.TextFile
                extension in TEXT_EXTENSIONS -> AttachmentKind.TextFile
                // An extensionless file with an unhelpful mime type is usually a
                // dotfile or a script, and reading it as text is recoverable;
                // guessing "binary" for a real config file is not.
                extension.isEmpty() && (type.isEmpty() || type == "application/octet-stream") ->
                    AttachmentKind.TextFile
                else -> AttachmentKind.Opaque
            }
        }

        /** `image/jpg` is common in the wild and is not a real media type. */
        fun normalizeImageType(mime: String?): String =
            MediaTypes.normalize(mime).ifEmpty { "image/png" }

        private fun guessMime(name: String): String? = when (name.substringAfterLast('.', "").lowercase()) {
            "png" -> "image/png"
            "jpg", "jpeg" -> "image/jpeg"
            "gif" -> "image/gif"
            "webp" -> "image/webp"
            "pdf" -> "application/pdf"
            "json" -> "application/json"
            "md" -> "text/markdown"
            "txt", "log" -> "text/plain"
            else -> null
        }
    }
}
