package com.sirius.chat.data.repository

import android.content.ContentResolver
import android.content.Context
import android.content.Intent
import android.database.Cursor
import android.net.Uri
import android.provider.DocumentsContract
import android.util.Log
import com.sirius.chat.core.common.AppDispatchers
import com.sirius.chat.core.util.CodeLanguages
import com.sirius.chat.domain.model.FileNode
import com.sirius.chat.domain.model.ProjectSnapshot
import com.sirius.chat.domain.model.TextMatch
import com.sirius.chat.domain.repository.WorkspaceRepository
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.NonCancellable
import java.io.ByteArrayOutputStream
import java.io.IOException
import java.nio.ByteBuffer
import java.nio.charset.CodingErrorAction
import com.sirius.chat.core.util.ProjectPaths
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import java.io.BufferedReader
import java.io.InputStreamReader
import kotlin.coroutines.coroutineContext

/**
 * Workspace access through the Storage Access Framework.
 *
 * The implementation talks to [DocumentsContract] directly instead of using
 * `DocumentFile` for traversal: a single cursor query returns name, size, mime
 * and modification time for a whole directory, whereas `DocumentFile` performs
 * one query per attribute per file. On a real project tree that is the
 * difference between a snappy file browser and a sluggish one.
 */
class WorkspaceRepositoryImpl(
    private val context: Context,
    private val dispatchers: AppDispatchers
) : WorkspaceRepository {

    private val resolver: ContentResolver get() = context.contentResolver

    private val projection = arrayOf(
        DocumentsContract.Document.COLUMN_DOCUMENT_ID,
        DocumentsContract.Document.COLUMN_DISPLAY_NAME,
        DocumentsContract.Document.COLUMN_MIME_TYPE,
        DocumentsContract.Document.COLUMN_LAST_MODIFIED,
        DocumentsContract.Document.COLUMN_SIZE
    )

    /** Directories that are never worth indexing on a phone. */
    private val ignoredDirectories = setOf(
        ".git", ".gradle", ".idea", "build", "node_modules", ".dart_tool",
        "__pycache__", ".venv", "venv", ".cxx", "captures", ".kotlin"
    )

    // ---------------------------------------------------------------- access

    override fun persistAccess(treeUri: String) {
        runCatching {
            resolver.takePersistableUriPermission(
                Uri.parse(treeUri),
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }.onFailure { Log.w(TAG, "Cannot persist access: ${it.message}") }
    }

    override fun hasAccess(treeUri: String): Boolean {
        val uri = Uri.parse(treeUri)
        return resolver.persistedUriPermissions.any {
            it.uri == uri && it.isReadPermission
        }
    }

    override fun releaseAccess(treeUri: String) {
        runCatching {
            resolver.releasePersistableUriPermission(
                Uri.parse(treeUri),
                Intent.FLAG_GRANT_READ_URI_PERMISSION or Intent.FLAG_GRANT_WRITE_URI_PERMISSION
            )
        }
    }

    // ------------------------------------------------------------- traversal

    override suspend fun rootNode(treeUri: String): FileNode? = withContext(dispatchers.io) {
        val uri = Uri.parse(treeUri)
        val rootId = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrNull()
            ?: return@withContext null
        val docUri = DocumentsContract.buildDocumentUriUsingTree(uri, rootId)
        queryOne(docUri, rootId, "")
    }

    override suspend fun listChildren(
        treeUri: String,
        documentId: String,
        parentPath: String
    ): List<FileNode> = withContext(dispatchers.io) {
        readChildren(Uri.parse(treeUri), documentId, parentPath)
    }

    private fun readChildren(treeUri: Uri, documentId: String, parentPath: String): List<FileNode> {
        val childrenUri = DocumentsContract.buildChildDocumentsUriUsingTree(treeUri, documentId)
        val nodes = ArrayList<FileNode>(32)
        resolver.query(childrenUri, projection, null, null, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                nodes += cursor.toNode(parentPath)
            }
        }
        return nodes.sortedWith(
            compareByDescending<FileNode> { it.isDirectory }.thenBy { it.name.lowercase() }
        )
    }

    private fun Cursor.toNode(parentPath: String): FileNode {
        val id = getString(0)
        val name = getString(1) ?: id.substringAfterLast('/')
        val mime = getString(2).orEmpty()
        val modified = if (isNull(3)) 0L else getLong(3)
        val size = if (isNull(4)) 0L else getLong(4)
        return FileNode(
            documentId = id,
            name = name,
            path = if (parentPath.isEmpty()) name else "$parentPath/$name",
            isDirectory = mime == DocumentsContract.Document.MIME_TYPE_DIR,
            sizeBytes = size,
            lastModified = modified,
            mimeType = mime
        )
    }

    private fun queryOne(docUri: Uri, fallbackId: String, parentPath: String): FileNode? =
        resolver.query(docUri, projection, null, null, null)?.use { cursor ->
            if (cursor.moveToFirst()) cursor.toNode(parentPath) else null
        }

    override suspend fun findByPath(treeUri: String, path: String): FileNode? =
        withContext(dispatchers.io) {
            val uri = Uri.parse(treeUri)
            val rootId = DocumentsContract.getTreeDocumentId(uri)
            val segments = ProjectPaths.relative(path, allowRoot = true).split('/').filter { it.isNotEmpty() }
            if (segments.isEmpty()) return@withContext rootNode(treeUri)

            var currentId = rootId
            var currentPath = ""
            var node: FileNode? = null
            for (segment in segments) {
                coroutineContext.ensureActive()
                val match = readChildren(uri, currentId, currentPath)
                    .firstOrNull { it.name == segment } ?: return@withContext null
                currentId = match.documentId
                currentPath = match.path
                node = match
            }
            node
        }

    override suspend fun exists(treeUri: String, path: String): Boolean =
        findByPath(treeUri, path) != null

    // ------------------------------------------------------------------- io

    override suspend fun readText(treeUri: String, documentId: String, maxBytes: Long): String =
        withContext(dispatchers.io) {
            val docUri = DocumentsContract.buildDocumentUriUsingTree(Uri.parse(treeUri), documentId)
            resolver.openInputStream(docUri)?.use { stream ->
                val buffer = CharArray(8 * 1024)
                val builder = StringBuilder()
                BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).use { reader ->
                    while (true) {
                        coroutineContext.ensureActive()
                        val read = reader.read(buffer)
                        if (read <= 0) break
                        builder.appendRange(buffer, 0, read)
                        if (builder.length > maxBytes) {
                            builder.append("\n\n\u2026 file truncated at ${maxBytes / 1024} KB \u2026")
                            break
                        }
                    }
                }
                builder.toString()
            }.orEmpty()
        }

    override suspend fun readTextExact(treeUri: String, documentId: String, maxBytes: Long): String =
        withContext(dispatchers.io) {
            require(maxBytes in 1..(16L * 1024 * 1024)) { "Invalid text size limit." }
            val uri = DocumentsContract.buildDocumentUriUsingTree(Uri.parse(treeUri), documentId)
            val data = ByteArrayOutputStream()
            val input = resolver.openInputStream(uri) ?: throw IOException("Cannot read the file.")
            input.use { stream ->
                val buffer = ByteArray(8192)
                while (true) {
                    coroutineContext.ensureActive()
                    val count = stream.read(buffer)
                    if (count < 0) break
                    if (data.size().toLong() + count > maxBytes) {
                        throw IOException("File is too large for a safe text edit. Use a binary-safe copy or move.")
                    }
                    data.write(buffer, 0, count)
                }
            }
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(data.toByteArray())).toString()
        }

    override suspend fun writeText(treeUri: String, documentId: String, content: String): Boolean =
        withContext(dispatchers.io) {
            val docUri = DocumentsContract.buildDocumentUriUsingTree(Uri.parse(treeUri), documentId)
            var backup: ByteArray? = null
            var mutationStarted = false
            try {
                // Read before opening a truncating stream. A failed/cancelled write can restore bytes.
                backup = resolver.openInputStream(docUri)?.use { input ->
                    val out = java.io.ByteArrayOutputStream()
                    val chunk = ByteArray(64 * 1024)
                    while (true) {
                        coroutineContext.ensureActive()
                        val count = input.read(chunk)
                        if (count < 0) break
                        check(out.size() + count <= 16 * 1024 * 1024) { "File is too large to save with recovery." }
                        out.write(chunk, 0, count)
                    }
                    out.toByteArray()
                } ?: return@withContext false
                val bytes = content.toByteArray(Charsets.UTF_8)
                val activeContext = coroutineContext
                com.sirius.chat.core.util.VerifiedStreams.copy(
                    { java.io.ByteArrayInputStream(bytes) },
                    { mutationStarted = true; resolver.openOutputStream(docUri, "wt") },
                    { resolver.openInputStream(docUri) },
                    { activeContext.ensureActive() }
                )
                true
            } catch (failure: Exception) {
                val original = backup
                if (mutationStarted && original != null) withContext(NonCancellable) {
                    runCatching {
                        com.sirius.chat.core.util.VerifiedStreams.copy(
                            { java.io.ByteArrayInputStream(original) },
                            { resolver.openOutputStream(docUri, "wt") },
                            { resolver.openInputStream(docUri) },
                            { }
                        )
                    }.onFailure { Log.e(TAG, "Write recovery failed; retain the editor/proposal original", it) }
                }
                if (failure is CancellationException) throw failure
                Log.e(TAG, "writeText failed", failure)
                false
            }
        }

    override suspend fun createFile(
        treeUri: String,
        parentDocumentId: String,
        name: String
    ): FileNode? = withContext(dispatchers.io) {
        createDocument(treeUri, parentDocumentId, name, mimeForName(name))
    }

    override suspend fun createDirectory(
        treeUri: String,
        parentDocumentId: String,
        name: String
    ): FileNode? = withContext(dispatchers.io) {
        createDocument(treeUri, parentDocumentId, name, DocumentsContract.Document.MIME_TYPE_DIR)
    }

    private fun createDocument(
        treeUri: String,
        parentDocumentId: String,
        name: String,
        mime: String
    ): FileNode? = runCatching {
        val uri = Uri.parse(treeUri)
        val parentUri = DocumentsContract.buildDocumentUriUsingTree(uri, parentDocumentId)
        val created = DocumentsContract.createDocument(resolver, parentUri, mime, name) ?: return null
        var documentId = DocumentsContract.getDocumentId(created)
        var node = queryOne(created, documentId, "")

        // Some providers append an extension for the given mime type; restore
        // the exact name the user asked for.
        if (node != null && node.name != name && mime != DocumentsContract.Document.MIME_TYPE_DIR) {
            val renamed = DocumentsContract.renameDocument(resolver, created, name)
            if (renamed != null) {
                documentId = DocumentsContract.getDocumentId(renamed)
                node = queryOne(renamed, documentId, "")
            }
        }
        node
    }.getOrElse {
        Log.e(TAG, "createDocument failed", it)
        null
    }

    override suspend fun rename(treeUri: String, documentId: String, newName: String): String? =
        withContext(dispatchers.io) {
            runCatching {
                val docUri = DocumentsContract.buildDocumentUriUsingTree(Uri.parse(treeUri), documentId)
                DocumentsContract.renameDocument(resolver, docUri, newName)
                    ?.let { DocumentsContract.getDocumentId(it) }
            }.getOrNull()
        }

    override suspend fun delete(treeUri: String, documentId: String): Boolean =
        withContext(dispatchers.io) {
            runCatching {
                val docUri = DocumentsContract.buildDocumentUriUsingTree(Uri.parse(treeUri), documentId)
                DocumentsContract.deleteDocument(resolver, docUri)
            }.getOrDefault(false)
        }

    override suspend fun copy(treeUri: String, documentId: String, targetParentId: String): FileNode? =
        withContext(dispatchers.io) {
            val uri = Uri.parse(treeUri)
            val source = DocumentsContract.buildDocumentUriUsingTree(uri, documentId)
            val target = DocumentsContract.buildDocumentUriUsingTree(uri, targetParentId)
            val sourceNode = queryOne(source, documentId, "") ?: return@withContext null
            if (readChildren(uri, targetParentId, "").any { it.name == sourceNode.name }) {
                return@withContext null
            }
            val copied = runCatching { DocumentsContract.copyDocument(resolver, source, target) }.getOrNull()
            if (copied != null) {
                return@withContext queryOne(copied, DocumentsContract.getDocumentId(copied), "")
            }
            // Provider does not support copy: only report success after both streams
            // have closed and a read-back checksum matches. A partial file is not a copy.
            val node = queryOne(source, documentId, "") ?: return@withContext null
            if (node.isDirectory) return@withContext null
            val created = createDocument(treeUri, targetParentId, node.name, mimeForName(node.name))
                ?: return@withContext null
            val destUri = DocumentsContract.buildDocumentUriUsingTree(uri, created.documentId)
            try {
                val activeContext = coroutineContext
                com.sirius.chat.core.util.VerifiedStreams.copy(
                    { resolver.openInputStream(source) },
                    { resolver.openOutputStream(destUri, "wt") },
                    { resolver.openInputStream(destUri) },
                    { activeContext.ensureActive() }
                )
                created
            } catch (failure: Exception) {
                withContext(NonCancellable) { delete(treeUri, created.documentId) }
                if (failure is CancellationException) throw failure
                Log.e(TAG, "Copy failed; original was preserved", failure)
                null
            }
        }

    override suspend fun move(
        treeUri: String,
        documentId: String,
        sourceParentId: String,
        targetParentId: String
    ): FileNode? = withContext(dispatchers.io) {
        val uri = Uri.parse(treeUri)
        val source = DocumentsContract.buildDocumentUriUsingTree(uri, documentId)
        val sourceParent = DocumentsContract.buildDocumentUriUsingTree(uri, sourceParentId)
        val targetParent = DocumentsContract.buildDocumentUriUsingTree(uri, targetParentId)
        if (sourceParentId == targetParentId) return@withContext queryOne(source, documentId, "")
        val sourceNode = queryOne(source, documentId, "") ?: return@withContext null
        if (readChildren(uri, targetParentId, "").any { it.name == sourceNode.name }) return@withContext null
        val moved = runCatching {
            DocumentsContract.moveDocument(resolver, source, sourceParent, targetParent)
        }.getOrNull()
        if (moved != null) {
            queryOne(moved, DocumentsContract.getDocumentId(moved), "")
        } else {
            val copied = copy(treeUri, documentId, targetParentId) ?: return@withContext null
            if (!delete(treeUri, documentId)) {
                // Keep both complete copies. Claiming success would hide a failed move.
                Log.w(TAG, "Copy completed, but the source could not be deleted")
                return@withContext null
            }
            copied
        }
    }

    // --------------------------------------------------------------- search

    override suspend fun searchFiles(treeUri: String, query: String, limit: Int): List<FileNode> =
        withContext(dispatchers.io) {
            val needle = query.trim().lowercase()
            if (needle.isEmpty()) return@withContext emptyList()
            val results = ArrayList<FileNode>(limit)
            walk(treeUri, maxEntries = 4000) { node ->
                if (!node.isDirectory && node.name.lowercase().contains(needle)) results += node
                results.size < limit
            }
            results
        }

    override suspend fun searchText(treeUri: String, query: String, limit: Int): List<TextMatch> =
        withContext(dispatchers.io) {
            val needle = query.trim()
            if (needle.isEmpty()) return@withContext emptyList()
            val results = ArrayList<TextMatch>(limit)
            walk(treeUri, maxEntries = 1500) { node ->
                if (!node.isDirectory &&
                    node.sizeBytes in 1..MAX_SEARCHABLE_BYTES &&
                    CodeLanguages.isProbablyText(node.name, node.mimeType)
                ) {
                    val docUri = DocumentsContract.buildDocumentUriUsingTree(Uri.parse(treeUri), node.documentId)
                    runCatching {
                        resolver.openInputStream(docUri)?.use { stream ->
                            BufferedReader(InputStreamReader(stream, Charsets.UTF_8)).useLines { lines ->
                                lines.forEachIndexed { index, line ->
                                    if (results.size < limit && line.contains(needle, ignoreCase = true)) {
                                        results += TextMatch(
                                            documentId = node.documentId,
                                            path = node.path,
                                            lineNumber = index + 1,
                                            line = line.trim().take(200)
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
                results.size < limit
            }
            results
        }

    override suspend fun snapshot(treeUri: String, maxEntries: Int): ProjectSnapshot =
        withContext(dispatchers.io) {
            val root = rootNode(treeUri)
            var files = 0
            var directories = 0
            var bytes = 0L
            val languages = HashMap<String, Int>()
            val tree = StringBuilder()
            var truncated = false

            walk(treeUri, maxEntries) { node ->
                if (node.isDirectory) {
                    directories++
                } else {
                    files++
                    bytes += node.sizeBytes
                    val ext = node.extension.ifEmpty { "other" }
                    languages[ext] = (languages[ext] ?: 0) + 1
                }
                val depth = node.path.count { it == '/' }
                if (tree.length < MAX_TREE_CHARS) {
                    tree.append("  ".repeat(depth))
                        .append(if (node.isDirectory) "\u25B8 " else "\u00B7 ")
                        .append(node.name)
                        .append('\n')
                } else {
                    truncated = true
                }
                true
            }

            ProjectSnapshot(
                rootName = root?.name ?: "workspace",
                fileCount = files,
                directoryCount = directories,
                totalBytes = bytes,
                languages = languages.entries.sortedByDescending { it.value }.take(8)
                    .associate { it.key to it.value },
                tree = tree.toString(),
                truncated = truncated
            )
        }

    /**
     * Breadth-first traversal with a hard entry budget. [visit] returns false to
     * stop early, so searches abort as soon as they have enough results.
     */
    private suspend fun walk(
        treeUri: String,
        maxEntries: Int,
        visit: (FileNode) -> Boolean
    ) {
        val uri = Uri.parse(treeUri)
        val rootId = runCatching { DocumentsContract.getTreeDocumentId(uri) }.getOrNull() ?: return
        val queue = ArrayDeque<Pair<String, String>>() // documentId to path
        queue.addLast(rootId to "")
        var visited = 0

        while (queue.isNotEmpty() && visited < maxEntries) {
            coroutineContext.ensureActive()
            val (id, path) = queue.removeFirst()
            val children = readChildren(uri, id, path)
            for (child in children) {
                visited++
                if (child.isDirectory && child.name in ignoredDirectories) continue
                if (child.name.startsWith('.') && child.isDirectory) continue
                if (!visit(child)) return
                if (child.isDirectory) queue.addLast(child.documentId to child.path)
                if (visited >= maxEntries) break
            }
        }
    }

    private fun mimeForName(name: String): String {
        val ext = name.substringAfterLast('.', "").lowercase()
        return when (ext) {
            "json" -> "application/json"
            "xml" -> "text/xml"
            "html", "htm" -> "text/html"
            "md" -> "text/markdown"
            "txt" -> "text/plain"
            "" -> "application/octet-stream"
            else -> "application/octet-stream"
        }
    }

    private companion object {
        const val TAG = "SiriusWorkspace"
        const val MAX_SEARCHABLE_BYTES = 512L * 1024
        const val MAX_TREE_CHARS = 8000
    }
}
