package com.sirius.chat.data.preview

import org.json.JSONObject

/**
 * The script injected into every previewed page before its own code runs.
 *
 * ### Why it has to be first
 * It replaces `console.log` and installs the error listeners. A game that throws
 * while parsing its first module throws before any script appended at the end of
 * the document exists, and that crash -- the most informative one there is --
 * would be the exact one nobody captured. So this goes in on `onPageStarted`.
 *
 * ### Why it patches getContext
 * `canvas.toDataURL()` on a WebGL context returns a black rectangle unless the
 * context was created with `preserveDrawingBuffer: true`, because the browser is
 * free to discard the buffer after compositing. Almost nothing sets that flag,
 * so the honest fix is to force it here rather than to ask the model to write it
 * and to silently return black frames when it forgets. The system prompt also
 * mentions it, but the prompt is advice and this is enforcement.
 *
 * ### Why the seed arrives in the URL
 * Determinism has to be installed before the page's first line runs, and the
 * only channel that is reliably earlier than the document on every WebView
 * version is the URL the document was requested with. `?__sirius_seed=N`
 * switches `Math.random` to a seeded generator and quantises the frame clock, so
 * two iterations of the same code produce the same pixels. Without it the model
 * compares two screenshots of a particle field, sees a difference it caused
 * nothing of, and "fixes" randomness.
 */
object PreviewHarness {

    /** How many console lines the ring buffer keeps. */
    const val LOG_LIMIT = 500

    /** Query parameter carrying the deterministic seed. */
    const val SEED_PARAM = "__sirius_seed"

    /** The injected source. Runs at most once per document. */
    val SOURCE: String = """
(function () {
  if (window.__sirius) return;
  var LIMIT = 500;
  var logs = [];
  var errs = [];
  var frames = 0;
  var startedAt = Date.now();

  function push(list, item) {
    list.push(item);
    if (list.length > LIMIT) list.splice(0, list.length - LIMIT);
  }

  function describe(value) {
    try {
      if (value instanceof Error) return value.message + ' | ' + (value.stack || '');
      if (typeof value === 'undefined') return 'undefined';
      if (value === null) return 'null';
      if (typeof value === 'function') return 'function ' + (value.name || 'anonymous');
      if (typeof value === 'object') return JSON.stringify(value);
      return String(value);
    } catch (e) {
      return Object.prototype.toString.call(value);
    }
  }

  function joinArgs(args) {
    var parts = [];
    for (var i = 0; i < args.length; i++) parts.push(describe(args[i]));
    return parts.join(' ');
  }

  var levels = ['log', 'info', 'warn', 'error', 'debug'];
  for (var i = 0; i < levels.length; i++) {
    (function (level) {
      var original = console[level];
      console[level] = function () {
        push(logs, { level: level, timestamp: Date.now(), message: joinArgs(arguments) });
        if (original) { try { original.apply(console, arguments); } catch (e) {} }
      };
    })(levels[i]);
  }

  window.addEventListener('error', function (event) {
    push(errs, {
      message: event.message || 'uncaught error',
      source: event.filename || '',
      line: event.lineno || 0,
      col: event.colno || 0,
      stack: (event.error && event.error.stack) ? event.error.stack : '',
      timestamp: Date.now()
    });
  }, true);

  window.addEventListener('unhandledrejection', function (event) {
    var reason = event.reason;
    push(errs, {
      message: (reason && reason.message) ? reason.message : describe(reason),
      source: 'unhandled promise rejection',
      line: 0,
      col: 0,
      stack: (reason && reason.stack) ? reason.stack : '',
      timestamp: Date.now()
    });
  });

  var nativeGetContext = HTMLCanvasElement.prototype.getContext;
  HTMLCanvasElement.prototype.getContext = function (kind, attrs) {
    if (kind === 'webgl' || kind === 'webgl2' || kind === 'experimental-webgl') {
      attrs = attrs || {};
      attrs.preserveDrawingBuffer = true;
    }
    return nativeGetContext.call(this, kind, attrs);
  };

  // ---------------------------------------------------------- determinism

  function readSeed() {
    try {
      var search = String(location.search || '');
      var marker = '__sirius_seed=';
      var at = search.indexOf(marker);
      if (at < 0) return 0;
      var rest = search.slice(at + marker.length);
      var end = rest.indexOf('&');
      var raw = (end < 0) ? rest : rest.slice(0, end);
      var value = parseInt(raw, 10);
      return (isFinite(value) && value > 0) ? value : 0;
    } catch (e) {
      return 0;
    }
  }

  var seed = readSeed();
  var seeded = seed > 0;
  var virtualClock = 0;

  if (seeded) {
    // mulberry32: small, fast, good enough for a game, and identical on every
    // run. Installed over Math.random rather than offered as an extra API,
    // because the page was written before this existed and will never call it.
    var state = seed >>> 0;
    Math.random = function () {
      state = (state + 0x6D2B79F5) >>> 0;
      var t = state;
      t = Math.imul(t ^ (t >>> 15), t | 1);
      t = t ^ (t + Math.imul(t ^ (t >>> 7), t | 61));
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };

    // A fixed timestep as well. Games advance physics by the delta they are
    // handed, so a real clock reintroduces exactly the variation the seed just
    // removed -- the same code lands the player on a different pixel because a
    // frame took 19 ms instead of 16.
    var nativeRaf = window.requestAnimationFrame.bind(window);
    window.requestAnimationFrame = function (callback) {
      return nativeRaf(function () {
        virtualClock = virtualClock + (1000 / 60);
        try { callback(virtualClock); } catch (e) { throw e; }
      });
    };
  }

  var rafSeen = false;
  function tick() {
    rafSeen = true;
    frames++;
    requestAnimationFrame(tick);
  }
  requestAnimationFrame(tick);

  // An unattached or backgrounded WebView never runs rAF, and a counter
  // stuck at zero reads exactly like a crashed page. The heartbeat keeps
  // the liveness question answerable; report() flags it as throttled so
  // nobody mistakes it for a frame rate.
  setTimeout(function () {
    if (!rafSeen) setInterval(function () { if (!rafSeen) frames++; }, 100);
  }, 1200);

  function biggestCanvas() {
    var all = document.getElementsByTagName('canvas');
    var best = null;
    var area = 0;
    for (var i = 0; i < all.length; i++) {
      var size = all[i].width * all[i].height;
      if (size > area) { area = size; best = all[i]; }
    }
    return best;
  }

  function label(node) {
    var text = '';
    try {
      text = (node.innerText || node.value || node.getAttribute('aria-label') || '');
    } catch (e) {}
    text = String(text).replace(/[\r\n]+/g, ' ').trim();
    return text.length > 40 ? text.slice(0, 40) : text;
  }

  function outline(node) {
    var box = node.getBoundingClientRect();
    return node.tagName.toLowerCase() + (node.id ? '#' + node.id : '') +
      ' "' + label(node) + '" @' +
      Math.round(box.left + box.width / 2) + ',' + Math.round(box.top + box.height / 2) +
      ' ' + Math.round(box.width) + 'x' + Math.round(box.height);
  }

  var api = {
    version: 2,
    frames: function () { return frames; },
    uptime: function () { return Date.now() - startedAt; },
    errors: function () { return errs.slice(); },
    seeded: function () { return seeded; },
    clear: function () { logs.length = 0; errs.length = 0; },

    logs: function (sinceMs, level) {
      var cutoff = (sinceMs && sinceMs > 0) ? Date.now() - sinceMs : 0;
      var out = [];
      for (var i = 0; i < logs.length; i++) {
        var entry = logs[i];
        if (entry.timestamp < cutoff) continue;
        if (level && level !== 'all' && entry.level !== level) continue;
        out.push(entry);
      }
      return out;
    },

    report: function (sinceMs, level) {
      return JSON.stringify({
        ok: true,
        frames: frames,
        uptime: Date.now() - startedAt,
        throttled: !rafSeen,
        seeded: seeded,
        url: location.href,
        title: document.title || '',
        logs: api.logs(sinceMs, level),
        errors: errs
      });
    },

    capture: function (quality) {
      var canvas = biggestCanvas();
      if (!canvas) return '';
      try {
        return canvas.toDataURL('image/jpeg', quality || 0.7);
      } catch (e) {
        return '';
      }
    },

    tap: function (x, y) {
      var node = document.elementFromPoint(x, y) || document.body;
      var kinds = ['pointerdown', 'mousedown', 'pointerup', 'mouseup', 'click'];
      for (var i = 0; i < kinds.length; i++) {
        var name = kinds[i];
        try {
          var event;
          if (name.indexOf('pointer') === 0 && window.PointerEvent) {
            event = new PointerEvent(name, {
              bubbles: true, cancelable: true, view: window,
              clientX: x, clientY: y, pointerId: 1, isPrimary: true, pointerType: 'touch'
            });
          } else {
            event = new MouseEvent(name, {
              bubbles: true, cancelable: true, view: window, clientX: x, clientY: y
            });
          }
          node.dispatchEvent(event);
        } catch (e) {}
      }
      return outline(node);
    },

    key: function (code, holdMs) {
      var init = { bubbles: true, cancelable: true, key: code, code: code };
      try {
        window.dispatchEvent(new KeyboardEvent('keydown', init));
        document.dispatchEvent(new KeyboardEvent('keydown', init));
      } catch (e) {}
      setTimeout(function () {
        try {
          window.dispatchEvent(new KeyboardEvent('keyup', init));
          document.dispatchEvent(new KeyboardEvent('keyup', init));
        } catch (e) {}
      }, (holdMs && holdMs > 0) ? holdMs : 80);
      return code;
    },

    snapshot: function () {
      var nodes = document.querySelectorAll('button, a, input, select, textarea, [role], canvas, h1, h2');
      var out = [];
      for (var i = 0; i < nodes.length && out.length < 60; i++) {
        var box = nodes[i].getBoundingClientRect();
        if (box.width < 1 || box.height < 1) continue;
        out.push(outline(nodes[i]));
      }
      return out;
    },

    // Reading one number out of the page is a few tokens; looking at a picture
    // of that number is several hundred. This is the cheap check, and it is the
    // one that answers questions a screenshot cannot -- what is in the array,
    // what the flag is set to, whether the listener is attached.
    evaluate: function (source) {
      try {
        var value = eval(source);
        return JSON.stringify({
          ok: true,
          type: (value === null) ? 'null' : typeof value,
          value: describe(value)
        });
      } catch (e) {
        return JSON.stringify({
          ok: false,
          reason: (e && e.message) ? e.message : String(e),
          stack: (e && e.stack) ? String(e.stack).split('\n').slice(0, 3).join(' | ') : ''
        });
      }
    }
  };

  window.__sirius = api;
})();
""".trimIndent()

    /**
     * A call to `__sirius.report`, guarded for the window where the page has
     * navigated and the harness has not been injected into the new document yet.
     * Returning a shaped failure rather than `undefined` keeps the Kotlin side
     * from having to tell "no harness" apart from "malformed JSON".
     */
    fun reportScript(sinceMs: Long, level: String): String {
        val safeLevel = JSONObject.quote(level.ifBlank { "all" })
        return "(window.__sirius ? window.__sirius.report($sinceMs, $safeLevel) : " +
            "JSON.stringify({ok:false,reason:'harness not installed'}))"
    }

    /** A call to `__sirius.frames`, or -1 when the harness is not there. */
    fun framesScript(): String = "(window.__sirius ? window.__sirius.frames() : -1)"

    /** Dispatches a synthetic tap and returns the element description. */
    fun tapScript(x: Int, y: Int): String =
        "(window.__sirius ? window.__sirius.tap($x, $y) : '')"

    /** Presses a key and releases it after [holdMs]. */
    fun keyScript(code: String, holdMs: Long): String {
        val safeCode = JSONObject.quote(code)
        return "(window.__sirius ? window.__sirius.key($safeCode, $holdMs) : '')"
    }

    /** The interactive elements the page is currently showing. */
    fun snapshotScript(): String =
        "(window.__sirius ? JSON.stringify(window.__sirius.snapshot()) : '[]')"

    /** `canvas.toDataURL` from inside the page, as a data url or an empty string. */
    fun captureScript(quality: Int): String {
        val clamped = quality.coerceIn(20, 95) / 100.0
        return "(window.__sirius ? window.__sirius.capture($clamped) : '')"
    }

    /**
     * Evaluates [expression] inside the page.
     *
     * The expression is passed as a quoted argument rather than pasted into the
     * script. Pasting would break on the first apostrophe in the model's code and
     * would make the script itself a place where an argument can change control
     * flow; quoting keeps the boundary between script and data intact.
     */
    fun evalScript(expression: String): String {
        val quoted = JSONObject.quote(expression)
        return "(window.__sirius ? window.__sirius.evaluate($quoted) : " +
            "JSON.stringify({ok:false,reason:'harness not installed'}))"
    }
}
