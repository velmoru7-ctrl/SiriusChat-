package com.sirius.chat.data.preview

import android.app.Activity
import android.content.Context
import android.content.ContextWrapper
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Rect
import android.os.Handler
import android.os.Looper
import android.util.Base64
import android.view.PixelCopy
import android.view.View
import android.view.Window
import android.webkit.WebView
import com.sirius.chat.domain.model.PreviewShot
import com.sirius.chat.domain.model.PreviewShotSource
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withContext
import kotlinx.coroutines.withTimeoutOrNull
import java.io.ByteArrayOutputStream
import kotlin.coroutines.resume

/**
 * Turns whatever the page is showing into something a vision model can afford to
 * look at.
 *
 * ### Why there are two Android paths
 * `PixelCopy` reads the real window buffer, so it returns the true composite:
 * DOM, CSS effects and WebGL together, exactly as a person sees it. It only
 * works while the WebView is attached to a window that has a surface, which
 * means it needs the preview screen to be in front.
 *
 * `View.draw` needs nothing, works with the screen closed, and renders the DOM
 * correctly -- but a WebGL canvas is composited by the GPU outside the view's
 * own drawing pass, so it usually comes out black. Both paths are here because
 * neither alone covers the two situations that matter: the user watching, and
 * the agent working while the user is in the chat.
 *
 * A black frame is reported as black rather than sent as if it were a picture of
 * the game. The distinction is not academic -- a model shown a black rectangle
 * concludes the renderer is broken and rewrites working code.
 *
 * ### Why compression is not optional
 * A phone frame is around a megabyte. Base64 inflates it by a third, and a
 * megabyte of image is thousands of tokens: two screenshots and the context
 * window is gone, which in a repair loop means the model forgets the bug it was
 * fixing. 768 px wide at JPEG 65 lands at 30-50 KB, which is a few hundred
 * tokens and still legible enough to see a misplaced sprite or an empty screen.
 */
object PreviewCapture {

    /** Widest frame that still reads clearly at typical vision resolutions. */
    const val MAX_WIDTH = 768

    /** JPEG quality. Below about 55 the text in a HUD stops being readable. */
    const val QUALITY = 65

    /** How long to wait for the compositor before falling back. */
    private const val PIXEL_COPY_TIMEOUT_MS = 1_200L

    /** Mean luminance under which a frame counts as "nothing was drawn". */
    private const val BLACK_LUMA = 12

    /** Grid the black check samples. 32x32 is a thousand pixels, which is plenty. */
    private const val SAMPLE_STEPS = 32

    /**
     * Captures the window composite, falling back to an offscreen draw.
     *
     * Returns a [PreviewShot] with [PreviewShotSource.None] and a reason rather
     * than throwing: "the screen is not open" and "the page has no surface yet"
     * are both things the agent should read and route around, not failures of the
     * run.
     */
    suspend fun window(view: WebView, maxWidth: Int, quality: Int): PreviewShot {
        val bitmap = withContext(Dispatchers.Main) { grabWindow(view) }
            ?: return offscreen(view, maxWidth, quality)
        return withContext(Dispatchers.Default) {
            encode(bitmap, maxWidth, quality, PreviewShotSource.Window)
        }
    }

    /** Draws the view into a bitmap. Works detached; WebGL may come out black. */
    suspend fun offscreen(view: WebView, maxWidth: Int, quality: Int): PreviewShot {
        val bitmap = withContext(Dispatchers.Main) { grabOffscreen(view) }
            ?: return PreviewShot(
                source = PreviewShotSource.None,
                reason = "the preview has no size yet; open the preview screen or pass a " +
                    "width and height to preview_start"
            )
        return withContext(Dispatchers.Default) {
            encode(bitmap, maxWidth, quality, PreviewShotSource.Offscreen)
        }
    }

    /**
     * Re-encodes a data url produced inside the page.
     *
     * This is the only path that is immune to both problems above: it is the
     * canvas asking itself what it drew, so it needs no window and no view
     * drawing pass. What it cannot see is everything outside the canvas -- HTML
     * overlays, the score in a div, a dialog on top -- which is exactly the
     * layout a broken game usually gets wrong.
     */
    suspend fun fromDataUrl(dataUrl: String, maxWidth: Int, quality: Int): PreviewShot =
        withContext(Dispatchers.Default) {
            val comma = dataUrl.indexOf(',')
            if (!dataUrl.startsWith("data:image") || comma <= 0) {
                return@withContext PreviewShot(
                    source = PreviewShotSource.None,
                    reason = "the page has no canvas, or the canvas refused toDataURL " +
                        "(a cross-origin texture taints it)"
                )
            }
            val raw = runCatching {
                Base64.decode(dataUrl.substring(comma + 1), Base64.DEFAULT)
            }.getOrNull()
            if (raw == null || raw.isEmpty()) {
                return@withContext PreviewShot(
                    source = PreviewShotSource.None,
                    reason = "the canvas returned an unreadable frame"
                )
            }
            val bitmap = runCatching {
                android.graphics.BitmapFactory.decodeByteArray(raw, 0, raw.size)
            }.getOrNull() ?: return@withContext PreviewShot(
                source = PreviewShotSource.None,
                reason = "the canvas frame could not be decoded"
            )
            encode(bitmap, maxWidth, quality, PreviewShotSource.Canvas)
        }

    // --------------------------------------------------------------- internals

    private suspend fun grabWindow(view: WebView): Bitmap? {
        if (!view.isAttachedToWindow || view.width <= 0 || view.height <= 0) return null
        val window = view.hostWindow() ?: return null
        val bitmap = runCatching {
            Bitmap.createBitmap(view.width, view.height, Bitmap.Config.ARGB_8888)
        }.getOrNull() ?: return null

        val origin = IntArray(2)
        view.getLocationInWindow(origin)
        val rect = Rect(
            origin[0],
            origin[1],
            origin[0] + view.width,
            origin[1] + view.height
        )

        val copied = withTimeoutOrNull(PIXEL_COPY_TIMEOUT_MS) {
            suspendCancellableCoroutine { continuation ->
                runCatching {
                    PixelCopy.request(window, rect, bitmap, { result ->
                        if (continuation.isActive) {
                            continuation.resume(result == PixelCopy.SUCCESS)
                        }
                    }, Handler(Looper.getMainLooper()))
                }.onFailure {
                    // Thrown when the window has no surface yet. Not an error
                    // worth propagating: the offscreen path handles this case.
                    if (continuation.isActive) continuation.resume(false)
                }
            }
        }

        if (copied != true) {
            bitmap.recycle()
            return null
        }
        return bitmap
    }

    private fun grabOffscreen(view: WebView): Bitmap? {
        val width = view.width.takeIf { it > 0 } ?: view.measuredWidth
        val height = view.height.takeIf { it > 0 } ?: view.measuredHeight
        if (width <= 0 || height <= 0) return null
        return runCatching {
            val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            // Black, not white. An unpainted region that arrives white looks
            // like a page that rendered a blank body; black matches the surface
            // colour and is what the black-frame check is calibrated against.
            canvas.drawColor(android.graphics.Color.BLACK)
            view.draw(canvas)
            bitmap
        }.getOrNull()
    }

    private fun encode(
        source: Bitmap,
        maxWidth: Int,
        quality: Int,
        origin: PreviewShotSource
    ): PreviewShot {
        val limit = maxWidth.coerceIn(240, 1_600)
        val scaled = if (source.width > limit) {
            val height = (source.height.toFloat() * limit / source.width).toInt().coerceAtLeast(1)
            runCatching { Bitmap.createScaledBitmap(source, limit, height, true) }
                .getOrDefault(source)
        } else {
            source
        }

        val black = isBlack(scaled)
        val stream = ByteArrayOutputStream()
        val compressed = runCatching {
            scaled.compress(Bitmap.CompressFormat.JPEG, quality.coerceIn(20, 95), stream)
        }.getOrDefault(false)
        val bytes = stream.toByteArray()

        val width = scaled.width
        val height = scaled.height
        if (scaled !== source) scaled.recycle()
        source.recycle()

        if (!compressed || bytes.isEmpty()) {
            return PreviewShot(
                source = PreviewShotSource.None,
                reason = "the frame could not be compressed"
            )
        }

        return PreviewShot(
            // NO_WRAP matters: the default encoder inserts newlines every 76
            // characters, and a JSON payload carrying them is rejected by some
            // gateways and silently truncated by others.
            base64 = Base64.encodeToString(bytes, Base64.NO_WRAP),
            mediaType = "image/jpeg",
            width = width,
            height = height,
            bytes = bytes.size,
            source = origin,
            hash = SandboxOverlay.hash(bytes),
            black = black
        )
    }

    /**
     * Whether the frame is uniformly dark.
     *
     * Sampled on a grid rather than averaged over every pixel: a full pass over
     * a 768x1600 bitmap is a million reads for a question a thousand answers
     * just as well.
     */
    private fun isBlack(bitmap: Bitmap): Boolean {
        val stepX = (bitmap.width / SAMPLE_STEPS).coerceAtLeast(1)
        val stepY = (bitmap.height / SAMPLE_STEPS).coerceAtLeast(1)
        var total = 0L
        var count = 0
        var y = 0
        while (y < bitmap.height) {
            var x = 0
            while (x < bitmap.width) {
                val pixel = runCatching { bitmap.getPixel(x, y) }.getOrDefault(0)
                val red = (pixel shr 16) and 0xFF
                val green = (pixel shr 8) and 0xFF
                val blue = pixel and 0xFF
                // Rec. 601 luma, integer arithmetic. Perceptual weighting matters
                // here: a dark blue background is visually black, a saturated
                // green of the same numeric average is plainly not.
                total += (red * 299 + green * 587 + blue * 114) / 1000
                count++
                x += stepX
            }
            y += stepY
        }
        if (count == 0) return false
        return (total / count) < BLACK_LUMA
    }

    /**
     * The window this view is drawn into, if any.
     *
     * The WebView is built with the application context so that it can outlive
     * any single screen, which means its own `context` is never an Activity. The
     * root view's context is, once it has been attached -- that is the decor
     * view's context, and it is the only handle to the window available from
     * here.
     */
    private fun View.hostWindow(): Window? {
        activityOf(rootView.context)?.window?.let { return it }
        return activityOf(context)?.window
    }

    private fun activityOf(context: Context?): Activity? {
        var current = context
        while (current is ContextWrapper) {
            if (current is Activity) return current
            current = current.baseContext
        }
        return null
    }
}
