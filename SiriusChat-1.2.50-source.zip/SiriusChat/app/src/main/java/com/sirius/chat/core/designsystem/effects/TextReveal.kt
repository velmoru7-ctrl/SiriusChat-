@file:OptIn(androidx.compose.ui.text.ExperimentalTextApi::class)

package com.sirius.chat.core.designsystem.effects

import android.os.Build
import androidx.annotation.RequiresApi
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ScrollState
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.size
import androidx.compose.ui.geometry.isSpecified
import androidx.compose.ui.unit.IntOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.clearAndSetSemantics
import androidx.compose.ui.text.*
import androidx.compose.ui.text.input.OffsetMapping
import androidx.compose.ui.text.input.TransformedText
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.util.Graphemes
import com.sirius.chat.domain.model.TextAnimationSettings
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.first
import kotlin.math.*
import kotlin.random.Random

/**
 * Native Compose adaptation of Text Animation (fork) 9.2, supplied by the user.
 * Original authors: @mihailkotovski & @mishabotov; fork: @private_let & @TextAnimation.
 * No Telegram hooks, reflective loaders or embedded executable DEX are used.
 * The actual field still owns text, selection, composition, clipboard and semantics.
 */
@Stable
class TextRevealState internal constructor(
    internal val settings: TextAnimationSettings,
    private val scroll: ScrollState? = null
) {
    internal var layout: TextLayoutResult? by mutableStateOf(null)
        private set
    internal val glyphs = mutableStateListOf<RevealGlyph>()
    internal val particles = mutableStateListOf<DeleteParticle>()
    internal var frameNanos by mutableLongStateOf(System.nanoTime())
        private set
    internal var hiddenRevision by mutableIntStateOf(0)
        private set
    internal var selection by mutableStateOf(TextRange.Zero)
        private set
    internal var composition by mutableStateOf<TextRange?>(null)
        private set
    internal var focused by mutableStateOf(false)
        private set
    internal var cursor: Offset by mutableStateOf(Offset.Unspecified)
        private set
    internal var selectionHead: Offset by mutableStateOf(Offset.Unspecified)
        private set
    internal var motion by mutableStateOf(Offset.Zero)
        private set
    internal var pulse by mutableFloatStateOf(0f)
        private set
    internal var pulseKind = ""
        private set
    private var pulseStarted = 0L
    private var previous: String? = null
    private var nextId = 0L
    private var lastFrame = 0L
    private var cursorChanged = System.nanoTime()
    private val random = Random(9201)
    internal val scrollY: Float get() = scroll?.value?.toFloat() ?: 0f
    internal val hasCursor: Boolean get() = settings.enabled && settings.cursorEnabled && focused && selection.collapsed && composition == null && layout != null
    internal val hasSelection: Boolean get() = settings.enabled && focused && !selection.collapsed && settings.selectionCursorEffect == 1
    internal val hasWork: Boolean get() = glyphs.isNotEmpty() || particles.isNotEmpty() ||
        ((hasCursor || hasSelection) && (System.nanoTime() - cursorChanged < 1_000_000_000L || pulse > 0f))
    internal val cursorVisible: Boolean get() = (frameNanos - cursorChanged).coerceAtLeast(0) % 1_060_000_000L < 620_000_000L

    fun onTextLayout(result: TextLayoutResult) {
        // Color-only transformations must not start a layout/recomposition loop.
        val old = layout
        if (old == null || old.layoutInput.text.text != result.layoutInput.text.text || old.size != result.size ||
            old.layoutInput.style != result.layoutInput.style || old.lineCount != result.lineCount) {
            layout = result
            cursorChanged = System.nanoTime()
        }
    }

    fun onInput(text: String, caret: TextRange, composing: TextRange?, isFocused: Boolean) {
        val now = System.nanoTime()
        if (selection != caret || focused != isFocused) cursorChanged = now
        selection = caret
        composition = composing
        focused = isFocused
        val old = previous
        previous = text
        if (old == null || old == text) return
        if (!settings.enabled) { glyphs.clear(); particles.clear(); hiddenRevision++; return }
        val edit = Graphemes.diff(old, text)
        val removed = edit.oldEnd - edit.oldStart
        val inserted = edit.newEnd - edit.newStart
        val shift = text.length - old.length
        val sourceLayout = layout?.takeIf { it.layoutInput.text.text == old }
        // Autocorrection is a replacement, not a backspace. Do not spray the IME's draft away.
        if (removed > 0 && settings.deleteAnimationEnabled && !(composing != null && inserted > 0) && sourceLayout != null) {
            val bounds = Graphemes.boundaries(old)
            val oldLine = sourceLayout.getLineForOffset(edit.oldEnd.coerceIn(0, old.length))
            bounds.asList().zipWithNext().filter { (start, end) ->
                start >= edit.oldStart && end <= edit.oldEnd &&
                    (settings.animateAllLines || sourceLayout.getLineForOffset(start) == oldLine)
            }.takeLast(24).forEach { (start, end) ->
                val cluster = old.substring(start, end)
                if (!settings.ignoreSpaces || cluster.any { !it.isWhitespace() }) {
                    rangeBox(sourceLayout, start, end)?.let { spawn(cluster, it, now) }
                }
            }
        }
        glyphs.removeAll { it.start < edit.oldEnd && it.end > edit.oldStart }
        glyphs.forEach { glyph -> if (glyph.start >= edit.oldEnd) { glyph.start += shift; glyph.end += shift } }
        if (inserted > 0) {
            val lineStart = text.lastIndexOf('\n', caret.end - 1).let { it + 1 }
            val lineEnd = text.indexOf('\n', caret.end.coerceIn(0, text.length)).let { if (it < 0) text.length else it }
            val clusters = Graphemes.boundaries(text).asList().zipWithNext().filter { (start, end) ->
                start >= edit.newStart && end <= edit.newEnd &&
                    (settings.animateAllLines || (start >= lineStart && end <= lineEnd))
            }
            // A huge paste is instant; it must never allocate hundreds of GPU layers.
            if (clusters.size <= 24) clusters.forEachIndexed { order, (start, end) ->
                if (glyphs.size < 48 && (!settings.ignoreSpaces || text.substring(start, end).any { !it.isWhitespace() })) {
                    glyphs += RevealGlyph(nextId++, start, end, now + order * 12_000_000L)
                }
            }
        }
        pulseKind = when {
            inserted > 0 && text.substring(edit.newStart, edit.newEnd).contains('\n') -> "enter"
            inserted > 0 && text.substring(edit.newStart, edit.newEnd).all { it == ' ' } -> "space"
            removed > 0 && inserted == 0 -> "backspace"
            else -> ""
        }
        pulseStarted = now
        pulse = if (pulseKind.isEmpty()) 0f else 0.01f
        cursorChanged = now
        hiddenRevision++
    }

    private fun spawn(text: String, box: Rect, now: Long) {
        repeat(settings.particleCount) {
            if (particles.size >= 192) particles.removeAt(0)
            val angle = random.nextFloat() * PI.toFloat() * 2f
            val speed = (12f + settings.particleSpeed * 2.0f) * (0.45f + random.nextFloat())
            val spread = settings.particleSpread / 50f
            particles += DeleteParticle(nextId++, text,
                Offset(box.center.x, box.center.y - scrollY),
                Offset(cos(angle) * speed * spread, sin(angle) * speed - 25f),
                now, (settings.durationMillis * 2L).coerceIn(240L, 1800L) * 1_000_000L,
                0.6f + random.nextFloat() * 1.1f, random.nextFloat() * 360f)
        }
    }

    internal fun hideAnimating(source: AnnotatedString): AnnotatedString {
        if (!settings.enabled || source.text != previous || glyphs.isEmpty()) return source
        return AnnotatedString.Builder(source).apply {
            glyphs.forEach { if (it.start >= 0 && it.end <= source.length && it.start < it.end) {
                addStyle(SpanStyle(color = Color.Transparent), it.start, it.end)
            } }
        }.toAnnotatedString()
    }

    internal fun tick(now: Long) {
        val dt = if (lastFrame == 0L) 1f / 60f else ((now - lastFrame) / 1_000_000_000f).coerceIn(0f, 0.05f)
        lastFrame = now
        frameNanos = now
        if (glyphs.removeAll { now - it.born >= settings.lifetimeMillis * 1_000_000L }) hiddenRevision++
        particles.removeAll { now - it.born >= it.lifetime }
        pulse = if (pulseKind.isEmpty()) 0f else sin(PI.toFloat() *
            ((now - pulseStarted) / (settings.durationMillis * 1_000_000f)).coerceIn(0f, 1f)).coerceAtLeast(0f)
        if (now - pulseStarted >= settings.durationMillis * 1_000_000L) pulse = 0f
        val currentLayout = layout ?: return
        val length = currentLayout.layoutInput.text.length
        val end = currentLayout.getCursorRect(selection.end.coerceIn(0, length)).topLeft
        val start = currentLayout.getCursorRect(selection.start.coerceIn(0, length)).topLeft
        val factor = 1f - exp(-settings.cursorSpeed * 1.6f * dt)
        if (!cursor.isSpecified) cursor = end
        if (!selectionHead.isSpecified) selectionHead = start
        motion = end - cursor
        cursor += motion * factor
        selectionHead += (start - selectionHead) * factor
        if ((end - cursor).getDistance() < 0.08f) cursor = end
    }

    internal fun progress(glyph: RevealGlyph): Float {
        val raw = ((frameNanos - glyph.born) / (settings.durationMillis * 1_000_000f)).coerceIn(0f, 1f)
        return 1f - (1f - raw).pow(3)
    }
    internal fun blur(glyph: RevealGlyph): Float {
        val elapsed = (frameNanos - glyph.born) / 1_000_000f
        val held = settings.blurDurationMillis * settings.blurHoldPercent / 100f
        return 1f - ((elapsed - held) / (settings.blurDurationMillis - held).coerceAtLeast(1f)).coerceIn(0f, 1f)
    }
}

@Stable
internal class RevealGlyph(val id: Long, start: Int, end: Int, val born: Long) {
    var start by mutableIntStateOf(start)
    var end by mutableIntStateOf(end)
}
internal data class DeleteParticle(val id: Long, val text: String, val origin: Offset, val velocity: Offset,
    val born: Long, val lifetime: Long, val size: Float, val rotation: Float)

@Composable
fun rememberTextRevealState(
    settings: TextAnimationSettings,
    text: String,
    selection: TextRange = TextRange(text.length),
    composition: TextRange? = null,
    focused: Boolean = false,
    scroll: ScrollState? = null
): TextRevealState {
    val reduce = SiriusTheme.reduceMotion
    val resolved = remember(settings, reduce) { settings.coerced().let { if (reduce) it.copy(enabled = false) else it } }
    val state = remember(resolved, scroll) { TextRevealState(resolved, scroll) }
    SideEffect { state.onInput(text, selection, composition, focused) }
    LaunchedEffect(state) {
        while (true) {
            snapshotFlow { state.hasWork || state.hasCursor || state.hasSelection }.first { it }
            if (state.hasWork) withFrameNanos { state.tick(it) }
            else { delay(100); state.tick(System.nanoTime()) } // Idle blink, not a permanent 120Hz loop.
        }
    }
    return state
}

@Composable
fun TextRevealState.rememberHidingTransformation(): VisualTransformation {
    val revision = hiddenRevision
    return remember(this, revision) { VisualTransformation { source ->
        TransformedText(hideAnimating(source), OffsetMapping.Identity)
    } }
}

@Composable
fun TextRevealOverlay(state: TextRevealState, style: TextStyle, modifier: Modifier = Modifier) {
    val config = state.settings
    if (!config.enabled) return
    val layout = state.layout ?: return
    val density = LocalDensity.current
    val measurer = rememberTextMeasurer(cacheSize = 16)
    // One fully shaped paragraph, then cropped per grapheme. Arabic, ligatures and emoji
    // retain the same contextual shaping, rather than being remeasured one UTF-16 char at a time.
    val visible = remember(layout.layoutInput.text.text, layout.size.width, style, density) {
        measurer.measure(AnnotatedString(layout.layoutInput.text.text), style,
            constraints = Constraints(maxWidth = layout.size.width.coerceAtLeast(1)),
            layoutDirection = layout.layoutInput.layoutDirection)
    }
    val slide = with(density) { config.slideDistanceDp.dp.toPx() }
    val blur = with(density) { (config.blurRadius * TextAnimationSettings.BlurRadiusToDp).dp.toPx() }
    val letters = if (config.particleStyle == 4) state.particles.map { it.text }.distinct().associateWith {
        measurer.measure(AnnotatedString(it), style, maxLines = 1)
    } else emptyMap()
    Box(modifier.clearAndSetSemantics { }) {
        state.glyphs.forEach { glyph ->
            val bounds = rangeBox(layout, glyph.start, glyph.end) ?: return@forEach
            key(glyph.id) {
                val width = with(density) { ceil(bounds.width).coerceAtLeast(1f).toDp() }
                val height = with(density) { ceil(bounds.height).coerceAtLeast(1f).toDp() }
                Canvas(Modifier.offset { IntOffset(floor(bounds.left).toInt(), floor(bounds.top).toInt()) }
                    .size(width, height).graphicsLayer {
                    val t = state.progress(glyph)
                    alpha = t
                    transformOrigin = TransformOrigin.Center
                    translationX = bounds.left - floor(bounds.left)
                    translationY = bounds.top - floor(bounds.top) - if (config.slideEnabled) (1f - t) * slide else 0f
                    if (config.scaleEnabled) { scaleX = config.scaleStart + (1f - config.scaleStart) * t; scaleY = scaleX }
                    if (config.rotateEnabled) rotationZ = config.rotateDegrees * (1f - t)
                    if (config.blurEnabled && Build.VERSION.SDK_INT >= 31) renderEffect = BlurEffects.of(blur * state.blur(glyph))
                }) {
                    clipRect(0f, 0f, bounds.width.coerceAtLeast(0.1f), bounds.height) {
                        drawText(visible, color = style.color, topLeft = Offset(-bounds.left, -bounds.top))
                    }
                }
            }
        }
        Canvas(Modifier.fillMaxSize()) {
            val now = state.frameNanos
            state.particles.forEach { particle ->
                val t = ((now - particle.born).toFloat() / particle.lifetime).coerceIn(0f, 1f)
                val seconds = (now - particle.born).coerceAtLeast(0L) / 1_000_000_000f
                val pos = particle.origin + particle.velocity * (seconds * this.density) + Offset(0f, 65f * seconds * seconds * this.density + state.scrollY)
                val radius = (config.particleSize / 50f) * particle.size * 2.dp.toPx() * (1f - t * 0.65f)
                val color = style.color.copy(alpha = (1f - t).pow(1.6f))
                rotate(particle.rotation + 90f * seconds, pos) {
                    when (config.particleStyle) {
                        1 -> drawLine(color, pos, pos - particle.velocity * 0.045f, strokeWidth = radius, cap = StrokeCap.Round)
                        2 -> repeat(3) { arm ->
                            val angle = arm * PI.toFloat() / 3f
                            val delta = Offset(cos(angle), sin(angle)) * radius * 2.4f
                            drawLine(color, pos - delta, pos + delta, strokeWidth = max(0.8f, radius * 0.45f), cap = StrokeCap.Round)
                        }
                        3 -> drawOval(color, pos - Offset(radius, radius * 1.6f), Size(radius * 2f, radius * 3.2f))
                        4 -> letters[particle.text]?.let { letter ->
                            val factor = (config.particleSize / 50f) * (1f - t * 0.4f)
                            withTransform({
                                scale(scaleX = factor, scaleY = factor, pivot = pos)
                            }) {
                                drawText(letter, color = color, topLeft = pos - Offset(letter.size.width / 2f, letter.size.height / 2f))
                            }
                        }
                        else -> drawCircle(color, radius, pos)
                    }
                }
            }
            if (state.hasCursor && state.cursor.isSpecified && state.cursorVisible) {
                val rect = layout.getCursorRect(state.selection.end.coerceIn(0, layout.layoutInput.text.length))
                val width = config.cursorWidthDp.dp.toPx()
                val liquid = if (config.liquidCursorEnabled) min(40.dp.toPx(), abs(state.motion.x) * config.liquidScaleFactor / 100f) else 0f
                val dy = when (state.pulseKind) { "enter" -> rect.height * state.pulse * 0.35f; "space" -> -rect.height * state.pulse * 0.18f; else -> 0f }
                val growth = if (state.pulseKind == "backspace") width * state.pulse * 0.65f else 0f
                val left = state.cursor.x - width / 2f - if (state.motion.x >= 0f) liquid else 0f
                drawRoundRect(style.color, Offset(left, state.cursor.y + dy), Size(width + liquid + growth, rect.height), CornerRadius(width / 2f))
            }
            if (state.hasSelection && state.cursor.isSpecified && state.selectionHead.isSpecified) {
                val length = layout.layoutInput.text.length
                listOf(state.selectionHead to state.selection.start, state.cursor to state.selection.end).forEach { (point, offset) ->
                    val target = layout.getCursorRect(offset.coerceIn(0, length))
                    val trail = min(48.dp.toPx(), (target.topLeft - point).getDistance() * config.selectionLiquidStretch / 100f)
                    val width = config.cursorWidthDp.dp.toPx() + trail
                    drawRoundRect(style.color.copy(alpha = 0.65f),
                        point - Offset(trail * config.selectionLiquidSide / 200f, 0f),
                        Size(width, target.height), CornerRadius(width / 2f))
                }
            }
            if (config.debugMode) {
                drawRect(Color.Magenta.copy(alpha = 0.6f), style = androidx.compose.ui.graphics.drawscope.Stroke(1.dp.toPx()))
                state.glyphs.forEach { glyph -> rangeBox(layout, glyph.start, glyph.end)?.let { rect ->
                    drawRect(Color.Cyan.copy(alpha = 0.5f), rect.topLeft, rect.size, style = androidx.compose.ui.graphics.drawscope.Stroke(1f))
                } }
            }
        }
    }
}

internal fun rangeBox(layout: TextLayoutResult, start: Int, end: Int): Rect? {
    if (start < 0 || start >= end || end > layout.layoutInput.text.length) return null
    var box = layout.getBoundingBox(start)
    for (index in start + 1 until end) {
        val next = layout.getBoundingBox(index)
        box = Rect(min(box.left, next.left), min(box.top, next.top), max(box.right, next.right), max(box.bottom, next.bottom))
    }
    return box
}

@Composable
fun AnimatedRevealText(text: String, style: TextStyle, settings: TextAnimationSettings, modifier: Modifier = Modifier) {
    val state = rememberTextRevealState(settings, text, focused = true)
    val revision = state.hiddenRevision
    val visible = remember(text, revision) { state.hideAnimating(AnnotatedString(text)) }
    Box(modifier) {
        Text(visible, style = style, onTextLayout = state::onTextLayout, modifier = Modifier.fillMaxWidth())
        TextRevealOverlay(state, style, Modifier.matchParentSize())
    }
}

@RequiresApi(31)
private object BlurEffects {
    private val cache = arrayOfNulls<RenderEffect>(128)
    fun of(radius: Float): RenderEffect? {
        if (radius <= 0.2f) return null
        val step = (radius / 0.5f).roundToInt().coerceIn(1, cache.lastIndex)
        return cache[step] ?: android.graphics.RenderEffect.createBlurEffect(step * 0.5f, step * 0.5f, android.graphics.Shader.TileMode.DECAL)
            .asComposeRenderEffect().also { cache[step] = it }
    }
}
