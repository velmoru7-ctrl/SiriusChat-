package com.sirius.chat.ai.pricing

import android.util.AtomicFile
import com.sirius.chat.domain.model.TokenUsage
import com.sirius.chat.domain.repository.SettingsRepository
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.NonCancellable
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.sync.Mutex
import kotlinx.coroutines.sync.withLock
import kotlinx.coroutines.withContext
import kotlinx.serialization.Serializable
import kotlinx.serialization.json.Json
import java.io.File
import java.util.UUID
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.AbstractCoroutineContextElement
import kotlin.coroutines.CoroutineContext
import kotlin.coroutines.coroutineContext

/** Bound once per user turn and inherited by agent tools and background work. */
class TaskCostContext(val taskId: String, val sessionId: String) : AbstractCoroutineContextElement(Key) {
    companion object Key : CoroutineContext.Key<TaskCostContext>
}

@Serializable
data class PriceRule(
    val providerId: String,
    val model: String,
    val inputPerMillion: Double,
    val outputPerMillion: Double,
    val imageUsd: Double? = null
) {
    fun valid(): Boolean = providerId.isNotBlank() && model.isNotBlank() &&
        listOfNotNull(inputPerMillion, outputPerMillion, imageUsd).all { it.isFinite() && it >= 0.0 }
}

@Serializable
data class UsageTask(
    val id: String,
    val sessionId: String,
    val createdAt: Long,
    val budgetUsd: Double = 0.0,
    val stoppedReason: String = ""
)

@Serializable
data class UsageAttempt(
    val id: String,
    val taskId: String,
    val providerId: String,
    val model: String,
    val purpose: String,
    val createdAt: Long,
    val status: String = "pending",
    val inputTokens: Long = 0,
    val outputTokens: Long = 0,
    val estimatedTokens: Boolean = true,
    val costUsd: Double? = null,
    val reservedUsd: Double? = null,
    val inputRate: Double? = null,
    val outputRate: Double? = null,
    val imageRate: Double? = null,
    val priceSource: String = "unknown"
)

@Serializable
data class UsageState(
    val tasks: List<UsageTask> = emptyList(),
    val attempts: List<UsageAttempt> = emptyList(),
    val prices: List<PriceRule> = emptyList()
) {
    fun latest(sessionId: String): UsageTask? = tasks.lastOrNull { it.sessionId == sessionId }
    fun forTask(id: String): List<UsageAttempt> = attempts.filter { it.taskId == id }
}

class BudgetStoppedException(message: String) : IllegalStateException(message)

/**
 * Persistent, prompt-free accounting. Amounts are estimates, not the provider's invoice.
 * Reservations are serialized across concurrent calls in one task. Unknown billing or
 * missing tariffs stops budgeted tasks rather than silently treating a call as free.
 */
class UsageLedger(
    file: File,
    private val settings: SettingsRepository,
    scope: CoroutineScope
) {
    private val file = AtomicFile(file)
    private val mutex = Mutex()
    private val json = Json { ignoreUnknownKeys = true; encodeDefaults = true }
    private var loaded = false
    private val sessions = ConcurrentHashMap<String, TaskCostContext>()
    private val _state = MutableStateFlow(UsageState())
    val state: StateFlow<UsageState> = _state.asStateFlow()

    init { scope.launch(Dispatchers.IO) { runCatching { mutex.withLock { load() } } } }

    fun newTask(sessionId: String): TaskCostContext = TaskCostContext(UUID.randomUUID().toString(), sessionId)
        .also { if (sessionId.isNotBlank()) sessions[sessionId] = it }

    fun forSession(sessionId: String): TaskCostContext = sessions[sessionId] ?: newTask(sessionId)

    suspend fun register(task: TaskCostContext) {
        val budget = settings.current().taskBudgetUsd.takeIf { it.isFinite() && it > 0.0 } ?: 0.0
        withContext(Dispatchers.IO) { mutex.withLock {
            load()
            if (_state.value.tasks.none { it.id == task.taskId }) {
                persist(_state.value.copy(tasks = _state.value.tasks + UsageTask(
                    task.taskId, task.sessionId, System.currentTimeMillis(), budget
                )))
            }
        } }
    }

    suspend fun savePrice(rule: PriceRule) = withContext(Dispatchers.IO) { mutex.withLock {
        require(rule.valid()) { "Prices must be finite, non-negative USD amounts." }
        load()
        persist(_state.value.copy(prices = _state.value.prices.filterNot {
            it.providerId == rule.providerId && it.model == rule.model
        } + rule))
    } }

    suspend fun before(
        providerId: String,
        model: String,
        purpose: String,
        promptReserve: Long = 0,
        outputReserve: Long = 0,
        hasMedia: Boolean = false,
        image: Boolean = false
    ): UsageAttempt {
        val taskContext = coroutineContext[TaskCostContext] ?: newTask("")
        register(taskContext)
        return withContext(Dispatchers.IO) { mutex.withLock {
            load()
            val state = _state.value
            val task = state.tasks.first { it.id == taskContext.taskId }
            val rule = state.prices.firstOrNull { it.providerId == providerId && it.model == model }
            val reference = if (image) null else ModelPricing.of(model)
            val builtinFree = image && providerId == BUILTIN_IMAGE_PROVIDER
            val input = rule?.inputPerMillion ?: reference?.inputPerMillion
            val output = rule?.outputPerMillion ?: reference?.outputPerMillion
            val imagePrice = if (builtinFree) 0.0 else rule?.imageUsd
            val source = when { builtinFree -> "builtin"; rule != null -> "manual"; reference != null -> "reference"; else -> "unknown" }
            val reserve = when {
                image -> imagePrice
                hasMedia -> null // Provider tokenization of image/PDF input has no reliable local upper bound.
                input != null && output != null -> CostMath.tokenCost(promptReserve, outputReserve, input, output)
                else -> null
            }
            if (task.budgetUsd > 0.0) {
                val rows = state.forTask(task.id)
                val unknown = rows.any { it.status != "pending" && it.costUsd == null }
                val spent = rows.sumOf { it.costUsd ?: 0.0 }
                val pending = rows.filter { it.status == "pending" }.sumOf { it.reservedUsd ?: 0.0 }
                val reason = when {
                    unknown -> "Стоимость предыдущей попытки неизвестна. / Previous attempt billing is unknown. Start a new task only after checking your provider."
                    reserve == null -> "Нет тарифа или надёжной оценки для $model. / Set a price or remove the estimated task budget before this request."
                    !CostMath.admits(task.budgetUsd, spent, pending, reserve) ->
                        "Лимит задачи достигнут. / Task budget would be exceeded. No new request was sent."
                    else -> null
                }
                if (reason != null) {
                    persist(state.copy(tasks = state.tasks.map { if (it.id == task.id) it.copy(stoppedReason = reason) else it }))
                    throw BudgetStoppedException(reason)
                }
            }
            val attempt = UsageAttempt(
                id = UUID.randomUUID().toString(), taskId = task.id, providerId = providerId,
                model = model, purpose = purpose, createdAt = System.currentTimeMillis(),
                reservedUsd = reserve, inputRate = input, outputRate = output,
                imageRate = if (image) imagePrice else null, priceSource = source
            )
            persist(state.copy(attempts = state.attempts + attempt))
            attempt
        } }
    }

    suspend fun finish(
        attempt: UsageAttempt,
        usage: TokenUsage? = null,
        estimatedInput: Long = 0,
        estimatedOutput: Long = 0,
        success: Boolean,
        hasMedia: Boolean = false,
        image: Boolean = false
    ) = withContext(NonCancellable + Dispatchers.IO) { mutex.withLock {
        load()
        val stored = _state.value.attempts.firstOrNull { it.id == attempt.id } ?: return@withLock
        if (stored.status != "pending") return@withLock
        val input = (usage?.promptTokens?.toLong() ?: estimatedInput).coerceAtLeast(0)
        val output = (usage?.completionTokens?.toLong() ?: estimatedOutput).coerceAtLeast(0)
        val amount = when {
            image && success -> stored.imageRate
            !success && stored.reservedUsd == 0.0 -> 0.0
            !success && usage == null -> null // A timeout is not proof of zero billing.
            hasMedia && usage == null -> null
            stored.inputRate != null && stored.outputRate != null ->
                CostMath.tokenCost(input, output, stored.inputRate, stored.outputRate)
            else -> null
        }
        val completed = stored.copy(
            status = if (success) "complete" else "uncertain",
            inputTokens = input, outputTokens = output,
            estimatedTokens = usage == null || usage.estimated,
            costUsd = amount, reservedUsd = null
        )
        persist(_state.value.copy(attempts = _state.value.attempts.map { if (it.id == stored.id) completed else it }))
    } }

    suspend fun <T> imageCall(providerId: String, model: String, block: suspend () -> T): T {
        val attempt = before(providerId, model, "images", image = true)
        var success = false
        try { return block().also { success = true } }
        finally { finish(attempt, success = success, image = true) }
    }

    private fun load() {
        if (loaded) return
        if (file.baseFile.exists() || File(file.baseFile.path + ".bak").exists()) {
            val state = file.openRead().bufferedReader().use { json.decodeFromString(UsageState.serializer(), it.readText()) }
            // Process death leaves an in-flight charge uncertain, never free.
            _state.value = state.copy(attempts = state.attempts.map {
                if (it.status == "pending") it.copy(status = "uncertain", reservedUsd = null) else it
            })
        }
        loaded = true
    }

    private fun persist(value: UsageState) {
        // Keep complete task groups, never trim the middle of an active task.
        val protected = value.attempts.filter { it.status == "pending" }.map { it.taskId }.toSet()
        val keep = value.tasks.takeLast(200).map { it.id }.toSet() + protected
        val bounded = value.copy(tasks = value.tasks.filter { it.id in keep }, attempts = value.attempts.filter { it.taskId in keep })
        file.baseFile.parentFile?.mkdirs()
        val stream = file.startWrite()
        try {
            stream.write(json.encodeToString(UsageState.serializer(), bounded).toByteArray(Charsets.UTF_8))
            file.finishWrite(stream)
        } catch (error: Exception) {
            file.failWrite(stream)
            throw error
        }
        _state.value = bounded
    }

    companion object { const val BUILTIN_IMAGE_PROVIDER = "builtin-image" }
}
