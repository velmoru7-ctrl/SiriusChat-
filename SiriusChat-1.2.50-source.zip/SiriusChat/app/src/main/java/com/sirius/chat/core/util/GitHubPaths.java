package com.sirius.chat.core.util;

import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;

/** Shared GET/PUT/DELETE path encoding; #, ?, + and Unicode are filenames, not URL syntax. */
public final class GitHubPaths {
    private GitHubPaths() {}
    public static String repository(String value) {
        String repo = value.trim().replaceAll("^/+|/+$", "");
        if (!repo.matches("[A-Za-z0-9_.-]+/[A-Za-z0-9_.-]+"))
            throw new IllegalArgumentException("Use a GitHub repository in owner/name format");
        for (String part : repo.split("/")) {
            if (part.equals(".") || part.equals("..")) throw new IllegalArgumentException("Invalid repository path");
        }
        return repo;
    }
    public static String contents(String repo, String path, String ref) {
        String clean = SafeProjectPaths.relative(path.replaceAll("^/+|/+$", ""), true);
        StringBuilder result = new StringBuilder("/repos/").append(repository(repo)).append("/contents/");
        if (!clean.isEmpty()) {
            for (String segment : clean.split("/")) {
                if (result.charAt(result.length() - 1) != '/') result.append('/');
                result.append(encode(segment));
            }
        }
        if (ref != null && !ref.trim().isEmpty()) result.append("?ref=").append(encode(ref));
        return result.toString();
    }
    private static String encode(String value) {
        try { return URLEncoder.encode(value, "UTF-8").replace("+", "%20"); }
        catch (UnsupportedEncodingException impossible) { throw new AssertionError(impossible); }
    }
}
