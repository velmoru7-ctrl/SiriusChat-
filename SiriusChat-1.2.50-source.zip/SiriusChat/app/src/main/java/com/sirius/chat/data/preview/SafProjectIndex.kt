package com.sirius.chat.data.preview

import android.content.ContentResolver
import android.net.Uri
import android.provider.DocumentsContract
import java.io.File
import java.io.FileOutputStream
import java.util.concurrent.ConcurrentHashMap

/**
 * Maps a project-relative path to the SAF document that holds it.
 *
 * ### Why an index and not a lookup per request
 * `DocumentsContract` has no "find by path". Resolving `assets/hero.png` means
 * walking the tree from the root with one `query` per directory, and a query is
 * a binder round trip. For a forty-file project that is a few hundred
 * milliseconds -- fine once, ruinous on every `shouldInterceptRequest`, which a
 * single page fires dozens of times before it draws.
 *
 * So the walk happens once when the preview starts, and single entries are
 * invalidated as the agent writes. The index is the only thing in the preview
 * path that is allowed to be stale, and it is repaired the moment a read fails.
 *
 * ### Why this also ends path traversal
 * A path is a *key* here, never a path segment joined onto a root. `../../etc`
 * does not resolve to a parent directory, it simply misses the map. The
 * canonical-prefix guard a `File`-backed handler needs has no equivalent here
 * because the class of bug it defends against cannot be expressed.
 */
class SafProjectIndex(
    private val resolver: ContentResolver,
    private val mirrorRoot: File
) {

    /** Outcome of a walk. Named cases because the caller reports each differently. */
    sealed interface Result {
        data class Ok(val files: Int, val mirrored: Int) : Result

        /** The persisted grant is gone: the user revoked it, or the folder was deleted. */
        data object AccessRevoked : Result

        data class Unreadable(val reason: String) : Result
    }

    private val index = ConcurrentHashMap<String, Uri>()
    private val mirrors = ConcurrentHashMap<String, File>()

    /**
     * Directories, keyed the same way, with the tree root under the empty
     * string.
     *
     * Serving a page never needs these -- a request names a file. Committing a
     * sandbox does: creating `src/levels/two.json` requires the document id of
     * `src/levels`, and `DocumentsContract.createDocument` takes a parent, not a
     * path. Collecting them during the walk that is already happening costs one
     * map insert per directory; discovering them later would mean walking the
     * tree a second time.
     */
    private val dirs = ConcurrentHashMap<String, Uri>()

    val fileCount: Int get() = index.size

    /**
     * Walks [treeUri] and replaces the whole index.
     *
     * Access is checked against the persisted grants first rather than
     * discovered through a `SecurityException` halfway down the tree, so a
     * revoked folder is reported as revoked instead of as a half-built index
     * that 404s on most files.
     */
    fun rebuild(treeUri: String): Result {
        val tree = runCatching { Uri.parse(treeUri) }.getOrNull()
            ?: return Result.Unreadable("project uri could not be parsed")
        if (!hasPersistedAccess(tree)) return Result.AccessRevoked
        val rootId = runCatching { DocumentsContract.getTreeDocumentId(tree) }.getOrNull()
            ?: return Result.Unreadable("project uri carries no document id")

        clear()
        dirs[""] = DocumentsContract.buildDocumentUriUsingTree(tree, rootId)
        return try {
            val mirrored = walk(tree, rootId, "", 0)
            Result.Ok(index.size, mirrored)
        } catch (security: SecurityException) {
            clear()
            Result.AccessRevoked
        } catch (failure: Exception) {
            clear()
            Result.Unreadable(failure.message ?: failure.javaClass.simpleName)
        }
    }

    /** The document for [path], or null when the project has no such file. */
    fun resolve(path: String): Uri? = index[path]

    /** The document for a directory, with the project root under `""`. */
    fun resolveDir(path: String): Uri? = dirs[path]

    /** Records a directory discovered or created after the walk. */
    fun putDir(path: String, uri: Uri) {
        dirs[path] = uri
    }

    /** Forgets a directory, for rolling back one this app created. */
    fun forgetDir(path: String) {
        dirs.remove(path)
    }

    /**
     * The cached copy of [path], for the file types a SAF stream cannot serve.
     *
     * See [MIRROR_EXT]: these are read through `Range` requests, and a
     * `WebResourceResponse` built from a SAF stream reports no length and
     * honours no range, so seeking in audio and streaming compilation of large
     * wasm both break. Everything the agent actually edits is served live.
     */
    fun mirrorOf(path: String): File? = mirrors[path]

    /** Points [path] at [uri], or forgets it when [uri] is null. */
    fun invalidate(path: String, uri: Uri?) {
        if (uri == null) {
            index.remove(path)
            mirrors.remove(path)?.delete()
        } else {
            index[path] = uri
        }
    }

    fun clear() {
        index.clear()
        mirrors.clear()
        dirs.clear()
        runCatching { mirrorRoot.deleteRecursively() }
    }

    private fun hasPersistedAccess(tree: Uri): Boolean = runCatching {
        resolver.persistedUriPermissions.any { it.uri == tree && it.isReadPermission }
    }.getOrDefault(false)

    private fun walk(tree: Uri, documentId: String, prefix: String, depth: Int): Int {
        if (depth > MAX_DEPTH) return 0
        var mirrored = 0
        val children = DocumentsContract.buildChildDocumentsUriUsingTree(tree, documentId)
        val columns = arrayOf(
            DocumentsContract.Document.COLUMN_DOCUMENT_ID,
            DocumentsContract.Document.COLUMN_DISPLAY_NAME,
            DocumentsContract.Document.COLUMN_MIME_TYPE
        )
        resolver.query(children, columns, null, null, null)?.use { cursor ->
            while (cursor.moveToNext()) {
                if (index.size >= MAX_FILES) break
                val id = cursor.getString(0) ?: continue
                val name = cursor.getString(1) ?: continue
                val mime = cursor.getString(2).orEmpty()
                val path = if (prefix.isEmpty()) name else prefix + "/" + name
                if (mime == DocumentsContract.Document.MIME_TYPE_DIR) {
                    if (name !in SKIP_DIRS) {
                        dirs[path] = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                        mirrored += walk(tree, id, path, depth + 1)
                    }
                    continue
                }
                val document = DocumentsContract.buildDocumentUriUsingTree(tree, id)
                index[path] = document
                val extension = name.substringAfterLast('.', "").lowercase()
                if (extension in MIRROR_EXT && mirror(path, document)) mirrored++
            }
        }
        return mirrored
    }

    private fun mirror(path: String, source: Uri): Boolean {
        return try {
            val target = File(mirrorRoot, path)
            target.parentFile?.mkdirs()
            val stream = resolver.openInputStream(source) ?: return false
            stream.use { input -> FileOutputStream(target).use { input.copyTo(it) } }
            mirrors[path] = target
            true
        } catch (failure: Exception) {
            // A media file that will not copy is not a reason to fail the whole
            // preview: the page still loads, that one asset 404s, and the agent
            // sees the 404 in the console rather than an unexplained dead start.
            false
        }
    }

    private companion object {
        /** Directories that are never part of a page and are frequently enormous. */
        val SKIP_DIRS = setOf(
            "node_modules", ".git", "build", ".gradle", ".idea", "dist", ".next", "__pycache__"
        )

        /**
         * Extensions copied to app storage instead of streamed from SAF.
         *
         * Audio and video need `Content-Length` and `Range` to seek, and wasm
         * needs a length for streaming compilation. A SAF-backed response gives
         * neither.
         */
        val MIRROR_EXT = setOf("mp3", "ogg", "wav", "m4a", "aac", "mp4", "webm", "mov", "wasm")

        /** Deep enough for any real web project, shallow enough to stop a symlink loop. */
        const val MAX_DEPTH = 12

        /** Ceiling on one index, so a folder picked by mistake cannot hang the walk. */
        const val MAX_FILES = 4_000
    }
}
