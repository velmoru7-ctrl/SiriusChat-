package com.sirius.chat.ai.provider

import okhttp3.Interceptor
import okhttp3.HttpUrl
import okhttp3.HttpUrl.Companion.toHttpUrlOrNull
import java.io.IOException

object LanHttpPolicy {
    @Volatile var enabled: Boolean = false

    fun isPrivateIpv4(host: String): Boolean {
        val parts = host.split('.')
        if (parts.size != 4 || parts.any { it.isEmpty() || it.any { c -> !c.isDigit() } || (it.length > 1 && it.startsWith('0')) }) return false
        val bytes = parts.map { it.toIntOrNull() ?: return false }
        if (bytes.any { it !in 0..255 }) return false
        return bytes[0] == 10 || (bytes[0] == 172 && bytes[1] in 16..31) ||
            (bytes[0] == 192 && bytes[1] == 168)
    }

    fun permits(url: HttpUrl): Boolean = url.isHttps ||
        url.host in setOf("localhost", "127.0.0.1", "::1", "10.0.2.2") ||
        (enabled && isPrivateIpv4(url.host))

    fun permits(address: String): Boolean = address.toHttpUrlOrNull()?.let(::permits) == true

    val interceptor = Interceptor { chain ->
        if (!permits(chain.request().url)) throw IOException(
            "Cleartext HTTP is blocked. Use HTTPS, or explicitly enable trusted private-LAN HTTP in Settings."
        )
        chain.proceed(chain.request())
    }
}
