package com.sirius.chat.core.util;

/** Appends only a final utterance to the LATEST draft; never rewrites a start snapshot. */
public final class DictationText {
    public static final int MAX_UTTERANCE_CHARS = 8_000;
    public static final int MAX_DRAFT_CHARS = 200_000;
    private DictationText() {}

    public static String append(String current, String recognised) {
        if (current == null || recognised == null) throw new IllegalArgumentException("Missing dictation text");
        if (recognised.length() > MAX_UTTERANCE_CHARS) throw new IllegalArgumentException("Utterance too long");
        String words = trimSpace(recognised);
        if (words.isEmpty()) return current;
        boolean separate = !current.isEmpty()
                && !space(current.codePointBefore(current.length()))
                && ".,!?;:)]}»".indexOf(words.codePointAt(0)) < 0;
        long required = (long) current.length() + words.length() + (separate ? 1 : 0);
        if (required > MAX_DRAFT_CHARS) throw new IllegalArgumentException("Draft too long");
        return current + (separate ? " " : "") + words;
    }
    /** Preview is bounded and cannot split a UTF-16 surrogate pair. */
    public static String preview(String text) {
        return text == null ? "" : BoundedIo.prefix(text, 512);
    }
    /** Aggregate RMS, not invented frequency bins. Non-finite callbacks are inert. */
    public static float level(float rmsDb) {
        if (Float.isNaN(rmsDb) || Float.isInfinite(rmsDb)) return 0f;
        return Math.max(0f, Math.min(1f, (rmsDb + 2f) / 12f));
    }
    private static boolean space(int point) {
        return Character.isWhitespace(point) || Character.isSpaceChar(point);
    }
    private static String trimSpace(String text) {
        int a=0,b=text.length();
        while(a<b && space(text.codePointAt(a))) a+=Character.charCount(text.codePointAt(a));
        while(b>a && space(text.codePointBefore(b))) b-=Character.charCount(text.codePointBefore(b));
        return text.substring(a,b);
    }
}
