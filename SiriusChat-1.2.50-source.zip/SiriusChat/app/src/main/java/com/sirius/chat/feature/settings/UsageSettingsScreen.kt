package com.sirius.chat.feature.settings

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.ai.pricing.ModelPricing
import com.sirius.chat.ai.pricing.PriceRule
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.ui.LocalAppContainer
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.feature.chat.components.CostBreakdown
import com.sirius.chat.feature.chat.components.summarizeUsage
import com.sirius.chat.feature.chat.components.usageAmountLabel
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Date

@Composable
fun UsageSettingsScreen(onBack: () -> Unit) {
    val container = LocalAppContainer.current
    val viewModel: SettingsViewModel = siriusViewModel { SettingsViewModel(it) }
    val ui by viewModel.state.collectAsStateWithLifecycle()
    val ledger by container.usageLedger.state.collectAsStateWithLifecycle()
    val sessions by remember(container) { container.chatRepository.observeSessions() }.collectAsStateWithLifecycle(initialValue = emptyList())
    val scope = rememberCoroutineScope()
    var budget by rememberSaveable { mutableStateOf("") }
    var budgetDirty by rememberSaveable { mutableStateOf(false) }
    var budgetBusy by remember { mutableStateOf(false) }
    LaunchedEffect(ui.settings.taskBudgetUsd) {
        if (!budgetDirty) budget = ui.settings.taskBudgetUsd.takeIf { it > 0.0 }?.toString().orEmpty()
    }
    var providerId by rememberSaveable { mutableStateOf("") }
    var model by rememberSaveable { mutableStateOf("") }
    var input by rememberSaveable { mutableStateOf("") }
    var output by rememberSaveable { mutableStateOf("") }
    var image by rememberSaveable { mutableStateOf("") }
    var priceDirty by rememberSaveable(providerId, model) { mutableStateOf(false) }
    var menu by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var historyLimit by remember { mutableStateOf(20) }
    val savedLabel = stringResource(R.string.usage_saved)
    val saveFailedLabel = stringResource(R.string.usage_save_failed)
    LaunchedEffect(ui.providers, ui.settings.activeProviderId, ui.settings.activeModel) {
        if (providerId.isEmpty()) providerId = ui.settings.activeProviderId.takeIf { id -> ui.providers.any { it.id == id } }
            ?: ui.providers.firstOrNull()?.id.orEmpty()
        if (model.isEmpty()) model = ui.settings.activeModel
    }
    val savedRule = ledger.prices.firstOrNull { it.providerId == providerId && it.model == model }
    LaunchedEffect(providerId, model, savedRule) {
        // Late disk data refreshes untouched fields, never a form being edited.
        if (!priceDirty) {
            input = savedRule?.inputPerMillion?.toString().orEmpty()
            output = savedRule?.outputPerMillion?.toString().orEmpty()
            image = savedRule?.imageUsd?.toString().orEmpty()
        }
    }
    Column(Modifier.fillMaxSize()) {
        SiriusTopBar(title = stringResource(R.string.usage_title), onBack = onBack)
        Column(Modifier.fillMaxWidth().verticalScroll(rememberScrollState()).navigationBarsPadding().imePadding().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)) {
            GlassCard {
                Text(stringResource(R.string.usage_budget), style = MaterialTheme.typography.titleLarge)
                Text(stringResource(R.string.usage_budget_hint), style = MaterialTheme.typography.bodyMedium)
                OutlinedTextField(value = budget, onValueChange = { budget = it; budgetDirty = true; message = null }, enabled = !budgetBusy, label = { Text(stringResource(R.string.usage_budget_field)) },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true, modifier = Modifier.fillMaxWidth(),
                    isError = budget.isNotBlank() && money(budget) == null)
                Button(onClick = {
                    val value = money(budget) ?: 0.0
                    budgetBusy = true
                    scope.launch {
                        try {
                            container.settingsRepository.update { it.copy(taskBudgetUsd = value) }
                            budgetDirty = false
                            message = savedLabel
                        } catch (cancel: CancellationException) { throw cancel }
                        catch (_: Exception) { message = saveFailedLabel }
                        finally { budgetBusy = false }
                    }
                }, enabled = !budgetBusy && (budget.isBlank() || money(budget) != null), modifier = Modifier.heightIn(min = 48.dp)) {
                    Text(stringResource(R.string.action_save))
                }
                Text(stringResource(R.string.usage_budget_warning), style = MaterialTheme.typography.bodySmall)
            }
            GlassCard {
                Text(stringResource(R.string.usage_prices), style = MaterialTheme.typography.titleLarge)
                Text(stringResource(R.string.usage_prices_hint), style = MaterialTheme.typography.bodyMedium)
                Box {
                    TextButton(onClick = { menu = true }, enabled = !busy, modifier = Modifier.heightIn(min = 48.dp)) {
                        Text(ui.providers.firstOrNull { it.id == providerId }?.label ?: stringResource(R.string.providers_title))
                    }
                    DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                        ui.providers.forEach { provider -> DropdownMenuItem(text = { Text(provider.label) }, onClick = {
                            providerId = provider.id; menu = false; message = null
                        }) }
                    }
                }
                OutlinedTextField(value = model, onValueChange = { model = it.trim(); message = null }, enabled = !busy, label = { Text(stringResource(R.string.usage_model)) },
                    singleLine = true, modifier = Modifier.fillMaxWidth())
                MoneyField(input, { input = it; priceDirty = true; message = null }, stringResource(R.string.usage_input_price), enabled = !busy)
                MoneyField(output, { output = it; priceDirty = true; message = null }, stringResource(R.string.usage_output_price), enabled = !busy)
                MoneyField(image, { image = it; priceDirty = true; message = null }, stringResource(R.string.usage_image_price), enabled = !busy)
                val valid = providerId.isNotBlank() && model.isNotBlank() && money(input) != null && money(output) != null &&
                    (image.isBlank() || money(image) != null)
                Button(onClick = {
                    val rule = PriceRule(providerId, model, money(input) ?: 0.0, money(output) ?: 0.0, money(image))
                    busy = true
                    scope.launch {
                        try { container.usageLedger.savePrice(rule); priceDirty = false; message = savedLabel }
                        catch (cancel: CancellationException) { throw cancel }
                        catch (_: Exception) { message = saveFailedLabel }
                        finally { busy = false }
                    }
                }, enabled = valid && !busy, modifier = Modifier.heightIn(min = 48.dp)) { Text(stringResource(R.string.action_save)) }
                Text(stringResource(R.string.usage_reference_note), style = MaterialTheme.typography.bodySmall)
            }
            message?.let { Text(it, style = MaterialTheme.typography.bodyMedium) }
            Text(stringResource(R.string.usage_history), style = MaterialTheme.typography.titleLarge)
            Text(stringResource(R.string.usage_history_hint), style = MaterialTheme.typography.bodySmall)
            if (ledger.tasks.isEmpty()) Text(stringResource(R.string.usage_empty))
            ledger.tasks.takeLast(historyLimit).asReversed().forEach { task ->
                val rows = ledger.forTask(task.id)
                val summary = summarizeUsage(rows)
                val unknown = summary.unknown
                GlassCard {
                    Text(sessions.firstOrNull { it.id == task.sessionId }?.title ?: stringResource(R.string.usage_service_task),
                        style = MaterialTheme.typography.titleMedium)
                    Text(DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT).format(Date(task.createdAt)),
                        style = MaterialTheme.typography.bodySmall)
                    Text(usageAmountLabel(summary), style = MaterialTheme.typography.titleLarge)
                    if (unknown > 0) Text(stringResource(R.string.usage_unknown_count, unknown))
                    if (rows.any { it.status == "pending" }) Text(stringResource(R.string.usage_pending, rows.count { it.status == "pending" }))
                    if (task.budgetUsd > 0.0) Text(stringResource(R.string.usage_budget_amount, ModelPricing.format(task.budgetUsd)))
                    CostBreakdown(rows)
                    Text(stringResource(R.string.usage_token_totals, rows.sumOf { it.inputTokens }.toString(), rows.sumOf { it.outputTokens }.toString()),
                        style = MaterialTheme.typography.bodySmall)
                    if (rows.any { it.estimatedTokens }) Text(stringResource(R.string.usage_estimated_tokens), style = MaterialTheme.typography.bodySmall)
                    if (task.stoppedReason.isNotBlank()) Text(task.stoppedReason, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.error)
                }
            }
            if (ledger.tasks.size > historyLimit) TextButton(onClick = { historyLimit += 20 }) { Text(stringResource(R.string.usage_more)) }
        }
    }
}

@Composable
private fun MoneyField(value: String, change: (String) -> Unit, label: String, enabled: Boolean = true) {
    OutlinedTextField(value = value, onValueChange = change, enabled = enabled, label = { Text(label) },
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true,
        modifier = Modifier.fillMaxWidth(), isError = value.isNotBlank() && money(value) == null)
}

private fun money(value: String): Double? = value.trim().replace(',', '.').toDoubleOrNull()?.takeIf { it.isFinite() && it >= 0.0 }
