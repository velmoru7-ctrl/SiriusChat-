package com.sirius.chat.feature.preview

import android.view.ViewGroup
import android.widget.FrameLayout
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.BugReport
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material.icons.rounded.DeleteOutline
import androidx.compose.material.icons.rounded.Difference
import androidx.compose.material.icons.rounded.Fullscreen
import androidx.compose.material.icons.rounded.FullscreenExit
import androidx.compose.material.icons.rounded.PhotoCamera
import androidx.compose.material.icons.rounded.PlayArrow
import androidx.compose.material.icons.rounded.Refresh
import androidx.compose.material.icons.rounded.Stop
import androidx.compose.material.icons.rounded.Terminal
import androidx.compose.material.icons.rounded.WebAsset
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.sirius.chat.R
import com.sirius.chat.core.designsystem.SiriusMotion
import com.sirius.chat.core.designsystem.SiriusRadius
import com.sirius.chat.core.designsystem.SiriusSpacing
import com.sirius.chat.core.designsystem.SiriusTheme
import com.sirius.chat.core.designsystem.components.EmptyState
import com.sirius.chat.core.designsystem.components.GlassCard
import com.sirius.chat.core.designsystem.components.GlassIconButton
import com.sirius.chat.core.designsystem.components.MessageToast
import com.sirius.chat.core.designsystem.components.SectionHeader
import com.sirius.chat.core.designsystem.components.SiriusChip
import com.sirius.chat.core.designsystem.components.SiriusGhostButton
import com.sirius.chat.core.designsystem.components.SiriusPrimaryButton
import com.sirius.chat.core.designsystem.components.SiriusTextField
import com.sirius.chat.core.designsystem.components.SiriusTopBar
import com.sirius.chat.core.designsystem.components.ToastTone
import com.sirius.chat.core.designsystem.components.VSpace
import com.sirius.chat.core.designsystem.siriusTween
import com.sirius.chat.core.ui.siriusViewModel
import com.sirius.chat.domain.model.PreviewState
import com.sirius.chat.domain.model.PreviewStatus
import com.sirius.chat.domain.model.ReviewEntry
import com.sirius.chat.domain.model.ReviewKind
import kotlinx.coroutines.delay

/**
 * The live preview, on a route of its own.
 *
 * A panel inside the chat was the other option and it is the wrong one here: a
 * game is looked at, not glanced at, and sharing the screen with a message list
 * leaves both too small to use. On its own route it gets the whole viewport and
 * the chat keeps its scroll position.
 */
@Composable
fun PreviewScreen(
    onBack: () -> Unit,
    contentPadding: PaddingValues
) {
    val viewModel: PreviewViewModel = siriusViewModel { PreviewViewModel(it) }
    val state by viewModel.state.collectAsStateWithLifecycle()
    val colors = SiriusTheme.colors
    val preview = state.preview

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(colors.background)
            .padding(contentPadding)
    ) {
        if (!state.fullscreen) {
            SiriusTopBar(
                title = stringResource(R.string.preview_title),
                subtitle = preview.title.takeIf { it.isNotBlank() } ?: state.project?.name,
                onBack = onBack,
                actions = {
                    if (preview.live) {
                        GlassIconButton(
                            icon = Icons.Rounded.Refresh,
                            contentDescription = stringResource(R.string.preview_restart),
                            onClick = viewModel::reload,
                            busy = preview.busy
                        )
                        GlassIconButton(
                            icon = Icons.Rounded.Stop,
                            contentDescription = stringResource(R.string.preview_stop),
                            onClick = viewModel::stop
                        )
                        GlassIconButton(
                            icon = Icons.Rounded.PhotoCamera,
                            contentDescription = stringResource(R.string.preview_capture),
                            onClick = viewModel::capture,
                            busy = state.capturing
                        )
                    }
                    if (state.hasStaged) {
                        GlassIconButton(
                            icon = Icons.Rounded.Difference,
                            contentDescription = stringResource(R.string.preview_review),
                            onClick = viewModel::openReview,
                            highlighted = true
                        )
                    }
                    GlassIconButton(
                        icon = Icons.Rounded.Fullscreen,
                        contentDescription = stringResource(R.string.preview_fullscreen),
                        onClick = { viewModel.setFullscreen(true) },
                        enabled = preview.live
                    )
                }
            )
        }

        when {
            !state.hasWorkspace -> EmptyState(
                icon = Icons.Rounded.WebAsset,
                title = stringResource(R.string.preview_no_project_title),
                message = stringResource(R.string.preview_no_project_body),
                modifier = Modifier.fillMaxSize()
            )

            preview.status == PreviewStatus.Idle -> StartPanel(
                entry = state.entry,
                onEntryChange = viewModel::setEntry,
                onStart = viewModel::start
            )

            else -> Column(Modifier.fillMaxSize()) {
                if (!state.fullscreen) {
                    StatusStrip(
                        state = state,
                        onOpenConsole = viewModel::toggleLog,
                        onOpenReview = viewModel::openReview
                    )
                }
                PreviewSurface(
                    viewModel = viewModel,
                    busy = preview.busy,
                    fullscreen = state.fullscreen,
                    modifier = Modifier.weight(1f)
                )
                AnimatedVisibility(visible = state.reviewOpen && !state.fullscreen) {
                    SandboxReviewPanel(state = state, viewModel = viewModel)
                }
                AnimatedVisibility(visible = state.logOpen && !state.fullscreen) {
                    ConsolePanel(state = state, viewModel = viewModel)
                }
            }
        }

        // Lives in a popup window, so it floats over the full-size Column above
        // instead of taking height away from the page.
        MessageToast(
            message = state.message,
            tone = if (state.messageIsError) ToastTone.Error else ToastTone.Success,
            bottomPadding = contentPadding.calculateBottomPadding() + SiriusSpacing.sm
        )
        LaunchedEffect(state.message) {
            if (state.message != null) {
                delay(2600)
                viewModel.dismissMessage()
            }
        }
    }
}

/**
 * One decision for the whole run.
 *
 * Byte counts rather than inline diffs, on purpose. Forty expandable diffs is a
 * review nobody reads, and the entire reason the run collapses into a single
 * approval is that this one gets read. Anything genuinely surprising says so on
 * its own row: a build file, or a file that also changed on disk while the agent
 * was working.
 */
@Composable
private fun SandboxReviewPanel(
    state: PreviewUiState,
    viewModel: PreviewViewModel
) {
    val colors = SiriusTheme.colors
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(SiriusSpacing.md)
    ) {
        GlassCard {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                SectionHeader(
                    title = stringResource(R.string.preview_review_title),
                    subtitle = stringResource(R.string.preview_review_body),
                    modifier = Modifier.weight(1f)
                )
                GlassIconButton(
                    icon = Icons.Rounded.Close,
                    contentDescription = stringResource(R.string.preview_console_close),
                    onClick = viewModel::closeReview
                )
            }
            VSpace(SiriusSpacing.sm)

            if (state.review.isEmpty()) {
                Text(
                    text = stringResource(R.string.preview_review_empty),
                    style = MaterialTheme.typography.bodySmall,
                    color = colors.textTertiary
                )
                return@GlassCard
            }

            LazyColumn(
                modifier = Modifier.heightIn(max = 200.dp),
                verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
            ) {
                items(state.review) { entry -> ReviewRow(entry = entry) }
            }
            VSpace(SiriusSpacing.md)
            SiriusPrimaryButton(
                text = stringResource(R.string.preview_review_apply),
                onClick = viewModel::applyStaged,
                icon = Icons.Rounded.Check,
                loading = state.committing,
                modifier = Modifier.fillMaxWidth()
            )
            VSpace(SiriusSpacing.xs)
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs)
            ) {
                // "Keep in preview" matters more than it looks: without it the
                // only moves are writing to the project and throwing the run
                // away, and someone who wants to play the game once more before
                // deciding has neither.
                SiriusGhostButton(
                    text = stringResource(R.string.preview_review_keep),
                    onClick = viewModel::keepStaged,
                    modifier = Modifier.weight(1f)
                )
                SiriusGhostButton(
                    text = stringResource(R.string.preview_review_discard),
                    onClick = viewModel::discardStaged,
                    icon = Icons.Rounded.DeleteOutline,
                    tint = colors.error,
                    modifier = Modifier.weight(1f)
                )
            }
        }
    }
}

/** One file, and the one thing worth knowing about it. */
@Composable
private fun ReviewRow(entry: ReviewEntry) {
    val colors = SiriusTheme.colors
    val label = when (entry.kind) {
        ReviewKind.Added -> R.string.preview_review_added
        ReviewKind.Deleted -> R.string.preview_review_deleted
        ReviewKind.Conflict -> R.string.preview_review_conflict
        else -> R.string.preview_review_modified
    }
    val tone = when (entry.kind) {
        ReviewKind.Added -> colors.success
        ReviewKind.Deleted -> colors.error
        ReviewKind.Conflict -> colors.warning
        else -> colors.textSecondary
    }

    Column(Modifier.fillMaxWidth()) {
        Text(
            text = entry.path,
            style = MaterialTheme.typography.bodyMedium,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis
        )
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = stringResource(label),
                style = MaterialTheme.typography.labelSmall,
                color = tone,
                modifier = Modifier.padding(end = SiriusSpacing.xs)
            )
            Text(
                text = stringResource(
                    R.string.preview_bytes,
                    entry.originalBytes,
                    entry.newBytes
                ),
                style = MaterialTheme.typography.labelSmall,
                color = colors.textTertiary
            )
            if (entry.sensitive) {
                Text(
                    text = stringResource(R.string.preview_review_sensitive),
                    style = MaterialTheme.typography.labelSmall,
                    color = colors.warning,
                    modifier = Modifier.padding(start = SiriusSpacing.xs)
                )
            }
        }
    }
}

/** The pre-run state: pick an entry file and press go. */
@Composable
private fun StartPanel(
    entry: String,
    onEntryChange: (String) -> Unit,
    onStart: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(SiriusSpacing.md),
        verticalArrangement = Arrangement.Center
    ) {
        GlassCard {
            SectionHeader(
                title = stringResource(R.string.preview_entry_label),
                subtitle = stringResource(R.string.preview_entry_hint)
            )
            VSpace(SiriusSpacing.sm)
            SiriusTextField(
                value = entry,
                onValueChange = onEntryChange,
                placeholder = "index.html",
                singleLine = true
            )
            VSpace(SiriusSpacing.md)
            SiriusPrimaryButton(
                text = stringResource(R.string.preview_run),
                onClick = onStart,
                icon = Icons.Rounded.PlayArrow,
                modifier = Modifier.fillMaxWidth()
            )
        }
    }
}

/**
 * The one-line answer to "is it working".
 *
 * The frame count earns its place here. A page that loaded and then died looks
 * identical to a working one in every other signal, and a number that is not
 * climbing is the cheapest way to see that.
 */
@Composable
private fun StatusStrip(
    state: PreviewUiState,
    onOpenConsole: () -> Unit,
    onOpenReview: () -> Unit
) {
    val colors = SiriusTheme.colors
    val preview = state.preview
    val tone = when (preview.status) {
        PreviewStatus.Running -> colors.success
        PreviewStatus.Crashed -> colors.error
        PreviewStatus.Unavailable -> colors.error
        else -> colors.textSecondary
    }
    val label = when (preview.status) {
        PreviewStatus.Idle -> R.string.preview_status_idle
        PreviewStatus.Indexing -> R.string.preview_status_indexing
        PreviewStatus.Loading -> R.string.preview_status_loading
        PreviewStatus.Running -> R.string.preview_status_running
        PreviewStatus.Crashed -> R.string.preview_status_crashed
        PreviewStatus.Unavailable -> R.string.preview_status_unavailable
    }

    Column(Modifier.padding(horizontal = SiriusSpacing.md)) {
        Row(
            // Scrollable because the chips are now a variable set: staged files,
            // a seed and a frame count can all be present at once, and on a
            // narrow phone the row that reports errors must not be the one that
            // gets clipped off the edge.
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(SiriusSpacing.xs),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SiriusChip(text = stringResource(label), color = tone)
            if (preview.live) {
                SiriusChip(
                    text = stringResource(
                        if (state.throttled) R.string.preview_heartbeat else R.string.preview_frames,
                        preview.frames
                    )
                )
            }
            if (preview.staged > 0) {
                SiriusChip(
                    text = stringResource(R.string.preview_staged, preview.staged),
                    icon = Icons.Rounded.Difference,
                    color = colors.warning,
                    onClick = onOpenReview
                )
            }
            if (preview.seeded) {
                SiriusChip(text = stringResource(R.string.preview_seeded))
            }
            if (preview.shotsTaken > 0) {
                SiriusChip(
                    text = stringResource(
                        R.string.preview_shots_sent,
                        preview.shotsTaken,
                        PreviewState.SHOT_BUDGET
                    )
                )
            }
            if (preview.errorCount > 0) {
                SiriusChip(
                    text = stringResource(R.string.preview_errors, preview.errorCount),
                    icon = Icons.Rounded.BugReport,
                    color = colors.error,
                    onClick = onOpenConsole
                )
            } else if (preview.live) {
                SiriusChip(
                    text = stringResource(R.string.preview_console),
                    icon = Icons.Rounded.Terminal,
                    onClick = onOpenConsole
                )
            }
        }
        if (preview.detail.isNotBlank()) {
            VSpace(SiriusSpacing.xs)
            Text(
                text = preview.detail,
                style = MaterialTheme.typography.bodySmall,
                color = colors.error
            )
        }
        VSpace(SiriusSpacing.xs)
    }
}

/**
 * Borrows the controller's WebView rather than making one.
 *
 * The page has to outlive this screen: the agent inspects it from the chat, and
 * a view rebuilt on every navigation would reload the game and throw away the
 * state the next tool call was about to read.
 */
@Composable
private fun PreviewSurface(
    viewModel: PreviewViewModel,
    busy: Boolean,
    fullscreen: Boolean,
    modifier: Modifier = Modifier
) {
    val shape = if (fullscreen) RoundedCornerShape(0.dp) else RoundedCornerShape(SiriusRadius.md)
    val alpha by animateFloatAsState(
        targetValue = if (busy) 0.45f else 1f,
        animationSpec = siriusTween(SiriusMotion.Base, SiriusMotion.Emphasized),
        label = "previewFade"
    )

    Box(
        modifier = modifier
            .fillMaxWidth()
            .padding(
                horizontal = if (fullscreen) 0.dp else SiriusSpacing.md,
                vertical = if (fullscreen) 0.dp else 0.dp
            )
            .clip(shape)
            .background(Color.Black)
            .onSizeChanged { viewModel.onSurfaceSize(it.width, it.height) }
    ) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { context ->
                FrameLayout(context).apply {
                    setBackgroundColor(android.graphics.Color.BLACK)
                }
            },
            update = { host ->
                val view = viewModel.controller.obtainView()
                val parent = view.parent as? ViewGroup
                if (parent !== host) {
                    parent?.removeView(view)
                    host.addView(
                        view,
                        FrameLayout.LayoutParams(
                            ViewGroup.LayoutParams.MATCH_PARENT,
                            ViewGroup.LayoutParams.MATCH_PARENT
                        )
                    )
                }
                view.alpha = alpha
            },
            // Detached, never destroyed. The controller owns its life.
            onRelease = { host -> host.removeAllViews() }
        )

        if (fullscreen) {
            GlassIconButton(
                icon = Icons.Rounded.FullscreenExit,
                contentDescription = stringResource(R.string.preview_fullscreen_exit),
                onClick = { viewModel.setFullscreen(false) },
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(SiriusSpacing.sm)
            )
        }
    }
}

/** Errors first, then the log. Skimming a stack trace is how a crash gets missed. */
@Composable
private fun ConsolePanel(
    state: PreviewUiState,
    viewModel: PreviewViewModel
) {
    val colors = SiriusTheme.colors
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(SiriusSpacing.md)
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically
        ) {
            SectionHeader(
                title = stringResource(R.string.preview_console),
                modifier = Modifier.weight(1f)
            )
            SiriusGhostButton(
                text = stringResource(R.string.preview_console_refresh),
                onClick = viewModel::refreshConsole,
                icon = Icons.Rounded.Refresh
            )
            GlassIconButton(
                icon = Icons.Rounded.Close,
                contentDescription = stringResource(R.string.preview_console_close),
                onClick = viewModel::toggleLog
            )
        }
        VSpace(SiriusSpacing.xs)

        if (state.errors.isEmpty() && state.logs.isEmpty()) {
            Text(
                text = stringResource(R.string.preview_console_empty),
                style = MaterialTheme.typography.bodySmall,
                color = colors.textTertiary
            )
            return@Column
        }

        LazyColumn(
            modifier = Modifier.heightIn(max = 260.dp),
            verticalArrangement = Arrangement.spacedBy(SiriusSpacing.xxs)
        ) {
            items(state.errors) { crash ->
                GlassCard(tint = colors.error.copy(alpha = 0.10f), contentPadding = SiriusSpacing.sm) {
                    Text(
                        text = crash.message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = colors.error
                    )
                    if (crash.source.isNotBlank()) {
                        Text(
                            text = crash.source.substringAfterLast('/') + ":" + crash.line,
                            style = MaterialTheme.typography.labelSmall,
                            color = colors.textTertiary
                        )
                    }
                }
            }
            items(state.logs) { entry ->
                Row(modifier = Modifier.fillMaxWidth()) {
                    Text(
                        text = entry.level.uppercase(),
                        style = MaterialTheme.typography.labelSmall,
                        color = when (entry.level) {
                            "error" -> colors.error
                            "warn" -> colors.warning
                            else -> colors.textTertiary
                        },
                        modifier = Modifier.padding(end = SiriusSpacing.xs)
                    )
                    Text(
                        text = entry.message,
                        style = MaterialTheme.typography.bodySmall,
                        color = colors.textSecondary,
                        maxLines = 4,
                        overflow = TextOverflow.Ellipsis
                    )
                }
            }
        }
    }
}
