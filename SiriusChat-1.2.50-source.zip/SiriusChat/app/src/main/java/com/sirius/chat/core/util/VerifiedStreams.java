package com.sirius.chat.core.util;

import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Arrays;

/** Binary-safe, close-before-verify transfer. Deletion of the source is never this helper's job. */
public final class VerifiedStreams {
    private VerifiedStreams() {}
    @FunctionalInterface public interface Input { InputStream open() throws IOException; }
    @FunctionalInterface public interface Output { OutputStream open() throws IOException; }
    @FunctionalInterface public interface Check { void check(); }

    public static long copy(Input source, Output destination, Input verification, Check cancellation) throws IOException {
        MessageDigest expected = sha256();
        long count = 0;
        try (InputStream from = source.open()) {
            if (from == null) throw new IOException("Cannot open source.");
            try (OutputStream to = destination.open()) {
                if (to == null) throw new IOException("Cannot open destination.");
                byte[] buffer = new byte[64 * 1024];
                for (;;) {
                    cancellation.check();
                    int length = from.read(buffer);
                    if (length < 0) break;
                    expected.update(buffer, 0, length);
                    to.write(buffer, 0, length);
                    count += length;
                }
                to.flush();
            }
        }
        MessageDigest actual = sha256();
        try (InputStream verify = verification.open()) {
            if (verify == null) throw new IOException("Cannot verify destination.");
            byte[] buffer = new byte[64 * 1024];
            for (;;) {
                cancellation.check();
                int length = verify.read(buffer);
                if (length < 0) break;
                actual.update(buffer, 0, length);
            }
        }
        if (!Arrays.equals(expected.digest(), actual.digest())) throw new IOException("Copy checksum mismatch.");
        return count;
    }

    private static MessageDigest sha256() {
        try { return MessageDigest.getInstance("SHA-256"); }
        catch (NoSuchAlgorithmException impossible) { throw new IllegalStateException(impossible); }
    }
}
