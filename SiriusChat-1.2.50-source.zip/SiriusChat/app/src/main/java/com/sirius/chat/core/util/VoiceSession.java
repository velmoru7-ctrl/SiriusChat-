package com.sirius.chat.core.util;

/** Main-thread ticket gate shared by consent, permissions and recognizer callbacks. */
public final class VoiceSession {
    private static final java.util.concurrent.atomic.AtomicLong NEXT = new java.util.concurrent.atomic.AtomicLong();
    private long epoch;
    private boolean active;
    private boolean closed;

    /** Zero means rejected: a double tap never starts a second recording. */
    public long begin() {
        if (closed || active) return 0L;
        advance();
        active = true;
        return epoch;
    }
    public boolean isCurrent(long ticket) {
        return !closed && active && ticket != 0L && ticket == epoch;
    }
    /** Exactly one final result or error may consume the active ticket. */
    public boolean finish(long ticket) {
        if (!isCurrent(ticket)) return false;
        active = false;
        return true;
    }
    public void cancel() { active = false; advance(); }
    public void close() { cancel(); closed = true; }
    public boolean isActive() { return active && !closed; }
    public boolean isClosed() { return closed; }
    private void advance() { do { epoch = NEXT.incrementAndGet(); } while (epoch == 0L); }
}
