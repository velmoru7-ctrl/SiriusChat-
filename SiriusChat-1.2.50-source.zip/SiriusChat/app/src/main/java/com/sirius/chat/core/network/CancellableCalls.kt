package com.sirius.chat.core.network

import kotlinx.coroutines.CompletableJob
import kotlinx.coroutines.Job
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.job
import okhttp3.Call
import okhttp3.Response
import java.io.IOException

/**
 * A plain child Job completes as soon as its parent is cancelled. In contrast,
 * the parent's ordinary completion hook may wait for the very blocking read
 * it is supposed to cancel. Complete this relay in finally on every path.
 */
fun Call.cancellationRelay(parent: Job): CompletableJob = Job(parent).also { relay ->
    relay.invokeOnCompletion { cause -> if (cause != null) this.cancel() }
}

/** Keep cancellation attached until the response body has also been consumed. */
suspend inline fun <T> Call.useCancellableResponse(block: (Response) -> T): T {
    val relay = cancellationRelay(currentCoroutineContext().job)
    try {
        currentCoroutineContext().ensureActive()
        return execute().use { block(it) }
    } catch (error: IOException) {
        currentCoroutineContext().ensureActive()
        throw error
    } finally {
        relay.complete()
    }
}
