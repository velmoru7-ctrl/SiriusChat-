package com.sirius.chat.ai.agent.tools

import com.sirius.chat.ai.agent.AgentContext
import com.sirius.chat.ai.agent.AgentTool
import com.sirius.chat.ai.agent.AgentToolResult
import com.sirius.chat.ai.agent.int
import com.sirius.chat.ai.agent.stringOrEmpty
import com.sirius.chat.ai.agent.ToolImage
import com.sirius.chat.data.preview.PreviewController
import com.sirius.chat.data.preview.PreviewCapture
import com.sirius.chat.domain.model.ConsoleEntry
import com.sirius.chat.domain.model.PreviewCrash
import com.sirius.chat.domain.model.PreviewFailure
import com.sirius.chat.domain.model.PreviewState
import kotlinx.serialization.json.JsonObject

/**
 * Runs the project the model just wrote, and reports what happened.
 *
 * ### Why every name carries the prefix
 * `wait` and `tap` are words a model already uses for other things, and a
 * registry that contains a bare `wait` invites it in contexts where there is no
 * preview at all. `preview_wait` reads as one subsystem, and a model that has
 * called `preview_start` recognises the rest of the family without being told.
 */
class PreviewStartTool(private val preview: PreviewController) : AgentTool {

    override val name = "preview_start"
    override val description =
        "Serve the project folder over a real https origin and load its entry page in a " +
            "preview WebView. Call this before any other preview tool, and again after adding " +
            "or deleting files. Pass a seed when you intend to compare two runs: it makes " +
            "Math.random and frame timing repeat exactly, so a difference between iterations " +
            "means a change in your code and not luck. Returns the load result and any error " +
            "the page threw on start."
    override val usage =
        """{"entry": "index.html", "width": 720, "height": 1280, "seed": 7}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        val entry = args.stringOrEmpty("entry").ifBlank { PreviewState.DEFAULT_ENTRY }
        val width = args.int("width", DEFAULT_WIDTH).coerceIn(MIN_SIDE, MAX_WIDTH)
        val height = args.int("height", DEFAULT_HEIGHT).coerceIn(MIN_SIDE, MAX_HEIGHT)

        val seed = args.int("seed", 0).coerceIn(0, MAX_SEED)

        val state = preview.start(context.treeUri, entry, width, height, seed, context.sessionId)

        // Each failure gets a stable code the model can branch on. Prose alone
        // makes every one of these look like a bug in the page, and the model
        // then edits the game instead of asking for the folder back.
        state.failure?.let { failure ->
            val code = when (failure) {
                PreviewFailure.NoProject -> "no_project"
                PreviewFailure.AccessRevoked -> "project_access_revoked"
                PreviewFailure.EntryMissing -> "entry_missing"
                PreviewFailure.LoadTimeout -> "load_timeout"
                PreviewFailure.NoSurface -> "no_surface"
                PreviewFailure.Unreadable -> "project_unreadable"
            }
            val hint = when (failure) {
                PreviewFailure.AccessRevoked ->
                    "\nDo not edit the project. Ask the user to re-select the project folder."

                PreviewFailure.NoProject ->
                    "\nAsk the user to attach a project folder to this chat."

                PreviewFailure.EntryMissing ->
                    "\nWrite the entry file, then call preview_start again."

                else -> ""
            }
            return AgentToolResult("$code: ${state.detail}$hint", success = false)
        }

        val report = preview.report(0L, "all")
        val head = buildString {
            append("Preview running at ").append(state.url).append('\n')
            append("Indexed ").append(state.indexedFiles).append(" files")
            if (state.mirroredFiles > 0) {
                append(", ").append(state.mirroredFiles).append(" media cached")
            }
            append('\n')
            if (state.title.isNotBlank()) append("Title: ").append(state.title).append('\n')
            if (state.seeded) {
                append("Seeded run: Math.random and frame timing are deterministic, so do ")
                append("not treat differences between runs as randomness to remove.\n")
            }
            append("Frames drawn: ").append(state.frames)
            if (report.throttled) {
                append(" (heartbeat only -- the preview screen is not open, so this is not a ")
                append("frame rate)")
            }
        }
        return AgentToolResult(head + "\n\n" + renderConsole(report.logs, report.errors))
    }

    private companion object {
        const val DEFAULT_WIDTH = 720
        const val DEFAULT_HEIGHT = 1280
        const val MIN_SIDE = 240
        const val MAX_WIDTH = 2048
        const val MAX_HEIGHT = 4096
        const val MAX_SEED = 1_000_000
    }
}

/**
 * Lets the page run for a moment.
 *
 * Frames are the honest unit for anything animated: "three frames" means the
 * same thing on a flagship and on a budget phone, where "50 ms" quietly means
 * two different amounts of work. Milliseconds stay available for waiting on a
 * timer or a fetch, where wall clock really is what matters.
 */
class PreviewWaitTool(private val preview: PreviewController) : AgentTool {

    override val name = "preview_wait"
    override val description =
        "Let the running preview advance, then report how many frames it drew and whether it " +
            "threw. Prefer frames for animation and ms for timers. A frame count that does not " +
            "move means the page is not drawing."
    override val usage = """{"frames": 3, "ms": 600}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        if (!preview.claimSession(context.sessionId, context.treeUri)) {
            return AgentToolResult("Start a preview for this chat first; another chat's preview is isolated.", success = false)
        }

        val frames = args.int("frames", 0).coerceIn(0, MAX_FRAMES)
        val ms = args.int("ms", if (frames > 0) FRAME_BUDGET_MS else DEFAULT_MS).toLong()

        val state = preview.state.value
        if (!state.live) {
            return AgentToolResult(
                "not_running: there is no live preview. Call preview_start first.",
                success = false
            )
        }

        val outcome = preview.await(frames, ms)
        return AgentToolResult(
            buildString {
                append("Waited ").append(outcome.elapsedMs).append(" ms. ")
                append("Frames ").append(outcome.frames)
                append(" (+").append(outcome.advancedBy).append(").")
                if (outcome.throttled) {
                    append(" Heartbeat only: the preview screen is closed, so frame counts prove ")
                    append("the page is alive but say nothing about frame rate.")
                } else if (outcome.advancedBy == 0L) {
                    append(" Nothing was drawn -- the page is loaded but static or stalled.")
                }
                if (outcome.errors > 0) {
                    append(" ").append(outcome.errors)
                    append(" runtime error(s) pending: call preview_read_console and fix them ")
                    append("before doing anything else.")
                }
            }
        )
    }

    private companion object {
        const val MAX_FRAMES = 240
        const val DEFAULT_MS = 500
        const val FRAME_BUDGET_MS = 4_000
    }
}

/**
 * Reads the page's console and, more importantly, its crashes.
 *
 * Uncaught errors are printed first and separately. Buried among a hundred
 * `console.log` lines they get skimmed, and a model that skims a stack trace
 * concludes the run went fine and moves on to polish the layout of a page that
 * never drew.
 */
class PreviewReadConsoleTool(private val preview: PreviewController) : AgentTool {

    override val name = "preview_read_console"
    override val description =
        "Read what the running preview logged and every uncaught error or rejected promise it " +
            "produced. Errors come first. If any error is listed, fix it before judging the " +
            "page by how it looks."
    override val usage = """{"since_ms": 5000, "level": "error"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        if (!preview.claimSession(context.sessionId, context.treeUri)) {
            return AgentToolResult("Start a preview for this chat first; another chat's preview is isolated.", success = false)
        }

        val since = args.int("since_ms", 0).toLong().coerceAtLeast(0L)
        val level = args.stringOrEmpty("level").lowercase().ifBlank { "all" }
        if (level !in LEVELS) {
            return AgentToolResult(
                "bad_level: use one of " + LEVELS.joinToString(", "),
                success = false
            )
        }

        val report = preview.report(since, level)
        if (!report.ok) return AgentToolResult("not_running: ${report.reason}", success = false)

        return AgentToolResult(renderConsole(report.logs, report.errors))
    }

    private companion object {
        val LEVELS = listOf("all", "log", "info", "warn", "error", "debug")
    }
}

/**
 * The eye.
 *
 * Everything expensive about vision is handled below this tool -- downscaling,
 * quality, deduplication, the budget -- because the model cannot see how much a
 * frame cost and will happily ask for twenty.
 */
class PreviewScreenshotTool(private val preview: PreviewController) : AgentTool {

    override val name = "preview_screenshot"
    override val description =
        "Look at the running preview. Returns a compressed JPEG frame as an image, plus how it " +
            "was captured. Mode \"window\" is the true composite of DOM, CSS and WebGL and needs " +
            "the preview screen open; mode \"canvas\" asks the biggest canvas for its own pixels " +
            "and works with the screen closed. If the frame is identical to the last one, black " +
            "offscreen, or past this run's budget, you get a text outline of the page instead."
    override val usage = """{"mode": "window"}"""

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        if (!preview.claimSession(context.sessionId, context.treeUri)) {
            return AgentToolResult("Start a preview for this chat first; another chat's preview is isolated.", success = false)
        }

        val mode = args.stringOrEmpty("mode").trim().ifBlank { MODE_WINDOW }
        if (!mode.equals(MODE_WINDOW, ignoreCase = true) &&
            !mode.equals(MODE_CANVAS, ignoreCase = true)
        ) {
            return AgentToolResult(
                "bad_mode: \"" + mode + "\" is not a capture mode. Use \"" + MODE_WINDOW +
                    "\" or \"" + MODE_CANVAS + "\".",
                success = false
            )
        }

        val shot = preview.screenshot(
            mode = mode,
            maxWidth = args.int("max_width", PreviewCapture.MAX_WIDTH).coerceIn(MIN_SIDE, MAX_SIDE),
            quality = args.int("quality", PreviewCapture.QUALITY).coerceIn(MIN_QUALITY, MAX_QUALITY)
        )

        if (!shot.ok) {
            val outline = shot.outline
            return AgentToolResult(
                buildString {
                    append("No new frame: ").append(shot.reason.ifBlank { "the capture failed" })
                    if (outline.isNotEmpty()) {
                        append("\n\nWhat the page contains right now (")
                        append(outline.size).append(" elements):\n")
                        for (line in outline.take(MAX_OUTLINE)) {
                            append("  ").append(line).append('\n')
                        }
                        if (outline.size > MAX_OUTLINE) {
                            append("  ... ").append(outline.size - MAX_OUTLINE).append(" more\n")
                        }
                    }
                },
                // Not an error when the outline came back: the call answered the
                // question, just in text. Reporting failure invites an immediate
                // retry of the one thing that was already declined.
                success = outline.isNotEmpty()
            )
        }

        return AgentToolResult(
            buildString {
                append("Frame captured -- ").append(shot.source.name.lowercase())
                append(", ").append(shot.width).append('x').append(shot.height)
                append(", ").append(shot.sizeKb).append(" KB. It is attached as an image.")
                if (shot.black) {
                    append("\nThe frame is uniformly dark. From a window capture that is real: ")
                    append("the page is drawing nothing, or drawing in the background colour.")
                }
            },
            image = ToolImage(shot.base64, shot.mediaType)
        )
    }

    private companion object {
        const val MODE_WINDOW = "window"
        const val MODE_CANVAS = "canvas"
        const val MIN_SIDE = 240
        const val MAX_SIDE = 1280
        const val MIN_QUALITY = 20
        const val MAX_QUALITY = 95
        const val MAX_OUTLINE = 40
    }
}

/** A finger. */
class PreviewTapTool(private val preview: PreviewController) : AgentTool {

    override val name = "preview_tap"
    override val description =
        "Tap a point in the running preview. Coordinates are CSS pixels inside the page, so " +
            "take them from the element outline rather than from the picture. Synthetic events " +
            "go first because they report which element was hit; if nothing responds, a real " +
            "touch event follows, which is what engines that check isTrusted require."
    override val usage = """{"x": 360, "y": 640}"""
    override val requiredArgs = listOf("x", "y")

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        if (!preview.claimSession(context.sessionId, context.treeUri)) {
            return AgentToolResult("Start a preview for this chat first; another chat's preview is isolated.", success = false)
        }

        val x = args.int("x", -1)
        val y = args.int("y", -1)
        if (x < 0 || y < 0) {
            return AgentToolResult(
                "bad_point: x and y are required and must be zero or greater.",
                success = false
            )
        }
        val forceReal = args.stringOrEmpty("real").equals("true", ignoreCase = true)
        val result = preview.tap(x, y, forceReal)
        if (!result.ok) {
            return AgentToolResult("Tap failed: " + result.reason, success = false)
        }
        return AgentToolResult(
            buildString {
                append("Tapped ").append(x).append(',').append(y)
                append(if (result.real) " with a real touch event" else " with synthetic events")
                append(". Hit: ").append(result.element)
                append("\nFrames ").append(result.framesBefore).append(" -> ")
                append(result.framesAfter)
                append(if (result.moved) " (the page advanced)" else " (nothing advanced)")
                if (result.errors > 0) {
                    append("\n").append(result.errors)
                    append(" runtime error(s) are waiting -- read preview_read_console and fix ")
                    append("them before testing anything else.")
                }
                if (result.reason.isNotBlank()) append('\n').append(result.reason)
            }
        )
    }
}

/** A keyboard. */
class PreviewKeyTool(private val preview: PreviewController) : AgentTool {

    override val name = "preview_key"
    override val description =
        "Press a key in the running preview. Use KeyboardEvent codes: ArrowLeft, ArrowUp, " +
            "Space, KeyW, Enter, Escape. hold_ms keeps the key down, which is what continuous " +
            "movement needs -- a zero-length press moves most games by one step or not at all."
    override val usage = """{"code": "ArrowLeft", "hold_ms": 200}"""
    override val requiredArgs = listOf("code")

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        if (!preview.claimSession(context.sessionId, context.treeUri)) {
            return AgentToolResult("Start a preview for this chat first; another chat's preview is isolated.", success = false)
        }

        val code = args.stringOrEmpty("code").trim()
        if (code.isBlank()) {
            return AgentToolResult(
                "bad_code: give a KeyboardEvent code such as ArrowLeft or Space.",
                success = false
            )
        }
        val hold = args.int("hold_ms", DEFAULT_HOLD_MS).coerceIn(0, MAX_HOLD_MS).toLong()
        val wait = preview.key(code, hold)
        return AgentToolResult(
            buildString {
                append("Pressed ").append(code).append(" for ").append(hold).append(" ms. ")
                append("Frames advanced by ").append(wait.advancedBy)
                append(" in ").append(wait.elapsedMs).append(" ms.")
                if (wait.throttled) {
                    append("\nThe preview screen is not in front, so that count is a heartbeat ")
                    append("rather than real frames and cannot prove the key had an effect.")
                }
                if (wait.errors > 0) {
                    append("\n").append(wait.errors)
                    append(" runtime error(s) -- read preview_read_console and fix them first.")
                }
            }
        )
    }

    private companion object {
        const val DEFAULT_HOLD_MS = 80
        const val MAX_HOLD_MS = 3_000
    }
}

/**
 * The instrument, as opposed to the eye.
 *
 * Deliberately included even though a screenshot can "see" the same thing: one
 * expression answers precisely, in a few tokens, questions a picture only
 * suggests -- whether the array is empty, whether the flag flipped, whether the
 * listener was ever attached.
 */
class PreviewEvalJsTool(private val preview: PreviewController) : AgentTool {

    override val name = "preview_eval_js"
    override val description =
        "Evaluate a JavaScript expression inside the running page and return its value. Far " +
            "cheaper and more exact than a screenshot for checking state: game.score, " +
            "entities.length, typeof window.init, document.querySelectorAll('.enemy').length."
    override val usage = """{"expression": "game.score"}"""
    override val requiredArgs = listOf("expression")

    override suspend fun execute(args: JsonObject, context: AgentContext): AgentToolResult {
        if (!preview.claimSession(context.sessionId, context.treeUri)) {
            return AgentToolResult("Start a preview for this chat first; another chat's preview is isolated.", success = false)
        }

        val expression = args.stringOrEmpty("expression").ifBlank { args.stringOrEmpty("expr") }
        if (expression.isBlank()) {
            return AgentToolResult("bad_expression: nothing to evaluate.", success = false)
        }
        val result = preview.evalJs(expression)
        if (!result.ok) {
            return AgentToolResult(
                buildString {
                    append("The expression threw: ").append(result.reason)
                    val frame = result.stack.lineSequence().map { it.trim() }
                        .firstOrNull { it.isNotEmpty() }
                    if (!frame.isNullOrBlank()) append("\n  at ").append(frame.take(160))
                },
                success = false
            )
        }
        return AgentToolResult(
            buildString {
                append(result.type).append(": ")
                append(result.value.take(MAX_VALUE_CHARS))
                if (result.value.length > MAX_VALUE_CHARS) append(" ...(truncated)")
            }
        )
    }

    private companion object {
        const val MAX_VALUE_CHARS = 4_000
    }
}

/**
 * One rendering for both tools, so the model never has to learn two shapes for
 * the same information.
 */
private fun renderConsole(logs: List<ConsoleEntry>, errors: List<PreviewCrash>): String {
    if (errors.isEmpty() && logs.isEmpty()) return "Console is empty and no errors were thrown."

    return buildString {
        if (errors.isNotEmpty()) {
            append("RUNTIME ERRORS (").append(errors.size).append(") -- fix these first:\n")
            for (error in errors.take(MAX_ERRORS)) {
                append("  ! ").append(error.message)
                if (error.source.isNotBlank()) {
                    append("  [").append(error.source.substringAfterLast('/'))
                    if (error.line > 0) append(':').append(error.line).append(':').append(error.column)
                    append(']')
                }
                append('\n')
                val frame = error.stack.lineSequence()
                    .map { it.trim() }
                    .firstOrNull { it.isNotEmpty() && !it.startsWith(error.message) }
                if (!frame.isNullOrBlank()) append("      at ").append(frame.take(160)).append('\n')
            }
            if (errors.size > MAX_ERRORS) {
                append("  ... ").append(errors.size - MAX_ERRORS).append(" more\n")
            }
            append('\n')
        }

        if (logs.isEmpty()) {
            append("Console produced no output.")
            return@buildString
        }

        append("CONSOLE (").append(logs.size).append("):\n")
        val shown = if (logs.size > MAX_LOGS) logs.takeLast(MAX_LOGS) else logs
        if (logs.size > MAX_LOGS) {
            append("  ... ").append(logs.size - MAX_LOGS).append(" earlier lines dropped\n")
        }
        for (entry in shown) {
            append("  ").append(entry.level.uppercase().padEnd(5)).append("  ")
            append(entry.message.replace('\n', ' ').take(MAX_LINE)).append('\n')
        }
    }
}

private const val MAX_ERRORS = 12
private const val MAX_LOGS = 60
private const val MAX_LINE = 300

/**
 * The whole family, in the order a run uses them.
 *
 * All seven gate on the same session setting as every other tool, so a chat with
 * tools switched off has no preview either -- and a chat that has them keeps the
 * loop intact rather than half of it.
 */
fun previewTools(preview: PreviewController): List<AgentTool> = listOf(
    PreviewStartTool(preview),
    PreviewWaitTool(preview),
    PreviewReadConsoleTool(preview),
    PreviewScreenshotTool(preview),
    PreviewTapTool(preview),
    PreviewKeyTool(preview),
    PreviewEvalJsTool(preview)
)
