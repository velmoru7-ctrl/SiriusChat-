package com.sirius.chat.core.util;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.ArrayList;

/** Production path policy, independent of Android and directly JVM-testable. */
public final class SafeProjectPaths {
    private SafeProjectPaths() {}

    public static String relative(String path, boolean allowRoot) {
        if (path == null || path.startsWith("/") || path.indexOf('\\') >= 0 || path.indexOf('\0') >= 0 || (path.length() >= 2 && path.substring(0, 2).matches("[A-Za-z]:"))) {
            throw new IllegalArgumentException("Only project-relative paths are allowed.");
        }
        ArrayList<String> parts = new ArrayList<>();
        for (String part : path.split("/")) {
            if (part.equals("..")) throw new IllegalArgumentException("Parent traversal is not allowed.");
            if (!part.isEmpty() && !part.equals(".")) parts.add(part);
        }
        if (!allowRoot && parts.isEmpty()) throw new IllegalArgumentException("A file path is required.");
        return String.join("/", parts);
    }

    public static File file(File root, String path) throws IOException {
        String normalized = relative(path, false);
        if (Files.isSymbolicLink(root.toPath())) throw new IllegalArgumentException("The sandbox root cannot be a symlink.");
        File base = root.getCanonicalFile();
        File current = base;
        for (String segment : normalized.split("/")) {
            current = new File(current, segment);
            if (Files.isSymbolicLink(current.toPath())) throw new IllegalArgumentException("Symlinks are not allowed in the sandbox.");
        }
        File target = current.getCanonicalFile();
        if (!target.toPath().startsWith(base.toPath()) || target.equals(base)) throw new IllegalArgumentException("Path escapes the sandbox.");
        return target;
    }
}
