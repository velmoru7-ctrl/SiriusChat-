package com.sirius.chat.feature.github

import android.content.Context
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.sirius.chat.R
import com.sirius.chat.data.github.GitHubService
import com.sirius.chat.di.AppContainer
import com.sirius.chat.domain.model.GitHubAccount
import com.sirius.chat.domain.model.GitHubArtifact
import com.sirius.chat.domain.model.GitHubEntry
import com.sirius.chat.domain.model.GitHubRepo
import com.sirius.chat.domain.model.GitHubRun
import com.sirius.chat.core.util.SafeApkExtractor
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.ensureActive
import kotlinx.coroutines.withContext
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import java.io.File

data class GitHubUiState(
    val account: GitHubAccount? = null,
    val repos: List<GitHubRepo> = emptyList(),
    val selectedRepo: String = "",
    val runs: List<GitHubRun> = emptyList(),
    val artifacts: List<GitHubArtifact> = emptyList(),
    /** Non-blank while a request is in flight; the text labels what is happening. */
    val busy: String = "",
    val message: String = "",
    val messageIsError: Boolean = false,
    /** Absolute path of the APK pulled out of the last downloaded artifact. */
    val apkPath: String = "",
    /** Directory the repository browser is showing; empty is the repo root. */
    val browsePath: String = "",
    val entries: List<GitHubEntry> = emptyList(),
    /** Open file, or null when the browser is showing a directory. */
    val openFile: GitHubFileDraft? = null
) {
    val connected: Boolean get() = account != null
    val selected: GitHubRepo? get() = repos.firstOrNull { it.fullName == selectedRepo }
    val latestRun: GitHubRun? get() = runs.firstOrNull()
    val building: Boolean get() = runs.any { !it.finished }

    /** Breadcrumb segments of [browsePath], each with the path to jump to. */
    val breadcrumbs: List<Pair<String, String>>
        get() {
            if (browsePath.isBlank()) return emptyList()
            val parts = browsePath.trim('/').split('/')
            var acc = ""
            return parts.map { part ->
                acc = if (acc.isEmpty()) part else "$acc/$part"
                part to acc
            }
        }

    val parentPath: String?
        get() = when {
            browsePath.isBlank() -> null
            !browsePath.contains('/') -> ""
            else -> browsePath.substringBeforeLast('/')
        }
}

/**
 * A file opened from the repository, with the text as it was fetched.
 *
 * [original] is kept so the commit button can tell "edited" from "opened and
 * closed": committing an untouched file would put an empty commit in the history
 * and cost the user a CI run if a workflow watches the branch.
 */
data class GitHubFileDraft(
    val path: String,
    val original: String,
    val content: String,
    val repo: String,
    val sha: String
) {
    val name: String get() = path.substringAfterLast('/')
    val dirty: Boolean get() = content != original
}

/**
 * The GitHub screen's state machine.
 *
 * Every network call goes through [run], which owns the busy label, clears the
 * previous message and turns a [com.sirius.chat.data.github.GitHubException] into
 * a sentence. That is the difference between a screen that reports "GitHub 401:
 * Bad credentials" and one that spins forever.
 *
 * Build progress is polled rather than pushed, because GitHub has no webhook a
 * phone can receive. The poll only runs while a run is unfinished and only while
 * the screen is alive, so an idle repository costs nothing.
 */
class GitHubViewModel(private val container: AppContainer) : ViewModel() {

    private val github = container.github
    private val accounts = container.githubAccounts
    private val strings = container.strings

    private val _state = MutableStateFlow(GitHubUiState())
    val state: StateFlow<GitHubUiState> = _state.asStateFlow()

    private var pollJob: Job? = null
    private var operationJob: Job? = null
    private var operationSerial = 0L
    private var pendingRepo: String? = null

    init {
        viewModelScope.launch {
            accounts.account.collect { account ->
                _state.value = _state.value.copy(account = account)
                if (account != null && _state.value.repos.isEmpty()) refreshRepos()
            }
        }
        viewModelScope.launch {
            container.settingsRepository.settings
                .map { it.githubRepo }
                .collect { repo ->
                    if (repo != _state.value.selectedRepo) {
                        if (_state.value.openFile?.dirty == true) {
                            pendingRepo = repo // Settings/agent changes cannot throw away local edits.
                        } else {
                            adoptRepo(repo)
                            if (repo.isNotBlank()) refreshAll()
                        }
                    }
                }
        }
    }

    // ---------------------------------------------------------------- connecting

    fun connect(token: String) {
        val trimmed = token.trim()
        if (trimmed.isEmpty()) return
        operation(strings.get(R.string.github_busy_connecting)) {
            val account = github.verify(trimmed)
            accounts.save(account, trimmed)
            refreshReposNow()
            strings.get(R.string.github_connected_as, account.displayName)
        }
    }

    fun disconnect() {
        cancelOperations()
        pollJob?.cancel()
        pendingRepo = null
        _state.value = GitHubUiState()
        operation(strings.get(R.string.github_busy_connecting)) {
            accounts.disconnect()
            container.settingsRepository.update { it.copy(githubRepo = "") }
            strings.get(R.string.github_disconnected)
        }
    }

    // -------------------------------------------------------------------- repos

    private suspend fun refreshReposNow() {
        val repos = github.repos()
        _state.value = _state.value.copy(repos = repos)
    }
    fun refreshRepos() {
        operation(strings.get(R.string.github_busy_repos)) { refreshReposNow(); "" }
    }
    fun refreshAll() {
        operation(strings.get(R.string.github_busy_repos)) {
            refreshReposNow(); refreshBrowse(); refreshRunsNow(); ""
        }
    }
    private fun cancelOperations() {
        operationSerial++
        operationJob?.cancel()
        operationJob = null
        _state.value = _state.value.copy(busy = "")
    }
    private fun adoptRepo(repo: String) {
        cancelOperations()
        pollJob?.cancel()
        pollJob = null
        pendingRepo = null
        _state.value = _state.value.copy(
            selectedRepo = repo, browsePath = "", entries = emptyList(), openFile = null,
            runs = emptyList(), artifacts = emptyList(), apkPath = ""
        )
    }
    fun selectRepo(fullName: String) {
        if (_state.value.busy.isNotBlank()) return
        val previous = _state.value.selectedRepo
        adoptRepo(fullName) // Scope is set before any suspend point.
        operation(strings.get(R.string.github_busy_files)) {
            try {
                container.settingsRepository.update { it.copy(githubRepo = fullName) }
            } catch (cancel: CancellationException) {
                throw cancel
            } catch (error: Exception) {
                _state.value = _state.value.copy(selectedRepo = previous)
                throw error
            }
            refreshBrowse(); refreshRunsNow(); ""
        }
    }

    fun toggleVisibility() {
        val repo = _state.value.selected ?: return
        operation(strings.get(R.string.github_busy_visibility)) {
            val updated = github.setVisibility(repo.fullName, isPrivate = !repo.isPrivate)
            _state.value = _state.value.copy(
                repos = _state.value.repos.map { if (it.fullName == updated.fullName) updated else it }
            )
            strings.get(
                if (updated.isPrivate) R.string.github_now_private else R.string.github_now_public,
                updated.fullName
            )
        }
    }

    // ------------------------------------------------------------------ browsing

    /** Lists [path] in the selected repository. Empty path means the root. */
    fun browse(path: String = _state.value.browsePath) {
        val repo = _state.value.selectedRepo
        if (repo.isBlank()) return
        operation(strings.get(R.string.github_busy_files)) {
            val entries = github.list(repo, path)
            if (_state.value.selectedRepo != repo) return@operation ""
            _state.value = _state.value.copy(
                browsePath = path,
                // Directories first, then files, each alphabetically: the API
                // returns them interleaved, which makes a deep tree unreadable.
                entries = entries.sortedWith(
                    compareByDescending<GitHubEntry> { it.isDirectory }
                        .thenBy { it.name.lowercase() }
                ),
                openFile = null
            )
            ""
        }
    }

    fun browseUp() {
        val parent = _state.value.parentPath ?: return
        browse(parent)
    }

    fun openFile(entry: GitHubEntry) {
        val repo = _state.value.selectedRepo
        if (repo.isBlank() || entry.isDirectory) return
        // A 5 MB blob would be fetched, base64-decoded and handed to a text field
        // that then drops frames on every keystroke. Refusing early is kinder.
        if (entry.sizeBytes > MAX_EDIT_BYTES) {
            _state.value = _state.value.copy(
                message = strings.get(R.string.github_file_too_big, entry.name),
                messageIsError = true
            )
            return
        }
        operation(strings.get(R.string.github_busy_file)) {
            val version = github.readFileVersion(repo, entry.path, maxBytes = MAX_EDIT_BYTES.toInt())
            if (_state.value.selectedRepo != repo) return@operation ""
            _state.value = _state.value.copy(
                openFile = GitHubFileDraft(entry.path, version.content, version.content, repo, version.sha)
            )
            ""
        }
    }

    fun editOpenFile(content: String) {
        val open = _state.value.openFile ?: return
        _state.value = _state.value.copy(openFile = open.copy(content = content))
    }

    fun closeFile() {
        _state.value = _state.value.copy(openFile = null)
        pendingRepo?.let { repo -> adoptRepo(repo); if (repo.isNotBlank()) refreshAll() }
    }

    /** Commits the open file. Does nothing when it was not edited. */
    fun commitOpenFile(message: String) {
        val repo = _state.value.selectedRepo
        val open = _state.value.openFile ?: return
        if (repo.isBlank() || !open.dirty || open.repo != repo || open.sha.isBlank()) return
        operation(strings.get(R.string.github_busy_commit)) {
            val receipt = github.writeFile(
                fullName = repo,
                path = open.path,
                content = open.content,
                message = message.ifBlank { "Update ${open.path} via Sirius Chat" },
                expectedSha = open.sha
            )
            val latest = _state.value.openFile
            if (_state.value.selectedRepo == repo && latest != null && latest.repo == repo &&
                latest.path == open.path && latest.sha == open.sha
            ) {
                // Preserve typing made while GitHub saved the submitted snapshot.
                _state.value = _state.value.copy(
                    openFile = latest.copy(original = open.content, sha = receipt.blobSha)
                )
            }
            strings.get(R.string.github_committed, open.name)
        }
    }

    /** Creates a file inside the directory currently being browsed. */
    fun createFile(name: String, content: String = "") {
        val repo = _state.value.selectedRepo
        val clean = name.trim().trim('/')
        if (repo.isBlank() || clean.isEmpty()) return
        val path = joinPath(_state.value.browsePath, clean)
        operation(strings.get(R.string.github_busy_create)) {
            if (github.exists(repo, path)) {
                throw IllegalStateException(strings.get(R.string.github_path_exists, path))
            }
            github.putFile(
                fullName = repo,
                path = path,
                content = content,
                message = "Create $path via Sirius Chat",
                expectedSha = ""
            )
            refreshBrowse()
            strings.get(R.string.github_created_file, path)
        }
    }

    fun createFolder(name: String) {
        val repo = _state.value.selectedRepo
        val clean = name.trim().trim('/')
        if (repo.isBlank() || clean.isEmpty()) return
        val path = joinPath(_state.value.browsePath, clean)
        operation(strings.get(R.string.github_busy_create)) {
            github.createFolder(repo, path)
            refreshBrowse()
            strings.get(R.string.github_created_folder, path)
        }
    }

    fun deleteEntry(entry: GitHubEntry) {
        val repo = _state.value.selectedRepo
        if (repo.isBlank() || entry.isDirectory) return
        operation(strings.get(R.string.github_busy_delete)) {
            github.deleteFile(repo, entry.path, "Delete ${entry.path} via Sirius Chat")
            refreshBrowse()
            strings.get(R.string.github_deleted, entry.name)
        }
    }

    private suspend fun refreshBrowse() {
        val repo = _state.value.selectedRepo
        if (repo.isBlank()) return
        val path = _state.value.browsePath
        val entries = github.list(repo, path)
        if (_state.value.selectedRepo != repo || _state.value.browsePath != path) return
        _state.value = _state.value.copy(
            entries = entries.sortedWith(
                compareByDescending<GitHubEntry> { it.isDirectory }.thenBy { it.name.lowercase() }
            )
        )
    }

    private fun joinPath(dir: String, name: String): String =
        if (dir.isBlank()) name else "${dir.trim('/')}/$name"

    // ------------------------------------------------------------------- builds

    fun build(variant: String) {
        val repo = _state.value.selectedRepo
        if (repo.isBlank()) return
        operation(strings.get(R.string.github_busy_build)) {
            val branch = github.repo(repo).defaultBranch
            val installed = github.ensureBuildWorkflow(repo, branch)
            github.dispatchWorkflow(fullName = repo, ref = branch, variant = variant)
            // Actions registers the run a beat after the dispatch returns 204, so
            // an immediate refresh would show the previous run and look broken.
            delay(2_500)
            refreshRunsNow()
            startPolling()
            if (installed) {
                strings.get(R.string.github_workflow_installed, GitHubService.WORKFLOW_PATH)
            } else {
                strings.get(R.string.github_build_started, variant)
            }
        }
    }

    fun refreshRuns() {
        val repo = _state.value.selectedRepo
        if (repo.isBlank()) return
        operation(strings.get(R.string.github_busy_runs)) {
            refreshRunsNow()
            startPolling()
            ""
        }
    }

    private suspend fun refreshRunsNow() {
        val repo = _state.value.selectedRepo
        if (repo.isBlank()) return
        val runs = github.runs(repo, limit = 8)
        val newest = runs.firstOrNull()
        val artifacts = if (newest != null && newest.finished && newest.succeeded) {
            try { github.artifacts(repo, newest.id) }
            catch (cancel: CancellationException) { throw cancel }
            catch (_: Exception) { emptyList() }
        } else {
            emptyList()
        }
        if (_state.value.selectedRepo == repo) {
            _state.value = _state.value.copy(runs = runs, artifacts = artifacts)
        }
    }

    /**
     * Polls while something is running. Ten minutes of eight-second checks is
     * enough for a cold Gradle build on a fresh runner; past that the user is
     * better served by the Actions page than by a spinner.
     */
    private fun startPolling() {
        if (pollJob?.isActive == true) return
        val repo = _state.value.selectedRepo
        pollJob = viewModelScope.launch {
            var attempts = 0
            while (attempts < 75 && _state.value.building && _state.value.selectedRepo == repo) {
                delay(8_000)
                if (_state.value.busy.isBlank()) {
                    try { refreshRunsNow() }
                    catch (cancel: CancellationException) { throw cancel }
                    catch (_: Exception) { /* The next poll may recover. */ }
                }
                attempts++
            }
        }
    }

    // ---------------------------------------------------------------- artifacts

    /**
     * Downloads an artifact and unpacks the APK out of it.
     *
     * Actions always hands back a zip, even for a single file, so a raw download
     * would leave the user holding an archive their phone cannot install. The APK
     * is extracted next to it and its path is reported so the screen can offer an
     * install intent.
     */
    fun download(context: Context, artifact: GitHubArtifact) {
        val repo = _state.value.selectedRepo
        if (repo.isBlank()) return
        operation(strings.get(R.string.github_busy_download)) {
            _state.value = _state.value.copy(apkPath = "")
            val external = context.getExternalFilesDir(null)
                ?: throw java.io.IOException("App download storage is unavailable")
            val dir = File(external, "apk")
            val zip = File(dir, "artifact-${artifact.id}.zip")
            github.downloadArtifact(repo, artifact.id, zip)
            val apk = withContext(container.dispatchers.io) {
                val context = currentCoroutineContext()
                SafeApkExtractor.extract(zip, dir) { context.ensureActive() }
            }
            if (_state.value.selectedRepo != repo) return@operation ""
            if (apk == null) strings.get(R.string.github_download_zip_only, zip.name)
            else {
                _state.value = _state.value.copy(apkPath = apk.absolutePath)
                strings.get(R.string.github_download_done, apk.name)
            }
        }
    }

    // ----------------------------------------------------------------- plumbing

    fun dismissMessage() {
        _state.value = _state.value.copy(message = "", messageIsError = false)
    }

    /**
     * Runs one operation with a busy label. The block returns the message to
     * show, or an empty string for "no news is good news".
     */
    private fun operation(label: String, block: suspend () -> String) {
        if (_state.value.busy.isNotBlank()) return
        val serial = ++operationSerial
        pollJob?.cancel()
        pollJob = null
        _state.value = _state.value.copy(busy = label, message = "", messageIsError = false)
        operationJob = viewModelScope.launch {
            try {
                val message = block()
                if (serial == operationSerial) {
                    _state.value = _state.value.copy(message = message, messageIsError = false)
                }
            } catch (cancel: CancellationException) {
                throw cancel
            } catch (error: Exception) {
                if (serial == operationSerial) {
                    _state.value = _state.value.copy(message = error.message.orEmpty(), messageIsError = true)
                }
            } finally {
                if (serial == operationSerial) {
                    _state.value = _state.value.copy(busy = "")
                    if (_state.value.building) startPolling()
                }
            }
        }
    }

    /** True once a token is stored, without exposing the token itself. */
    suspend fun hasToken(): Boolean = accounts.account.first() != null

    private companion object {
        /** Editing cap. Above this a file is a payload, not something to hand-edit. */
        const val MAX_EDIT_BYTES = 512L * 1024
    }
}
